# Rubik Universe V13 — V12 + V13 tích hợp

Rubik Universe là workspace speedcubing chạy bằng HTML/CSS/JavaScript ES Modules thuần. Không cần framework hoặc bước build. Bản V13 tích hợp phần thống kê nâng cao của V12 cùng bộ Rubik 3D cubie-level và sửa hiển thị của V13; tiếp tục giữ các module và dữ liệu đã có từ V11.

## Điểm mới của V12 + V13

### V12 — phân tích dữ liệu luyện tập
- Bộ lọc Statistics theo session, puzzle và khoảng ngày; xuất CSV dùng cùng bộ lọc.
- Best Ao100, Current Ao50 và tổng hợp xu hướng theo tuần/tháng.
- Giữ nguyên dữ liệu solve/session và cách lưu cục bộ.

### V13 — Rubik 3D và mô phỏng case
- Mô hình 3×3 dựng từ 26 cubie hiển thị riêng, mỗi cubie có đủ sáu mặt với hướng sticker tương ứng.
- Nút **3D** trong thư viện mở thẳng trạng thái case được dựng bằng công thức nghịch đảo; không hiển thị danh sách move làm màn hình mở đầu.
- Thông tin nhận diện, hướng cầm, tips và công thức được hiển thị cùng trạng thái case.
- Nút **Phát công thức từ trạng thái case** chuyển sang chế độ sequence, xoay từng lớp cubie bằng CSS animation rồi đồng bộ với cube engine.
- Hỗ trợ kéo/ vuốt để đổi góc nhìn, zoom, đặt lại góc nhìn và tự co giãn kích thước theo vùng hiển thị.
- Sửa flattening của CSS 3D, hướng mặt U/D và góc animation khi quy đổi từ tọa độ cube sang tọa độ màn hình.

## Các chức năng tiếp tục được giữ
- Timer, Inspection, +2/DNF, Session Manager và lịch sử solve.
- Scramble Center cho 11 loại puzzle; scramble practice được phân biệt với scramble random-state chính thức.
- Statistics, biểu đồ, Solver 3×3 và kiểm chứng lời giải.
- CFOP 119 case; khu 2-Look OLL/PLL riêng trong CFOP; công thức cá nhân.
- Beginner, Roux, ZZ và Petrus; Algorithm Trainer, Academy và lặp lại ngắt quãng.
- Thư viện kiến thức, tìm kiếm, Settings, backup/restore, PWA và offline cache.

## Cách hoạt động của 3D

Mô hình sử dụng `src/cube.js` làm nguồn sự thật cho vị trí sticker, hướng sticker và các move. `src/cube3d.js` nhóm 54 sticker thành 26 cubie, dựng sáu mặt cho mỗi cubie và nhóm đúng lớp đang chuyển động. Animation là lớp hiển thị trước khi trạng thái move được commit bằng cube engine; vì vậy trạng thái sau animation và trạng thái thuật toán dùng cùng một phép xoay. Bộ chuyển động hỗ trợ face turns, wide turns, slice turns, whole-cube rotations và các lớp `2R` / `3Rw` trong phạm vi mô hình 3×3.

Khi mở một case, trạng thái được tái tạo bằng inverse formula từ cube đã giải. Đây là trạng thái minh họa theo chính công thức lưu trong case; nếu công thức tùy chỉnh bị sửa sai, hình 3D cũng sẽ thể hiện trạng thái theo công thức mới đó.

## Giữ dữ liệu & tương thích

- LocalStorage key vẫn là `rubik-universe-v1`; không đổi khóa lưu dữ liệu.
- Migration hiện tại giữ session, solve, thuật toán cá nhân, tiến độ case, mục tiêu luyện tập và bản nháp Solver cũ.
- Cache Service Worker được nâng lên `rubik-universe-v13-0`, precache cả `src/cube3d.js` và `src/analytics.js`.
- Dữ liệu solve/session/thuật toán vẫn lưu trên trình duyệt hiện tại; không có đồng bộ cloud. Hãy xuất JSON backup trước khi cập nhật.

## Chạy local trên Windows

1. Giải nén `Rubik-Universe-V13.zip`.
2. Mở Terminal trong thư mục có `index.html`.
3. Chạy `py -m http.server 8080`.
4. Mở `http://localhost:8080`.

Không mở bằng `file://`; ứng dụng dùng ES Modules, Worker và Service Worker.

## Kiểm thử

Yêu cầu Node.js 18+; chạy:

```bash
npm test
```

Bộ test bao gồm tính đúng đắn move engine, 26 cubie, lớp xoay, hướng mặt U/D, preview case từ inverse formula, thống kê, dữ liệu cũ, thuật toán, scramble, PWA và workflow. Ở lần đóng gói này, `npm test` đạt **64/64**. Ngoài ra đã dùng Chromium để dựng ảnh thử từ CSS và bộ renderer: xác nhận có đủ 26 cubie, mặt trước/phải/trên hiển thị đúng màu. Do sandbox chặn điều hướng Chromium tới `localhost` và `file://`, chưa thực hiện được E2E toàn bộ ứng dụng qua server; không coi kiểm thử tĩnh này là thay thế cho việc thử trên Chrome/Edge thực tế.

## Cập nhật GitHub Pages

Xem `HUONG-DAN-GITHUB-V13.md`. Không cần repository mới: cập nhật workflow V13 trong `.github/workflows/deploy-pages.yml`, upload `Rubik-Universe-V13.zip` vào thư mục gốc repository và commit để GitHub Actions triển khai lại.

## Nguồn và giấy phép

Các nguồn thuật toán phương pháp nằm trong `src/methods-data.js`. Solver dùng cube.js 1.3.2; thông tin giấy phép được ghi ở `THIRD-PARTY-LICENSES.md`.
