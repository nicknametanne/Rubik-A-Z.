import test from 'node:test';
import assert from 'node:assert/strict';
import { filterStatsSolves, groupSolveAverages } from '../src/analytics.js';

const sessions = [
  { id: 's1', puzzle: '3x3' },
  { id: 's2', puzzle: '2x2' }
];
const solves = [
  { id: 'a', sessionId: 's1', rawMs: 10000, penalty: 'none', createdAt: '2026-11-02T10:00:00' },
  { id: 'b', sessionId: 's1', rawMs: 12000, penalty: '+2', createdAt: '2026-11-04T10:00:00' },
  { id: 'c', sessionId: 's2', rawMs: 7000, penalty: 'none', createdAt: '2026-11-05T10:00:00' },
  { id: 'd', sessionId: 's1', rawMs: 0, penalty: 'DNF', createdAt: '2026-12-01T10:00:00' }
];

test('V13 statistics filters apply session, puzzle and inclusive date range consistently', () => {
  const result = filterStatsSolves(solves, sessions, {
    sessionId: 'all', activeSessionId: 's1', puzzle: '3x3', from: '2026-11-03', to: '2026-11-30'
  });
  assert.deepEqual(result.map(item => item.id), ['b']);
  assert.deepEqual(filterStatsSolves(solves, sessions, { activeSessionId: 's1' }).map(item => item.id), ['a', 'b', 'd']);
});

test('V13 weekly and monthly analytics aggregate real solve rows, exclude DNF from mean and retain counts', () => {
  const weekly = groupSolveAverages(solves, 'week', 12);
  const november = weekly.find(group => group.key === '2026-11-02');
  assert.ok(november);
  assert.equal(november.solves, 3);
  assert.equal(november.dnfs, 0);
  assert.equal(november.averageMs, (10000 + 14000 + 7000) / 3);
  const monthly = groupSolveAverages(solves, 'month', 12);
  assert.equal(monthly.length, 2);
  assert.equal(monthly[0].key, '2026-11');
  assert.equal(monthly[1].dnfs, 1);
  assert.equal(monthly[1].averageMs, null);
});
