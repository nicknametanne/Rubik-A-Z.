import test from 'node:test';
import assert from 'node:assert/strict';
import { createSolvedCube, applyCubeMove, applyCubeMoves, describeCubeMove, invertCubeMoves, isCubeSolved } from '../src/cube.js';
import { countVisibleCubies, renderCube3D, getCssTurnAngle } from '../src/cube3d.js';
import { isValidNotation } from '../src/core.js';
import { readFile } from 'node:fs/promises';

const read = relative => readFile(new URL(`../${relative}`, import.meta.url), 'utf8');

test('V13 3D scene is built from 26 distinct cubies and all six face directions', () => {
  const cube = createSolvedCube();
  const markup = renderCube3D(cube);
  assert.equal(countVisibleCubies(cube), 26);
  assert.equal((markup.match(/class="viz-cubie"/g) || []).length, 26);
  for (const face of ['front', 'back', 'left', 'right', 'top', 'bottom']) assert.ok(markup.includes(`viz-cubie-face-${face}`));
  assert.ok(markup.includes('--sticker-color:#f5f3ea'));
});

test('V13 layer transforms support face, wide, slice, rotation and 2R/3Rw layers exactly', () => {
  assert.deepEqual(describeCubeMove('R'), { axis: 'x', layers: [1], turns: -1 });
  assert.deepEqual(describeCubeMove('Rw'), { axis: 'x', layers: [1, 0], turns: -1 });
  assert.deepEqual(describeCubeMove('3Rw'), { axis: 'x', layers: [1, 0, -1], turns: -1 });
  assert.deepEqual(describeCubeMove('2R'), { axis: 'x', layers: [0], turns: -1 });
  assert.deepEqual(describeCubeMove('M'), { axis: 'x', layers: [0], turns: 1 });
  assert.deepEqual(describeCubeMove('x'), { axis: 'x', layers: [-1, 0, 1], turns: -1 });
  assert.ok(isValidNotation("R U R' U' 2R 3Rw M E S x y z"));
  assert.throws(() => describeCubeMove('4Rw'), /outside the 3×3 model/);
});

test('V13 move and reverse move return the full cubie state to its origin', () => {
  for (const move of ['R', 'U2', "F'", 'Rw', 'Lw2', 'M', "E'", 'S2', 'x', "y'", '3Rw', '2R']) {
    const scrambled = applyCubeMove(createSolvedCube(), move);
    const restored = applyCubeMoves(scrambled, invertCubeMoves(move).join(' '));
    assert.equal(isCubeSolved(restored), true, `Failed to invert ${move}`);
    assert.equal(countVisibleCubies(restored), 26);
  }
});

test('V13 3D library action opens a case-state preview instead of autoplaying move steps', async () => {
  const app = await read('src/app.js');
  const html = await read('index.html');
  assert.ok(app.includes('function loadVisualizerCasePreview(item)'));
  assert.ok(app.includes('const inverse = invertCubeMoves(tokens.join(\' \')).join(\' \')'));
  assert.ok(app.includes('visualizer.mode = \'case\';'));
  assert.ok(app.includes('function jumpVisualizerToAlgorithm(id)'));
  assert.ok(html.includes('id="viz-case-preview"'));
  assert.ok(html.includes('id="viz-sequence-controls"'));
  assert.ok(html.includes('id="viz-case-play"'));
});

test('V13 cubie top and bottom stickers face the correct positive and negative Y axes', async () => {
  const css = await read('styles.css');
  assert.match(css, /\.viz-cubie-face-top\s*\{\s*transform:\s*rotateX\(90deg\)/);
  assert.match(css, /\.viz-cubie-face-bottom\s*\{\s*transform:\s*rotateX\(-90deg\)/);
});

test('V13 3D scene groups exactly the affected cubies for face, wide, slice and whole-cube turns', () => {
  const cube = createSolvedCube();
  const cases = [['R', 9, 17], ['Rw', 17, 9], ['M', 8, 18], ['x', 26, 0]];
  for (const [token, movingCount, stationaryCount] of cases) {
    const turn = describeCubeMove(token);
    const markup = renderCube3D(cube, { turn });
    const layerStart = markup.indexOf('class="viz-turn-layer"');
    const stationaryMarkup = layerStart >= 0 ? markup.slice(0, layerStart) : markup;
    const stationaryRendered = (stationaryMarkup.match(/class="viz-cubie"/g) || []).length;
    const totalRendered = (markup.match(/class="viz-cubie"/g) || []).length;
    assert.equal(totalRendered - stationaryRendered, movingCount, `${token} moving cubies`);
    assert.equal(totalRendered, movingCount + stationaryCount, `${token} total cubies`);
  }
});

test('V13 every library case can be reconstructed from its inverse algorithm and solved with its own formula', async () => {
  const { CFOP_CASES } = await import('../src/cfop-data.js');
  const { ALL_METHOD_CASES, TWO_LOOK_CASES } = await import('../src/methods-data.js');
  for (const item of [...CFOP_CASES, ...ALL_METHOD_CASES, ...TWO_LOOK_CASES]) {
    const state = applyCubeMoves(createSolvedCube(), invertCubeMoves(item.moves).join(' '));
    const solved = applyCubeMoves(state, item.moves);
    assert.equal(isCubeSolved(solved), true, `${item.id} must return to solved state`);
    assert.equal(countVisibleCubies(state), 26, `${item.id} must render a full 3D cube`);
  }
});

test('V13 visualizer scales its cubie model to the stage and refreshes on viewport resize', async () => {
  const app = await read('src/app.js');
  assert.ok(app.includes('stageWidth * 0.56'));
  assert.ok(app.includes('stageHeight * 0.76'));
  assert.ok(app.includes("window.addEventListener('resize'"));
  assert.ok(app.includes("stage.style.setProperty('--cube-size'"));
});


test('V13 CSS layer animation compensates for the screen Y axis being inverted from cube coordinates', () => {
  assert.equal(getCssTurnAngle({ axis: 'x', turns: 1 }), -90);
  assert.equal(getCssTurnAngle({ axis: 'y', turns: 1 }), 90);
  assert.equal(getCssTurnAngle({ axis: 'z', turns: 1 }), -90);
  assert.equal(getCssTurnAngle({ axis: 'x', turns: -2 }), 180);
});


test('V13 keeps preserve-3d unflattened in idle and case-entry animation styles', async () => {
  const css = await read('styles.css');
  const cubeRule = css.match(/\.viz-cube\s*\{([^}]*)\}/)?.[1] || '';
  const arriveRule = css.match(/@keyframes\s+viz-case-arrive\s*\{([^}]*)\}/)?.[1] || '';
  assert.match(cubeRule, /transform-style:\s*preserve-3d/);
  assert.doesNotMatch(cubeRule, /filter\s*:/);
  assert.doesNotMatch(cubeRule, /opacity\s*:/);
  assert.doesNotMatch(arriveRule, /filter\s*:/);
  assert.doesNotMatch(arriveRule, /opacity\s*:/);
});
