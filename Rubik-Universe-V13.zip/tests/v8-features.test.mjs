import test from 'node:test';
import assert from 'node:assert/strict';
import { CFOP_CASES } from '../src/cfop-data.js';
import { renderCfopCaseDiagram } from '../src/cfop-visuals.js';
import {
  SPECIAL_SCRAMBLE_PUZZLES,
  generateSpecialScramble,
  generatePracticeNxNScramble,
  getPuzzleLabel,
  isNxNPuzzle
} from '../src/multi-scramble.js';
import { readFile } from 'node:fs/promises';
import { generateCubingJsScrambles, getCubingEventCode, getScrambleMethod } from '../src/scramble-generator.js';

const read = relative => readFile(new URL(`../${relative}`, import.meta.url), 'utf8');

test('V8 renders a recognition diagram for all 119 existing V6–V7 CFOP cases', () => {
  assert.equal(CFOP_CASES.length, 119);
  const rendered = CFOP_CASES.map(item => renderCfopCaseDiagram(item));
  assert.ok(rendered.every(markup => markup.includes('<svg') && markup.includes('case-diagram-')));
  assert.ok(rendered.every(markup => !markup.includes('fallback')));
  assert.equal(rendered.filter(markup => markup.includes('case-diagram-f2l')).length, 41);
  assert.equal(rendered.filter(markup => markup.includes('case-diagram-oll')).length, 57);
  assert.equal(rendered.filter(markup => markup.includes('case-diagram-pll')).length, 21);
});

test('F2L, OLL and PLL diagrams use the matching source-style projection', () => {
  const f2l = renderCfopCaseDiagram(CFOP_CASES.find(item => item.type === 'F2L'));
  const oll = renderCfopCaseDiagram(CFOP_CASES.find(item => item.type === 'OLL'));
  const pll = renderCfopCaseDiagram(CFOP_CASES.find(item => item.type === 'PLL'));
  assert.ok(f2l.includes('viewBox="-60 -60 120 120"'));
  assert.ok(f2l.includes('F2L phối cảnh'));
  assert.ok(oll.includes('OLL nhìn từ trên xuống'));
  assert.ok(oll.includes('#f5d90a') && oll.includes('#8b9099'));
  assert.ok(pll.includes('PLL nhìn từ trên xuống'));
});

test('all five special puzzle scramblers produce non-empty event-specific notation', () => {
  assert.equal(SPECIAL_SCRAMBLE_PUZZLES.length, 5);
  for (const { value } of SPECIAL_SCRAMBLE_PUZZLES) {
    for (let sample = 0; sample < 20; sample += 1) {
      const scramble = generateSpecialScramble(value);
      assert.equal(typeof scramble, 'string');
      assert.ok(scramble.trim().length > 0, `${value} returned an empty scramble`);
    }
  }
});

test('Pyraminx and Skewb use face turns with no adjacent repeated faces', () => {
  for (const [puzzle, baseLength] of [['Pyraminx', 10], ['Skewb', 11]]) {
    const scramble = generateSpecialScramble(puzzle).split(/\s+/);
    assert.ok(scramble.length >= baseLength && scramble.length <= baseLength + (puzzle === 'Pyraminx' ? 4 : 0));
    const faces = scramble.slice(0, baseLength).map(token => token[0].toUpperCase());
    assert.ok(faces.every(face => ['U', 'L', 'R', 'B'].includes(face)));
    assert.ok(faces.every((face, index) => index === 0 || face !== faces[index - 1]));
  }
});

test('Megaminx, Square-1 and Clock match the reference notation shapes', () => {
  const mega = generateSpecialScramble('Megaminx').split('\n');
  assert.equal(mega.length, 7);
  assert.ok(mega.every(line => {
    const tokens = line.split(/\s+/);
    return tokens.length === 11 && tokens.slice(0, 10).every(token => /^(R|D)(\+\+|--)$/.test(token)) && /^U'?$/ .test(tokens[10]);
  }));

  const squareOne = generateSpecialScramble('Square-1').split(/\s+/);
  assert.equal(squareOne.length, 20);
  assert.ok(squareOne.every(token => /^\(-?\d+,-?\d+\)\/$/.test(token)));

  const clock = generateSpecialScramble('Clock');
  assert.ok(clock.includes('y2'));
  assert.ok(clock.split(/\s+/).some(token => /^ALL\d+[+-]$/.test(token)));
});

test('NxN event mapping and local fallbacks cover 2x2 through 7x7', () => {
  for (let size = 2; size <= 7; size += 1) {
    const puzzle = `${size}x${size}`;
    assert.equal(isNxNPuzzle(puzzle), true);
    assert.equal(generatePracticeNxNScramble(size).split(/\s+/).length, ({2:12,3:25,4:40,5:60,6:80,7:100})[size]);
    assert.equal(getPuzzleLabel(puzzle), `${size}×${size}`);
  }
  assert.equal(isNxNPuzzle('Pyraminx'), false);
  assert.equal(getPuzzleLabel('Square-1'), 'Square-1');
  assert.throws(() => generateSpecialScramble('8x8'), RangeError);
});

test('V8 pages expose case diagrams and all eleven scramble events', async () => {
  const html = await read('index.html');
  const app = await read('src/app.js');
  const worker = await read('sw.js');
  const css = await read('styles.css');
  for (const puzzle of ['2x2', '3x3', '4x4', '5x5', '6x6', '7x7', 'Pyraminx', 'Skewb', 'Megaminx', 'Square-1', 'Clock']) {
    assert.ok(html.includes(`value="${puzzle}"`), `Missing selector option ${puzzle}`);
  }
  for (const id of ['academy-case-visual', 'trainer-case-visual']) assert.ok(html.includes(`id="${id}"`));
  assert.ok(app.includes('renderCfopCaseDiagram(item, caseMoves(item))'));
  assert.ok(worker.includes('./src/cfop-visuals.js'));
  assert.ok(worker.includes('./src/multi-scramble.js'));
  for (const selector of ['.case-diagram', '.trainer-case-visual', '.academy-case-visual']) assert.ok(css.includes(selector), `Missing diagram style ${selector}`);
});


test('V9 maps all eleven puzzles to cubing.js event codes and correct generation classes', () => {
  const expected = { '2x2':'222', '3x3':'333', '4x4':'444', '5x5':'555', '6x6':'666', '7x7':'777', Pyraminx:'pyram', Skewb:'skewb', Megaminx:'minx', 'Square-1':'sq1', Clock:'clock' };
  for (const [puzzle, code] of Object.entries(expected)) assert.equal(getCubingEventCode(puzzle), code);
  for (const puzzle of ['2x2','3x3','4x4','Pyraminx','Skewb','Square-1','Clock']) assert.equal(getScrambleMethod(puzzle), 'random-state');
  for (const puzzle of ['5x5','6x6','7x7','Megaminx']) assert.equal(getScrambleMethod(puzzle), 'random-moves');
});

test('V9 cubing.js event generator requests event-specific algorithms and caps batch size', async () => {
  const calls = [];
  const fakeModule = { randomScrambleForEvent: async code => { calls.push(code); return { toString: () => `${code} R U` }; } };
  const scrambles = await generateCubingJsScrambles('Pyraminx', 3, async () => fakeModule);
  assert.deepEqual(calls, ['pyram','pyram','pyram']);
  assert.equal(scrambles.length, 3);
  assert.ok(scrambles.every(value => value === 'pyram R U'));
  await assert.rejects(() => generateCubingJsScrambles('Mirror Cube', 1, async () => fakeModule), RangeError);
});

test('V9 academy exposes Cross/F2L practice logs, puzzle analytics filter and cache invalidation', async () => {
  const html = await read('index.html');
  const app = await read('src/app.js');
  const core = await read('src/core.js');
  const sw = await read('sw.js');
  assert.ok(html.includes('id="cfop-cross-save"'));
  assert.ok(html.includes('id="cfop-f2l-save"'));
  assert.ok(html.includes('id="stats-puzzle-filter"'));
  assert.ok(app.includes('function saveCrossPractice()'));
  assert.ok(app.includes('function saveF2LPractice()'));
  assert.ok(core.includes('cfopPractice: normalizeCfopPractice(parsed.cfopPractice)'));
  assert.ok(sw.includes('rubik-universe-v13-0'));
});
