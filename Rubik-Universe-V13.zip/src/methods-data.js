import { PLL_CASES } from './cfop-data.js';

const methodCase = (id, type, name, stage, moves, recognition, grip, tips, extra = {}) => ({
  id, type, name, stage, moves, recognition, grip, tips, mistakes: extra.mistakes || 'Giữ đúng hướng cầm đã nêu; kiểm tra lại trạng thái sau khi chạy công thức.',
  family: extra.family || stage, diagramType: extra.diagramType || type, source: extra.source || '',
  ...extra
});

export const BEGINNER_STAGES = [
  { id:'cross', name:'Bước 1 · Dấu cộng trắng', kind:'intuitive', description:'Chọn tâm trắng làm đáy, ghép bốn cạnh trắng với đúng tâm màu bên cạnh. Kiểm tra cả màu bên trước khi đưa cạnh vào dấu cộng.', recognition:'Bốn cạnh trắng phải tạo dấu cộng quanh tâm trắng; mỗi cạnh đồng thời khớp màu với tâm ở mặt bên.', grip:'Giữ mặt trắng ở dưới (D), màu bên đã chọn hướng ra trước (F).', tips:'Lập kế hoạch ít nhất 2 cạnh trong Inspection; ưu tiên đưa cạnh vào D mà không phá cạnh đã đúng; không chỉ nhìn mặt trắng mà quên căn màu cạnh.' },
  { id:'corners', name:'Bước 2 · Bốn góc tầng đầu', kind:'algorithm', description:'Đưa từng góc có sticker trắng vào đúng khe giữa ba tâm tương ứng.', recognition:'Tìm góc trắng ở tầng trên, xác định hai màu bên của góc rồi đưa nó lên ngay phía trên khe đích.', grip:'Trắng ở dưới; khe đích ở trước-phải (FR).', tips:'Dùng trigger phải R U R\' U\' lặp đúng số lần để xoay góc; chỉ xoay U để chuyển góc kế tiếp. Không xoay cả khối liên tục.' },
  { id:'middle', name:'Bước 3 · Tầng giữa', kind:'algorithm', description:'Chèn bốn cạnh không có màu vàng từ tầng trên vào khe trái hoặc phải.', recognition:'Chọn cạnh trên không có vàng; căn màu cạnh trước với tâm trước. Màu còn lại cho biết chèn sang phải hay trái.', grip:'Trắng ở dưới, vàng ở trên; cạnh cần chèn ở vị trí UF.', tips:'Tách công thức thành hai trigger ngắn; nhớ cạnh phải và cạnh trái là hai trường hợp đối xứng. Nếu cạnh đang ở sai khe, đẩy nó ra trước rồi chèn lại.' },
  { id:'yellow-cross', name:'Bước 4 · Dấu cộng vàng', kind:'algorithm', description:'Định hướng bốn cạnh vàng trên mặt U, chưa cần khớp màu cạnh bên.', recognition:'Nhận dạng chấm, chữ L hoặc đường thẳng vàng trên U.', grip:'Vàng ở trên. Đường thẳng nằm ngang; chữ L đặt ở góc sau-trái trước khi chạy công thức.', tips:'Không đổi hướng cube giữa công thức. Với mẫu chấm, chạy bước tạo hình L trước rồi quan sát lại; với chữ L chọn case L riêng, sau đó xử lý đường thẳng.' },
  { id:'yellow-edges', name:'Bước 5 · Khớp cạnh vàng', kind:'algorithm', description:'Xoay U và hoán vị các cạnh tầng cuối để màu bên trùng tâm.', recognition:'Dấu cộng vàng đã có nhưng các cạnh vàng chưa khớp tâm bên; tìm cặp cạnh đã đúng.', grip:'Vàng ở trên; nếu có hai cạnh kề đúng, đặt chúng ở sau và phải.', tips:'Phân biệt trường hợp không có cạnh nào khớp và trường hợp có một cặp kề khớp; căn U trước khi chạy.' },
  { id:'corner-position', name:'Bước 6 · Đặt đúng vị trí góc vàng', kind:'algorithm', description:'Đưa bốn góc vàng về đúng vị trí theo ba màu, dù sticker vàng chưa hướng lên.', recognition:'Một góc đúng vị trí khi ba màu của nó thuộc đúng ba tâm xung quanh, không phụ thuộc hướng xoay.', grip:'Vàng ở trên; giữ một góc đã đúng tại UFR. Nếu chưa có góc nào đúng, chạy một lần từ góc bất kỳ.', tips:'Đừng nhầm “đúng vị trí” với “đúng hướng”. Khối có thể trông rối tạm thời; hoàn tất cả chuỗi trước khi đánh giá.' },
  { id:'corner-orientation', name:'Bước 7 · Xoay góc vàng', kind:'algorithm', description:'Xoay từng góc tại UFR để sticker vàng hướng lên, giữ nguyên các tầng đã giải.', recognition:'Đưa một góc có sticker vàng quay ngang lên vị trí UFR; lặp trigger cho đến khi vàng hướng lên.', grip:'Vàng ở trên; góc cần xoay ở UFR. Chỉ xoay U để đưa góc tiếp theo vào UFR.', tips:'Trong lúc xoay, hai tầng dưới nhìn có thể bị xáo trộn; không xoay cả khối và không dừng giữa trigger. Hoàn thành đủ bốn move R\' D\' R D.' }
];

export const BEGINNER_CASES = [
  methodCase('BEGINNER-CORNER','BEGINNER','Góc trắng · Trigger phải','corners',"R U R' U'",'Góc trắng nằm ở tầng trên; đưa góc tới UFR, ngay trên khe đích. Xem mặt trắng của góc đang hướng sang phải, lên trên hay ra trước.','Trắng ở dưới; khe đích tại FR.','Lặp trigger đến khi góc vào đúng khe. Giữa các góc chỉ xoay U; nếu sticker trắng quay ra trước hoặc lên trên, tiếp tục đủ chu kỳ rồi kiểm tra lại.',{source:'Yasin Alev · Beginner algorithms',diagramType:'BEGINNER'}),
  methodCase('BEGINNER-MIDDLE-R','BEGINNER','Cạnh giữa · Chèn phải','middle',"U R U' R' U' F' U F",'Cạnh UF không có vàng; màu mặt trước khớp tâm F, màu còn lại khớp tâm R.','Trắng dưới, vàng trên; cạnh cần chèn ở UF.','Tách thành U R U\' R\' và U\' F\' U F. Đưa cạnh đến đúng vị trí trước khi chèn.',{source:'Yasin Alev · Beginner algorithms',diagramType:'BEGINNER'}),
  methodCase('BEGINNER-MIDDLE-L','BEGINNER','Cạnh giữa · Chèn trái','middle',"U' L' U L U F U' F'",'Cạnh UF không có vàng; màu mặt trước khớp tâm F, màu còn lại khớp tâm L.','Trắng dưới, vàng trên; cạnh cần chèn ở UF.','Đây là ảnh gương của chèn phải. Tách thành U\' L\' U L và U F U\' F\'.', {source:'Yasin Alev · Beginner algorithms',diagramType:'BEGINNER'}),
  methodCase('BEGINNER-YELLOW-CROSS','BEGINNER','Dấu cộng vàng','yellow-cross',"F R U R' U' F'",'Hai cạnh vàng hướng lên tạo thành một đường thẳng trên mặt U; căn đường thẳng nằm ngang.','Vàng ở trên; đường thẳng nằm ngang từ trái sang phải.','Nhớ khối F ở đầu và cuối; phần giữa là trigger phải. Quan sát lại sau mỗi lần chạy.',{source:'Yasin Alev · Beginner algorithms',diagramType:'OLL'}),
  methodCase('BEGINNER-YELLOW-CROSS-L','BEGINNER','Dấu cộng vàng · Chữ L','yellow-cross',"F U R U' R' F'",'Hai cạnh vàng hướng lên tạo góc vuông trên mặt U. Đặt mẫu chữ L ở góc sau-trái theo hướng dẫn hình trước khi chạy.','Vàng ở trên; hai cạnh vàng hướng lên nằm phía sau và trái.','Nếu ban đầu là chấm, áp dụng công thức tạo L rồi quan sát lại; nếu là đường thẳng, dùng công thức đường thẳng. Sau mỗi lần chạy phải kiểm tra lại pattern thay vì lặp máy móc.',{source:'HCubist · 2-Look OLL edge cases',diagramType:'OLL'}),
  methodCase('BEGINNER-YELLOW-EDGES','BEGINNER','Hoán vị cạnh vàng','yellow-edges',"R U R' U R U2 R' U",'Dấu cộng vàng đã hoàn tất; hai cạnh bên liền kề có thể cùng khớp tâm.','Vàng trên; đặt cặp cạnh kề khớp ở sau và phải.','Tách công thức thành hai nửa tương tự; đếm U2 đủ hai nhịp.',{source:'Yasin Alev · Beginner algorithms',diagramType:'PLL'}),
  methodCase('BEGINNER-CORNER-POSITION','BEGINNER','Đặt vị trí góc vàng','corner-position',"U R U' L' U R' U' L",'Tìm góc đã nằm đúng vị trí bằng cách đối chiếu ba màu của nó với ba tâm, không xét hướng sticker.','Vàng trên; một góc đúng ở UFR.','Nếu chưa có góc đúng, chạy một lần rồi tìm lại. Đừng dừng giữa công thức dù tầng giữa tạm thời bị xáo trộn.',{source:'Yasin Alev · Beginner algorithms',diagramType:'PLL'}),
  methodCase('BEGINNER-CORNER-TWIST','BEGINNER','Xoay góc vàng','corner-orientation',"R' D' R D",'Góc UFR có sticker vàng quay ngang; cần xoay tại chỗ cho vàng hướng lên.','Vàng trên; góc đang xử lý ở UFR.','Lặp nguyên trigger 2 hoặc 4 lần đến khi vàng hướng lên; chỉ xoay U để chuyển góc kế tiếp. Không xoay cả cube.',{source:'Yasin Alev · Beginner algorithms',diagramType:'BEGINNER'})
];

const cmllRaw = [
 ['O','O Adjacent',"R U R' F' R U R' U' R' F R2 U' R'"],
 ['O','O Diagonal',"F R U' R' U' R U R' F' R U R' U' R' F R F'"],
 ['H','H Columns',"U R U R' U R U' R' U R U2 R'"],
 ['H','H Rows',"F R U R' U' R U R' U' R U R' U' F'"],
 ['H','H Column',"R' F2 D R2 U R2 D' F2 R"],
 ['H','H Row',"U2 r U' r2 D' r U' r' D r2 U r'"],
 ['Pi','Pi Right Bar',"F R U R' U' R U R' U' F'"],
 ['Pi','Pi Down Slash',"U F R' F' R U2 R U' R' U R U2 R'"],
 ['Pi','Pi X',"R' F2 D R2 U' R2 D' F2 R"],
 ['Pi','Pi Up Slash',"R U2 R' U' R U R' U2 R' F R F'"],
 ['Pi','Pi Columns',"U' r U' r2 D' r U r' D r2 U r'"],
 ['Pi','Pi Left Bar',"U' R' U' R' F R F' R U' R' U2 R"],
 ['U','U Up Slash',"U2 R2 D R' U2 R D' R' U2 R'"],
 ['U','U Down Slash',"R2 D' R U2 R' D R U2 R"],
 ['U','U Bottom Row',"R' U' R U' R' U2 R2 U R' U R U2 R'"],
 ['U','U Rows',"U' F R2 D R' U R D' R2 U' F'"],
 ['U','U X',"U2 r U' r' U r' D' r U' r' D r"],
 ['U','U Upper Row',"U' F R U R' U' F'"],
 ['T','T Left Bar',"U' R U R' U' R' F R F'"],
 ['T','T Right Bar',"U L' U' L U L F' L' F"],
 ['T','T Rows',"R U2 R' U' R U' R2 U2 R U R' U R"],
 ['T','T Bottom Row',"r' U r U2 R2 F R F' R"],
 ['T','T Top Row',"r' D' r U r' D r U' r U r'"],
 ['T','T Columns',"U2 r U' r2 D' r U2 r' D r2 U r'"],
 ['Sune','Sune Left Bar',"U R U R' U R U2 R'"],
 ['Sune','Sune X',"U L' U2 L U2 r U' r' F"],
 ['Sune','Sune Up Slash',"U F R' F' R U2 R U2 R'"],
 ['Sune','Sune Columns',"U R U R' U' R' F R F' R U R' U R U2 R'"],
 ['Sune','Sune Right Bar',"U' R U R' U R' F R F' R U2 R'"],
 ['Sune','Sune Down Slash',"U r U' r' F R' F' R"],
 ['Anti-Sune','Anti-Sune Right Bar',"U R' U' R U' R' U2 R"],
 ['Anti-Sune','Anti-Sune Columns',"U2 R U R2 F' r F R U' r2 F r"],
 ['Anti-Sune','Anti-Sune Down Slash',"U' F' L F L' U2 L' U2 L"],
 ['Anti-Sune','Anti-Sune X',"U' R U2 R' U2 R' F R F'"],
 ['Anti-Sune','Anti-Sune Up Slash',"U' R' F R F' r U r'"],
 ['Anti-Sune','Anti-Sune Left Bar',"U R U2 R' F R' F' R U' R U' R'"],
 ['L','L Best',"U' F' r U r' U' r' F r"],
 ['L','L Good',"U2 F R' F' R U R U' R'"],
 ['L','L Pure',"R U R' U R U' R' U R U' R' U R U2 R'"],
 ['L','L Front Commutator',"U2 R U2 R D R' U2 R D' R2"],
 ['L','L Diagonal',"U2 R U2 R2 F R F' R U2 R'"],
 ['L','L Back Commutator',"U R' U2 R' D' R U2 R' D R2"]
];
export const ROUX_CMLL_CASES = cmllRaw.map(([group, name, moves], index) => methodCase(
  `ROUX-CMLL-${String(index + 1).padStart(2,'0')}`, 'CMLL', name, 'cmll', moves,
  `Nhìn bốn góc tầng U theo mẫu ${group}; bỏ qua hoàn toàn sticker cạnh ở bước CMLL. Dùng hình minh họa để xác định hướng mẫu và xoay U căn chỉnh trước khi chạy.`,
  'Hai block Roux đã hoàn tất; U ở trên. Giữ nguyên hướng trước/trái của hai block, chỉ AUF bằng U trước khi chạy.',
  'CMLL chỉ giải bốn góc tầng cuối, không cần quan tâm cạnh tầng U. Học một công thức chính cho mỗi hình trước; luyện nhận diện khi xoay U 0/1/2/3 lần.',
  { family:group, diagramType:'CMLL', source:'HCubist · CMLL 42 cases', mistakes:'Không cố giải cạnh tầng U bằng CMLL; cạnh được xử lý ở LSE. Không đổi hướng cube giữa nhận diện và thực hiện.' }
));

const lseRaw = [
 ['EO · 2 cạnh lật','D-Line · DF và DB lật',"M' U M' U' M U M"],
 ['EO · 2 cạnh lật','Front One · U edge và DF',"M U' M' U' M'"],
 ['EO · 2 cạnh lật','Back One · U edge và DB',"M' U' M U' M'"],
 ['EO · 2 cạnh lật','V Two · hai cạnh kề',"M' U' M' U' M'"],
 ['EO · 2 cạnh lật','U-Line Two · hai cạnh đối',"M' U M U' M' U' M'"],
 ['EO · 4 cạnh lật','V + D-Line',"M2 U' M' U M'"],
 ['EO · 4 cạnh lật','(U+D)-Line',"M'"],
 ['EO · 4 cạnh lật','F Arrow',"M' U M'"],
 ['EO · 4 cạnh lật','B Arrow',"M U' M'"],
 ['EO · 4 cạnh lật','Cross',"M2 U' M'"],
 ['EO · 6 cạnh lật','Flip All',"M' U' M' U M U' M' U' M'"],
 ['LSE · Permutation','3-Cycle clockwise',"U2 M' U2 M"],
 ['LSE · Permutation','3-Cycle counterclockwise',"M' U2 M U2"],
 ['LSE · Permutation','H Perm',"M2 U2 M2 U2"],
 ['LSE · Permutation','Dots',"M' E2 M E2"]
];
export const ROUX_LSE_CASES = lseRaw.map(([family, name, moves], index) => methodCase(
  `ROUX-LSE-${String(index + 1).padStart(2,'0')}`, 'LSE', name, family.startsWith('EO') ? 'lse-eo' : 'lse-perm', moves,
  index < 11 ? `Nhìn sáu cạnh còn lại (UL, UR, UF, UB, DF, DB) sau CMLL; phân nhóm ${family}. Các hình edge-only sẽ tô nổi sticker cần xét.` : `Sau khi sáu cạnh đã định hướng và UL/UR đã đúng, nhận diện hoán vị M-slice: ${name}.`,
  'Giữ hai block trái/phải đã giải; M là lát giữa, U là mặt trên. Không xoay cả khối khi chạy chuỗi.',
  index < 11 ? 'Chỉ dùng M và U; kiểm tra hướng cạnh theo mặt F/B trước khi chọn case. Căn U nhẹ trước công thức nếu mẫu đã đúng nhưng lệch vị trí.' : 'LSE kết thúc bằng các move M/U; giữ UL và UR làm chuẩn. Đếm đủ nhịp M2 và U2.',
  { family, diagramType:'LSE', source:'HCubist · LSE 15 cases', mistakes:'Không dùng quy ước M ngược chiều tùy ý; hướng M ở đây theo ký hiệu chuẩn. Nếu áp dụng M ngược chiều do cách cầm, phải đổi cả công thức tương ứng.' }
));

const twoLookOll = [
 ['2LOLL-EDGE-LINE','Cạnh · Đường thẳng','F R U R\' U\' F\'','Có hai sticker U tạo đường thẳng trên mặt U. Giữ đường thẳng ngang.'],
 ['2LOLL-EDGE-ANGLE','Cạnh · Chữ L','F U R U\' R\' F\'','Hai cạnh vàng tạo góc vuông trên mặt U. Giữ mẫu ở góc sau-trái.'],
 ['2LOLL-EDGE-DOT','Cạnh · Chấm','R U\' R2 D\' r U r\' D R2 U R\'','Không có cạnh U nào hướng lên; đây là mẫu chấm.'],
 ['2LOLL-CORNER-SUNE','Góc · Sune (OLL 27)',"R U R' U R U2 R'",'Dấu cộng vàng đã hoàn thành; có ba góc cần xoay theo dạng Sune.'],
 ['2LOLL-CORNER-ANTISUNE','Góc · Anti-Sune (OLL 26)',"R' U' R U' R' U2 R",'Dấu cộng vàng đã hoàn thành; nhận diện mẫu đối xứng với Sune.'],
 ['2LOLL-CORNER-H','Góc · H (OLL 21)',"R U R' U R U' R' U R U2 R'",'Dấu cộng vàng đã hoàn thành; không có góc vàng hướng lên.'],
 ['2LOLL-CORNER-PI','Góc · Pi (OLL 22)',"R U2 R2 U' R2 U' R2 U2 R",'Dấu cộng vàng đã hoàn thành; nhìn cặp góc vàng và thanh màu bên để nhận diện Pi.'],
 ['2LOLL-CORNER-U','Góc · U (OLL 23)',"R2 D' R U2 R' D R U2 R",'Dấu cộng vàng đã hoàn thành; mẫu góc thuộc nhóm U.'],
 ['2LOLL-CORNER-T','Góc · T (OLL 24)',"Rw U R' U' Rw' F R F'",'Dấu cộng vàng đã hoàn thành; nhận diện mẫu T theo sticker vàng và màu bên.'],
 ['2LOLL-CORNER-L','Góc · L (OLL 25)',"F R' F' Rw U R U' Rw'",'Dấu cộng vàng đã hoàn thành; nhận diện mẫu L theo hình sticker vàng trên U.']
];
export const TWO_LOOK_OLL_CASES = twoLookOll.map(([id,name,moves,recognition], index) => methodCase(id,'2-LOOK OLL',name,index < 3 ? 'edge-orientation' : 'corner-orientation',moves,recognition,'Vàng ở trên; đặt đường thẳng/chữ L đúng hướng theo nhận diện.','2-Look OLL có hai lượt: orient edges thành dấu cộng, sau đó orient corners. Không nhầm bước 1 với hoán vị vị trí.',{ diagramType:'OLL', source:'HCubist · 2-Look OLL 10 cases' }));

const twoLookPll = [
 ['2LPLL-CORNER-ADJ','Góc · Hoán vị kề (Headlights)',"R U R' U' R' F R2 U' R' U' R U R' F'",'Có hai góc cùng màu bên tạo headlights ở một mặt. Đưa cặp đó ra sau.'],
 ['2LPLL-CORNER-DIAG','Góc · Hoán vị chéo',"F R U' R' U' R U R' F' R U R' U' R' F R F'",'Không có headlights trên các mặt bên; dùng trường hợp đổi chéo góc.'],
 ['2LPLL-EDGE-UA','Cạnh · Ua',"R U' R U R U R U' R' U' R2",'Các góc đã đúng; ba cạnh tầng U chạy theo chiều Ua. Căn U để xác định mặt lùi.'],
 ['2LPLL-EDGE-UB','Cạnh · Ub',"R2 U R U R' U' R' U' R' U R'",'Các góc đã đúng; ba cạnh tầng U chạy theo chiều ngược Ub.'],
 ['2LPLL-EDGE-H','Cạnh · H',"M2 U M2 U2 M2 U M2",'Hai cặp cạnh đối diện cần đổi; không có cạnh bên nào hoàn toàn khớp theo kiểu Ua/Ub.'],
 ['2LPLL-EDGE-Z','Cạnh · Z',"M' U M2 U M2 U M' U2 M2 U'",'Hai cặp cạnh kề cần đổi theo mẫu Z; dùng màu cạnh để phân biệt với H.']
];
export const TWO_LOOK_PLL_CASES = twoLookPll.map(([id,name,moves,recognition]) => methodCase(id,'2-LOOK PLL',name,name.startsWith('Góc')?'corner-permutation':'edge-permutation',moves,recognition,'Vàng ở trên; trước khi thực hiện, xoay U để căn mẫu theo mặt trước.','2-Look PLL giải góc trước, cạnh sau. Khi góc đã đúng thì giữ định hướng cube ổn định; kiểm tra side colors sau công thức.',{ diagramType:'PLL', source:'HCubist · 2-Look PLL 6 cases' }));

// ZZ/Petrus two-step last layer uses the seven OCLL cases, not arbitrary OLL 21–27 labels.
// Reuse the canonical 2-Look OLL corner set so recognition, names and algorithms stay aligned.
const ocllCases = TWO_LOOK_OLL_CASES.slice(3).map((item, index) => methodCase(
  `OCLL-${index + 1}`, 'OCLL', item.name.replace(/^Góc · /, 'OCLL · '), 'ocll', item.moves,
  `${item.recognition} Với ZZ/Petrus, EO đã được giải từ trước nên chỉ cần định hướng góc.`,
  'Giữ EO hoàn thành; U ở trên. AUF để mẫu góc trùng đúng hướng minh họa.',
  'Giữ edge orientation trong toàn bộ công thức. Xong OCLL thì bốn góc hướng đúng nhưng vị trí các góc/cạnh chưa nhất thiết hoàn tất.',
  { diagramType:'OCLL', source:'HCubist · 2-Look OLL corner orientation set', family:'OCLL 7 cases', mistakes:'Không dùng OCLL nếu các cạnh chưa được định hướng. Kiểm tra EO trước và sau công thức.' }
));
const pllCases = PLL_CASES.map(item => methodCase(
  `LL-${item.id}`, 'PLL', item.name, 'pll', item.moves,
  `Sau khi mặt trên đã đồng màu và các cạnh đã định hướng, nhận diện hoán vị bằng màu các miếng ở bốn mặt bên. Case tham chiếu ${item.name}.`,
  'Mặt trên hướng lên; thực hiện AUF để đưa case về đúng hướng nhận diện.',
  'Nhìn màu cạnh trước khi chọn algorithm; dùng fingertrick quen thuộc và kiểm tra cả góc lẫn cạnh sau khi chạy.',
  { diagramType:'PLL', source:'CFOP PLL standard 21 cases reused for alternate method last layers', family:'PLL 21 cases' }
));

export const ZZ_CASES = [...ocllCases.map(item => ({...item,id:`ZZ-${item.id}`})), ...pllCases.map(item => ({...item,id:`ZZ-${item.id}`}))];
export const PETRUS_CASES = [...ocllCases.map(item => ({...item,id:`PETRUS-${item.id}`})), ...pllCases.map(item => ({...item,id:`PETRUS-${item.id}`}))];

export const METHOD_LIBRARIES = {
  beginner: {
    id:'beginner', name:'Beginner chuẩn', short:'Beginner', tagline:'Layer-by-layer · học giải Rubik từ nền tảng', description:'Phương pháp giải từng tầng theo thứ tự: dấu cộng trắng, góc tầng đầu, tầng giữa, rồi tầng cuối vàng. Các bước Cross và ghép tầng đầu mang tính trực quan; tám công thức cốt lõi được liệt kê thành case riêng.',
    cases:BEGINNER_CASES, stages:BEGINNER_STAGES,
    pros:['Dễ tiếp cận, ít thuật toán phải học thuộc và giúp hiểu cấu trúc từng tầng.','Có thể bắt đầu giải khối ngay khi nắm được ký hiệu và ghép cạnh/góc.'], cons:['Thời gian giải thường dài hơn các phương pháp speedsolving nâng cao.','Dễ phát sinh thao tác thừa nếu giải từng miếng mà không lập kế hoạch trước.'],
    learningTips:['Cố định trắng dưới và vàng trên sau khi hoàn thành dấu cộng trắng.','Nhìn màu bên để xác định khe, không dựa vào sticker trên cùng.','Học từng trigger thành nhịp nhỏ, sau đó nối thành công thức.','Khi xoay góc cuối, không xoay toàn bộ cube giữa các lần lặp.'],
    sources:['https://rubiks.yasinalev.com/en/algorithms/']
  },
  roux: {
    id:'roux', name:'Roux chuẩn', short:'Roux', tagline:'Blockbuilding · CMLL · Last Six Edges', description:'Roux giải hai block 1×2×3 ở hai bên, sau đó CMLL giải bốn góc tầng cuối và LSE hoàn tất sáu cạnh còn lại. CMLL có đủ 42 trường hợp; LSE được tổ chức thành 11 case định hướng cạnh và 4 case hoán vị cuối.',
    cases:[...ROUX_CMLL_CASES,...ROUX_LSE_CASES], stages:[
      {id:'fb',name:'Bước 1 · First Block',kind:'intuitive',description:'Dựng block 1×2×3 bên trái, gồm hai góc tầng đầu, cạnh tầng giữa và cạnh tương ứng; không phá block khi mở rộng.',recognition:'Theo dõi một block 1×2×3 liên tục ở bên trái; cần giải cả vị trí lẫn hướng sticker, không chỉ ghép màu mặt.',grip:'Chọn mặt U và mặt trước nhất quán; ưu tiên xoay block về phía trái để giữ không gian làm Second Block.',tips:'Tìm cặp góc-cạnh trước; tránh rotation thừa; lập kế hoạch một phần block trong inspection.'},
      {id:'sb',name:'Bước 2 · Second Block',kind:'intuitive',description:'Dựng block 1×2×3 bên phải mà không phá First Block. Các miếng cuối có thể xử lý bằng insertion từ U hoặc D.',recognition:'Nhìn các vị trí chưa giải ở bên phải; ưu tiên ghép cặp góc-cạnh và đưa vào block theo cách không chạm block trái.',grip:'Giữ First Block ở bên trái và vùng thao tác ở bên phải.',tips:'Tập trung blockbuilding thay vì nghĩ theo tầng; giảm U-turn không cần thiết và học nhận diện cặp từ nhiều góc.'},
      {id:'cmll',name:'Bước 3 · CMLL',kind:'algorithm',description:'Giải đồng thời bốn góc tầng cuối bằng một algorithm; cạnh tầng U được bỏ qua và sẽ giải ở LSE.',recognition:'Nhận dạng 1 trong 42 mẫu góc thuộc O, H, Pi, U, T, Sune, Anti-Sune hoặc L.',grip:'Hai block hoàn chỉnh, U ở trên; giữ hai block không đổi hướng.',tips:'Học theo nhóm shape; sử dụng AUF trước khi chạy; cạnh tầng trên không cần khớp ở bước này.'},
      {id:'lse',name:'Bước 4 · Last Six Edges',kind:'overview',description:'LSE hoàn tất sáu cạnh còn lại sau CMLL. Học theo hai pha: 11 mẫu định hướng cạnh rồi 4 mẫu hoán vị cuối.',recognition:'Quan sát UL, UR, UF, UB, DF và DB; xác định cạnh nào chưa oriented trước, sau đó mới phân tích vị trí.',grip:'Hai block đã giải; giữ U ở trên, thao tác lát giữa M và mặt U.',tips:'Tách EO khỏi permutation để tránh chọn nhầm case; giữ nguyên hướng cầm và quy ước M xuyên suốt.'},
      {id:'lse-eo',name:'Bước 4a · LSE Edge Orientation',kind:'algorithm',description:'Định hướng sáu cạnh còn lại của Roux bằng 11 trường hợp EO. Hình minh họa chỉ nhấn mạnh sticker cạnh liên quan.',recognition:'Nhận dạng số lượng và vị trí cạnh bị lật trong nhóm UL, UR, UF, UB, DF, DB.',grip:'Hai block đã giải; U ở trên, M là lát giữa. Giữ block cố định.',tips:'Chỉ bắt đầu sau CMLL; xác định đúng chiều M theo ký hiệu chuẩn; luyện từng mẫu bằng M/U.'},
      {id:'lse-perm',name:'Bước 4b · LSE Permutation',kind:'algorithm',description:'Hoán vị sáu cạnh đã định hướng. Bốn trường hợp thư viện gồm 3-cycle theo hai chiều, H-perm và Dots.',recognition:'EO đã hoàn tất; dùng vị trí các cạnh so với tâm và hai block để nhận dạng chu kỳ hoán vị.',grip:'Giữ hai block; dùng M/U theo cùng một hướng cầm xuyên suốt.',tips:'Kiểm tra UL/UR trước khi chạy; học sự khác nhau giữa 3-cycle hai chiều và H-perm; kết thúc kiểm tra cả sáu cạnh.'}
    ], pros:['Không cần Cross/F2L theo từng slot; blockbuilding linh hoạt và có thể giảm số move.','CMLL và LSE có các bộ case tương đối gọn, M-slice hiệu quả.'], cons:['Blockbuilding và nhận diện CMLL khó với người mới.','LSE đòi hỏi điều khiển M-slice chính xác và giữ hướng hai block.'],
    learningTips:['Roux dựa nhiều vào blockbuilding trực quan hơn là ghi nhớ algorithm.','Đừng quan tâm vị trí cạnh tầng U khi làm CMLL.','LSE có quy tắc riêng: EO trước, permutation sau; giữ UL/UR chuẩn khi vào bước cuối.','M-slice phải đều nhịp và chính xác.'], sources:['https://hcubist.com/learn/algorithms/cmll/','https://hcubist.com/learn/algorithms/lse/']
  },
  zz: {
    id:'zz', name:'ZZ chuẩn', short:'ZZ', tagline:'Edge Orientation · Rotationless F2L · Last Layer', description:'ZZ định hướng cạnh ngay từ đầu bằng EOCross (hoặc EOLine), hoàn thiện hai tầng chỉ bằng R/U/L/D mà không xoay cube, rồi giải Last Layer. Thư viện có đủ bộ OCLL 7 + PLL 21 cho lối hai bước.',
    cases:ZZ_CASES, stages:[
      {id:'eo',name:'Bước 1 · EOCross / EOLine',kind:'intuitive',description:'Định hướng cả 12 cạnh; đồng thời giải Cross (EOCross) hoặc giải EO cùng hai cạnh DF/DB tạo line (EOLine).',recognition:'Phân biệt cạnh oriented theo quy ước ZZ; mục tiêu là sau bước này có thể giải phần còn lại mà không cần F/B turns.',grip:'Chọn trục U/D rõ ràng; EOCross là lựa chọn tiện cho hai tay, EOLine là biến thể line.',tips:'EO là kỹ năng nhận diện, không có một danh sách algorithm hữu hạn duy nhất. Luyện EO line theo từng cặp cạnh, sau đó gắn Cross vào kế hoạch inspection.'},
      {id:'zzf2l',name:'Bước 2 · ZZF2L',kind:'intuitive',description:'Hoàn thành First Two Layers bằng cách ghép và chèn cặp, chủ yếu chỉ dùng R, U, L, D; không rotation.',recognition:'Sau EO, các cạnh đã định hướng; quan sát cặp góc-cạnh và tạo slot bằng mặt R/L.',grip:'Giữ D cố định; tránh xoay cả cube. R/U/L/D là các move chính.',tips:'Dùng lookahead từ EO sang F2L; hạn chế F/B để giữ edge orientation; luyện block và pair insertion.'},
      {id:'ocll',name:'Bước 3 · OCLL',kind:'algorithm',description:'Với EO đã đúng, định hướng bốn góc tầng cuối bằng 1 trong 7 OCLL algorithms.',recognition:'Nhận dạng một trong bảy pattern góc: Sune, Anti-Sune, H, Pi, U, T hoặc L.',grip:'U ở trên; AUF để case khớp hình minh họa.',tips:'Giữ edge orientation suốt thuật toán. Nếu cạnh bị lật, kiểm tra lại cách chọn OCLL và hướng cầm.'},
      {id:'pll',name:'Bước 4 · PLL',kind:'algorithm',description:'Hoán vị các miếng tầng cuối bằng đầy đủ 21 trường hợp PLL, dùng chung bộ công thức tham chiếu CFOP.',recognition:'Mặt U đã đồng màu; so màu side stickers để xác định permutation.',grip:'U ở trên; dùng AUF trước và sau algorithm.',tips:'Học nhóm corner permutation và edge permutation; nhận diện headlights, bars và các chuỗi màu cạnh.'}
    ], pros:['EO sớm giúp giảm rotation và cho phép giải ZZF2L chủ yếu bằng R/U/L/D.','Có thể chọn lối hoàn tất hai bước OCLL+PLL hoặc học LL nâng cao về sau.'], cons:['EO đầu solve cần nhận diện tốt và có thể làm inspection khó hơn.','Phải giữ edge orientation xuyên suốt ZZF2L, hạn chế F/B turns.'],
    learningTips:['EO là nền tảng của ZZ: phải giữ các cạnh oriented trong ZZF2L.','Chọn EOCross cho lối hai tay phổ biến; EOLine là biến thể hợp lệ.','ZZF2L chủ yếu dùng R/U/L/D và giảm rotation.','Lựa chọn Last Layer trong V11 là OCLL+PLL (28 algorithms); ZBLL là bộ nâng cao riêng, không được giả vờ có đủ nếu chưa nhập 493 case.'], sources:['https://bradleykh.github.io/CubeTools/guides/methods/','https://github.com/crystalcuber/zz-method-docs']
  },
  petrus: {
    id:'petrus', name:'Petrus chuẩn', short:'Petrus', tagline:'Blockbuilding · Edge Orientation · Last Layer', description:'Petrus xây block 2×2×2, mở rộng thành 2×2×3, định hướng các cạnh còn lại, hoàn thiện F2L và giải Last Layer. Các bước đầu là blockbuilding trực quan; bộ Last Layer hai bước có OCLL 7 + PLL 21.',
    cases:PETRUS_CASES, stages:[
      {id:'222',name:'Bước 1 · Block 2×2×2',kind:'intuitive',description:'Tạo một khối 2×2×2 ở bất kỳ góc nào, ưu tiên chọn block có thể mở rộng tự nhiên.',recognition:'Theo dõi 8 cubies tạo thành thể tích 2×2×2 liền nhau, kiểm tra cả góc và cạnh.',grip:'Không bắt buộc mặt màu cố định; chọn hướng block thuận tiện.',tips:'Tối ưu block bằng cách ghép góc-cạnh trước; tránh giải từng mặt độc lập.'},
      {id:'223',name:'Bước 2 · Mở rộng 2×2×3',kind:'intuitive',description:'Mở block 2×2×2 thành block 2×2×3 bằng cách giải thêm một lớp/cạnh liền kề.',recognition:'Một mặt của block cần được mở rộng mà không phá 2×2×2 đã có.',grip:'Giữ block đã dựng ở vị trí dễ thao tác; hạn chế rotation.',tips:'Dự đoán cạnh tiếp theo và bảo toàn block; chú ý khoảng trống để chèn miếng.'},
      {id:'eo',name:'Bước 3 · Edge Orientation',kind:'intuitive',description:'Định hướng các cạnh chưa oriented để có thể hoàn thiện phần còn lại bằng ít mặt hơn.',recognition:'Kiểm tra orientation của các cạnh tự do sau block 2×2×3.',grip:'Giữ block đã dựng ổn định; xác định quy ước oriented trước khi bắt đầu.',tips:'Petrus EO là bước nhận diện và xử lý trực quan; không có bộ algorithm cố định duy nhất.'},
      {id:'f2l',name:'Bước 4 · Hoàn thiện F2L',kind:'intuitive',description:'Hoàn thiện hai tầng đầu, thường tận dụng R/U và tránh làm mất edge orientation.',recognition:'Các vị trí còn lại ở tầng một và hai được lấp theo cặp/khối mà vẫn giữ EO.',grip:'Giữ các block làm mốc; ưu tiên R/U theo hướng đã chọn.',tips:'Luyện insertion không phá EO; lập kế hoạch trước khi mở block.'},
      {id:'ocll',name:'Bước 5 · OCLL',kind:'algorithm',description:'Định hướng góc tầng cuối bằng một trong bảy OCLL algorithms sau khi EO hoàn tất.',recognition:'Nhận dạng một trong bảy pattern góc: Sune, Anti-Sune, H, Pi, U, T hoặc L.',grip:'U ở trên; AUF để khớp hình case.',tips:'Giữ edge orientation; kiểm tra đúng pattern trước khi chạy.'},
      {id:'pll',name:'Bước 6 · PLL',kind:'algorithm',description:'Hoán vị tầng cuối với đầy đủ 21 trường hợp PLL.',recognition:'Mặt U đồng màu; đối chiếu màu các mặt bên để nhận diện case.',grip:'U ở trên; căn AUF trước khi chạy.',tips:'Học PLL theo nhóm góc, cạnh và các hoán vị đặc trưng.'}
    ], pros:['Blockbuilding tự do, có tiềm năng giảm move và xây dựng tư duy định hướng cạnh.','Không bắt buộc bắt đầu theo Cross hoặc các slot CFOP cố định.'], cons:['Khó lập kế hoạch và nhận diện block hiệu quả.','Cần kiểm soát EO khi hoàn thiện F2L; tài liệu luyện tập ít phổ biến hơn CFOP.'],
    learningTips:['Petrus là phương pháp blockbuilding; đừng học thuộc công thức cho các bước vốn trực quan.','Giữ nguyên block đã giải trong khi mở rộng.','EO phải được bảo toàn ở các bước sau.','Last Layer hai bước là OCLL+PLL; các bộ một bước như ZBLL là lựa chọn nâng cao khác.'], sources:['https://bradleykh.github.io/CubeTools/guides/methods/']
  }
};

for (const [libraryId, method] of Object.entries(METHOD_LIBRARIES)) {
  method.cases.forEach(item => { item.libraryId = libraryId; });
}

export const ALL_METHOD_CASES = Object.values(METHOD_LIBRARIES).flatMap(method => method.cases);
export const METHOD_CASES_BY_ID = new Map(ALL_METHOD_CASES.map(item => [item.id,item]));
export const TWO_LOOK_CASES = [...TWO_LOOK_OLL_CASES,...TWO_LOOK_PLL_CASES];
