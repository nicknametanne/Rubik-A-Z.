const FACE_BY_NORMAL = {
  '0,0,1': 'front',
  '0,0,-1': 'back',
  '1,0,0': 'right',
  '-1,0,0': 'left',
  '0,1,0': 'top',
  '0,-1,0': 'bottom'
};

const FACE_ORDER = Object.keys(FACE_BY_NORMAL);
const AXIS_INDEX = { x: 0, y: 1, z: 2 };

/** Map logical cube coordinates (Y up) to CSS coordinates (Y down). */
export function getCssTurnAngle(move) {
  const sign = move.axis === 'y' ? 1 : -1;
  return move.turns * 90 * sign;
}

const STICKER_COLORS = { U: '#f5f3ea', R: '#e34f4f', F: '#32aa70', D: '#f0d23c', L: '#ff963f', B: '#3978df' };

function escapeAttribute(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

function groupedCubies(cube) {
  const groups = new Map();
  for (const sticker of cube) {
    const key = sticker.position.join(',');
    if (!groups.has(key)) groups.set(key, { position: [...sticker.position], stickers: new Map() });
    groups.get(key).stickers.set(sticker.normal.join(','), sticker.color);
  }
  return [...groups.values()].sort((a, b) => {
    for (let axis = 0; axis < 3; axis += 1) {
      if (a.position[axis] !== b.position[axis]) return a.position[axis] - b.position[axis];
    }
    return 0;
  });
}

function renderCubie(cubie, cellSize) {
  const [x, y, z] = cubie.position;
  const faces = FACE_ORDER.map(normal => {
    const face = FACE_BY_NORMAL[normal];
    const sticker = cubie.stickers.get(normal);
    const color = sticker ? STICKER_COLORS[sticker] : '';
    const style = color ? ` style="--sticker-color:${escapeAttribute(color)}"` : '';
    return `<i class="viz-cubie-face viz-cubie-face-${face}"${style} aria-hidden="true"></i>`;
  }).join('');
  const left = 50 + (x * 100 / 3);
  const top = 50 - (y * 100 / 3);
  const zOffset = z * cellSize;
  return `<span class="viz-cubie" data-cubie-position="${x},${y},${z}" style="left:${left}%;top:${top}%;transform:translate(-50%,-50%) translateZ(${zOffset}px)">${faces}</span>`;
}

/** Render all 26 visible 3×3 cubies. During a turn, the affected layer is grouped
 * so CSS can rotate that layer as a physical slice before the exact state commits. */
export function renderCube3D(cube, { turn = null, cellSize = 56 } = {}) {
  const cubies = groupedCubies(cube);
  const moving = [];
  const stationary = [];
  if (turn && AXIS_INDEX[turn.axis] !== undefined && Array.isArray(turn.layers)) {
    const axisIndex = AXIS_INDEX[turn.axis];
    for (const cubie of cubies) {
      (turn.layers.includes(cubie.position[axisIndex]) ? moving : stationary).push(cubie);
    }
  } else {
    stationary.push(...cubies);
  }
  const staticMarkup = stationary.map(cubie => renderCubie(cubie, cellSize)).join('');
  const movingMarkup = moving.map(cubie => renderCubie(cubie, cellSize)).join('');
  const layer = moving.length
    ? `<span class="viz-turn-layer" data-viz-turn-layer style="--turn-duration:280ms">${movingMarkup}</span>`
    : '';
  return `${staticMarkup}${layer}`;
}

export function countVisibleCubies(cube) {
  return groupedCubies(cube).length;
}
