# Cập nhật Rubik Universe V6–V7 lên GitHub Pages

## Bộ file gồm
- `Rubik-Universe-V6-V7.zip`: mã nguồn đầy đủ của website (có `index.html` ở thư mục gốc của ZIP).
- `deploy-pages.yml`: workflow mới để GitHub tự giải nén ZIP và triển khai website.

## Cập nhật repository đang có

1. Mở repository `Rubik-A-Z` trên GitHub.
2. Ở tab **Code**, mở `.github/workflows/deploy-pages.yml`.
3. Nhấn biểu tượng bút chì **Edit**, thay toàn bộ nội dung cũ bằng nội dung trong file `deploy-pages.yml` của bộ này, rồi nhấn **Commit changes**.
4. Quay lại tab **Code**, chọn **Add file → Upload files**.
5. Tải `Rubik-Universe-V6-V7.zip` lên **thư mục gốc repository** (cùng cấp với các file đầu tiên đang hiện ở tab Code), rồi commit.
6. Mở **Settings → Pages → Build and deployment → Source** và chọn **GitHub Actions**.
7. Mở tab **Actions**. Chờ workflow `Publish Rubik Universe to GitHub Pages` hoàn tất với dấu tích xanh.
8. Vào **Settings → Pages** và mở đường dẫn tại mục **Your site is live at**.

## Lưu ý
- ZIP phải được tải lên ở thư mục gốc repository, không giải nén trực tiếp vào một thư mục con.
- Workflow chỉ triển khai các file website cần thiết (`index.html`, CSS, PWA assets và `src/`), không đưa thư mục test lên website.
- Nếu repository dùng nhánh mặc định không phải `main`, sửa `branches: [main]` trong workflow cho khớp tên nhánh.
- Dữ liệu Timer, Session, công thức cá nhân và tiến độ Academy vẫn lưu trên trình duyệt hiện tại; hãy xuất backup JSON trước khi đổi thiết bị hoặc trình duyệt.
