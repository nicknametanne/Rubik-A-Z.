import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import { join } from 'node:path';

const root = new URL('../', import.meta.url);
const read = relative => readFile(new URL(relative, root), 'utf8');

test('PWA manifest has a valid app identity, relative scope and install icons', async () => {
  const manifest = JSON.parse(await read('manifest.webmanifest'));
  assert.equal(manifest.name, 'Rubik Universe');
  assert.equal(manifest.start_url, './');
  assert.equal(manifest.scope, './');
  assert.equal(manifest.display, 'standalone');
  for (const icon of manifest.icons) await access(new URL(icon.src.replace(/^\.\//, ''), root));
});

test('Service worker pre-caches all local app modules', async () => {
  const worker = await read('sw.js');
  const required = ['index.html', 'styles.css', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'src/app.js', 'src/core.js', 'src/academy-data.js', 'src/scramble-generator.js', 'src/cfop-data.js', 'src/cube.js', 'src/solver.js', 'src/solver-worker.js', 'src/knowledge-data.js'];
  for (const path of required) {
    assert.ok(worker.includes(`'./${path}'`), `Service worker misses ${path}`);
    await access(new URL(path, root));
  }
});

test('GitHub Pages workflow supports ZIP upload and direct source deployment', async () => {
  const workflow = await read('.github/workflows/deploy-pages.yml');
  assert.ok(workflow.includes("actions/checkout@v6"));
  assert.ok(workflow.includes('Rubik-Universe-V6-V7*.zip'));
  assert.ok(workflow.includes('Rubik-Universe-v5.5*.zip'));
  assert.ok(workflow.includes('actions/upload-pages-artifact@v4'));
  assert.ok(workflow.includes('actions/deploy-pages@v4'));
  assert.ok(workflow.includes('pages: write'));
  assert.ok(workflow.includes('id-token: write'));
  assert.ok(workflow.includes('ready=false'));
  assert.ok(workflow.includes("steps.prepare.outputs.ready == 'true'"));
  assert.ok(workflow.includes('No Rubik Universe V6–V7 / V5.5 ZIP or source files yet'));
});


test('V6 keyboard safety releases Space independently of current focus and on lost focus', async () => {
  const app = await read('src/app.js');
  assert.ok(app.includes('function releaseSpaceHold({ startOnRelease = false } = {})'));
  assert.ok(app.includes("window.addEventListener('blur', () => releaseSpaceHold({ startOnRelease: false }))"));
  const keyUp = app.slice(app.indexOf('function handleSpaceUp(event) {'), app.indexOf('function isTypingTarget(target) {'));
  assert.ok(keyUp.includes('if (event.code !== \'Space\' || !spaceHeld) return;'));
  assert.ok(keyUp.includes('releaseSpaceHold({ startOnRelease: shouldStart })'));
  assert.ok(keyUp.indexOf('if (event.code !== \'Space\' || !spaceHeld) return;') < keyUp.indexOf('releaseSpaceHold'));
});

test('V6 worker offers verified 3x3 random-state scrambles', async () => {
  const worker = await read('src/solver-worker.js');
  assert.ok(worker.includes('SolverCube.scramble()'));
  assert.ok(worker.includes('scrambledCube.clone().move(solution).isSolved()'));
  assert.ok(worker.includes("type: 'scrambles'"));
});

test('V7 Academy has 25 unique structured CFOP lessons', async () => {
  const { CFOP_LESSONS } = await import('../src/academy-data.js');
  assert.equal(CFOP_LESSONS.length, 25);
  assert.equal(new Set(CFOP_LESSONS.map(lesson => lesson.id)).size, 25);
  assert.ok(CFOP_LESSONS.every(lesson => lesson.title && lesson.body && lesson.drill && lesson.minutes > 0));
  for (const stage of ['CROSS', 'F2L', 'OLL', 'PLL', 'INTEGRATION']) {
    assert.ok(CFOP_LESSONS.some(lesson => lesson.stage === stage), `Missing ${stage} lessons`);
  }
});


test('V6 provides event-specific WCA-format scrambles for cube sizes 2x2 to 7x7', async () => {
  const { getWcaNxNEventCode, generateWcaNxNScrambles } = await import('../src/scramble-generator.js');
  for (let size = 2; size <= 7; size += 1) assert.equal(getWcaNxNEventCode(size), `${size}${size}${size}`);
  assert.equal(getWcaNxNEventCode(8), null);
  const requested = [];
  const result = await generateWcaNxNScrambles(4, 3, async () => ({
    randomScrambleForEvent: async code => {
      requested.push(code);
      return { toString: () => `R${requested.length} U F2` };
    }
  }));
  assert.deepEqual(requested, ['444', '444', '444']);
  assert.equal(result.length, 3);
  assert.ok(result.every(scramble => scramble.length > 0));
});
