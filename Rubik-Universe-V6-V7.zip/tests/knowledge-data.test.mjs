import test from 'node:test';
import assert from 'node:assert/strict';
import { KNOWLEDGE_ARTICLES, KNOWLEDGE_CATEGORIES } from '../src/knowledge-data.js';

test('Knowledge Base contains a useful set of unique articles and categories', () => {
  const ids = KNOWLEDGE_ARTICLES.map(article => article.id);
  assert.ok(KNOWLEDGE_ARTICLES.length >= 25);
  assert.equal(new Set(ids).size, ids.length);
  assert.ok(KNOWLEDGE_CATEGORIES.some(category => category.id === 'all'));
  for (const article of KNOWLEDGE_ARTICLES) {
    assert.ok(article.title.trim().length > 3, `Missing title: ${article.id}`);
    assert.ok(article.excerpt.trim().length > 20, `Missing excerpt: ${article.id}`);
    assert.ok(KNOWLEDGE_CATEGORIES.some(category => category.id === article.category), `Unknown category: ${article.id}`);
    assert.ok(article.sections.length > 0, `Missing sections: ${article.id}`);
    assert.ok(article.sections.every(section => section.heading && ((section.paragraphs?.length || 0) + (section.bullets?.length || 0)) > 0), `Empty section: ${article.id}`);
  }
});

test('Knowledge Base related article references all resolve', () => {
  const ids = new Set(KNOWLEDGE_ARTICLES.map(article => article.id));
  for (const article of KNOWLEDGE_ARTICLES) {
    for (const relatedId of article.related || []) assert.ok(ids.has(relatedId), `${article.id} references missing ${relatedId}`);
  }
});

test('Knowledge Base includes expected coverage across the requested areas', () => {
  const categories = new Set(KNOWLEDGE_ARTICLES.map(article => article.category));
  for (const required of ['basics', 'notation', 'methods', 'speedcubing', 'puzzles', 'hardware']) assert.ok(categories.has(required));
  const ids = new Set(KNOWLEDGE_ARTICLES.map(article => article.id));
  for (const required of ['cube-anatomy', 'cfop-overview', 'cross', 'f2l', 'oll', 'pll', 'lookahead', 'roux-method', 'zz-method', 'puzzle-nxn', 'magnet-system', 'cube-setup']) assert.ok(ids.has(required));
});
