# Rubik Universe V6–V7

Nền tảng speedcubing cá nhân chạy bằng HTML, CSS và JavaScript ES Modules thuần. Không cần framework, backend hay bước build.

## Chạy trên Windows

1. Giải nén `Rubik-Universe-V6-V7.zip`.
2. Mở Terminal/CMD trong thư mục `rubik-universe`.
3. Chạy:

   ```bash
   py -m http.server 8080
   ```

4. Mở `http://localhost:8080` trong Chrome hoặc Edge.

Không mở `index.html` trực tiếp bằng `file://`; module và Web Worker cần HTTP/HTTPS.

## V5.4 — Knowledge Base

- 29 bài viết biên soạn sẵn, hoạt động không cần backend.
- 6 nhóm: Rubik cơ bản, notation, phương pháp giải, speedcubing, các loại puzzle, cấu tạo và bảo dưỡng.
- Nội dung gồm cấu tạo 3×3, trạng thái Rubik, face/wide/slice/rotation notation, Beginner, CFOP, Cross, F2L, OLL, PLL, 2-Look, Roux, ZZ, Petrus, inspection, lookahead, fingertricks, TPS/turning accuracy, phân tích solve, 2×2, NxN, Pyraminx, Megaminx, Skewb, Square-1, Clock và cơ chế/bảo dưỡng cube.
- Tìm kiếm, lọc theo danh mục, trang đọc bài riêng và liên kết chủ đề liên quan.
- Tìm kiếm toàn cục có thể tìm cả nội dung bài viết.

## V5.5 — UX & Quality

- Tùy biến Dashboard: bật/tắt Lượt giải gần đây và Công cụ truy cập nhanh.
- Giao diện gọn và chế độ giảm chuyển động.
- Bảng phím tắt: `Ctrl/⌘ + K`, `Space`, `N`, `?`, `Esc`.
- Bổ sung nhãn truy cập, focus hiển thị, skip link, quản lý focus hộp thoại và tinh chỉnh giao diện màn hình nhỏ.
- Dữ liệu cài đặt mới được migrate tự động, giữ nguyên dữ liệu V5 cũ.
- PWA: có manifest, icon và Service Worker; sau lần tải đầu trên HTTPS, các tài nguyên cốt lõi được cache để mở lại khi mất mạng.
- Solver vẫn cần tải thư viện `cubejs@1.3.2` từ jsDelivr khi chạy lần đầu; do đó Solver có thể không hoạt động offline nếu thư viện chưa được tải/cache.

## Các module được giữ từ V5.1–V5.3

- **Scramble Center:** tạo scramble theo định dạng WCA cho 2×2–7×7, tạo theo lô, sao chép và lưu lịch sử tối đa 200 mục. Random-state được dùng ở các sự kiện được yêu cầu; big cubes dùng kiểu scramble theo lượt xoay. Đây là công cụ luyện tập, không thay thế chương trình scramble chính thức tại giải WCA.
- **CFOP Academy:** Cross planning, F2L pair, Lookahead, giảm rotation, OLL/PLL recognition và 2-Look.
- **Advanced Statistics:** Best Ao50, Mean of 3, Current Ao100, độ lệch chuẩn, bộ lọc ngày/session, biểu đồ và so sánh session.
- **CFOP Library:** 119 case (41 F2L, 57 OLL, 21 PLL), công thức cá nhân và Algorithm Trainer lặp lại ngắt quãng.
- **Timer, Sessions, Training Center, 3D Visualizer, 3×3 Solver, backup JSON và CSV** được giữ lại.

## Đưa lên GitHub Pages

GitHub không tự giải nén ZIP thành các tệp website khi bạn tải một file ZIP lên repository. Bản V6–V7 kèm workflow GitHub Actions để giải nén ZIP và triển khai website tự động; workflow phải được đặt trong repository một lần. Có hai cách dùng.

### Cách A — Chỉ đưa ZIP ứng dụng vào repository sau khi thêm workflow

1. Tạo repository mới trên GitHub, đặt tên ví dụ `rubik-universe` và chọn **Public**.
2. Trong repository, chọn **Add file → Create new file**.
3. Đặt tên file chính xác là `.github/workflows/deploy-pages.yml`.
4. Dán nội dung từ file `.github/workflows/deploy-pages.yml` có trong bộ GitHub Upload Kit V6–V7, rồi commit vào nhánh `main`.
5. Chọn **Add file → Upload files**, tải `Rubik-Universe-V6-V7.zip` lên thư mục gốc repository và commit.
6. Vào **Settings → Pages → Build and deployment → Source**, chọn **GitHub Actions**.
7. Mở tab **Actions**. Workflow sẽ tự tìm ZIP `Rubik-Universe-V6-V7*.zip`, giải nén, lấy thư mục chứa `index.html` và deploy.
8. Khi job Deploy thành công, website có địa chỉ dạng `https://TEN-GITHUB.github.io/TEN-REPOSITORY/`.

Sau này, chỉ cần thay ZIP cùng tên trong repository và commit; workflow sẽ chạy lại. Vì vậy, sau bước thiết lập workflow một lần, việc cập nhật website chỉ còn là tải ZIP `Rubik-Universe-V6-V7.zip` mới lên repository và commit. Workflow mặc định theo dõi nhánh `main`. Nếu repository dùng tên nhánh khác, sửa `branches: [main]` trong workflow thành tên nhánh đó.

### Cách B — Đưa toàn bộ mã nguồn lên repository

1. Giải nén ZIP ứng dụng trên máy.
2. Tải nội dung bên trong thư mục `rubik-universe` lên thư mục gốc repository, bao gồm cả thư mục ẩn `.github`.
3. Commit lên nhánh `main`, sau đó chọn **Settings → Pages → Source → GitHub Actions**.
4. Workflow sẽ triển khai các tệp website từ source. Khi cập nhật code và commit, website tự cập nhật.

**Lưu ý:** Chỉ chọn repository Public không đủ để GitHub Pages tự chạy. Phải chọn Source là GitHub Actions và để workflow chạy thành công. Tệp ZIP nằm trong repository chỉ là gói source; trang web thật được tạo từ nội dung giải nén trong workflow.

## Dữ liệu cá nhân

GitHub Pages chỉ host các tệp website tĩnh. Solve, session, công thức cá nhân, tiến độ và cài đặt được lưu trong LocalStorage của trình duyệt. Chúng không tự đồng bộ giữa máy tính/điện thoại hoặc giữa các trình duyệt. Trước khi đổi thiết bị, hãy xuất backup JSON trong Cài đặt rồi nhập lại trên thiết bị mới.

## Chạy kiểm thử

Yêu cầu Node.js 18+:

```bash
npm test
```

Các test kiểm tra thống kê, penalty, migration và backup, notation, 119 case CFOP, engine 3D, trạng thái Solver, bàn phím Space, bộ tạo scramble WCA 2×2–7×7, Academy và Knowledge Base.

## Cấu trúc

```text
rubik-universe/
├── .github/workflows/deploy-pages.yml
├── index.html
├── styles.css
├── manifest.webmanifest
├── sw.js
├── icon.svg
├── icon-192.png
├── icon-512.png
├── README.md
├── THIRD-PARTY-LICENSES.md
├── package.json
├── src/
│   ├── app.js
│   ├── academy-data.js
│   ├── scramble-generator.js
│   ├── core.js
│   ├── cfop-data.js
│   ├── cube.js
│   ├── solver.js
│   ├── solver-worker.js
│   └── knowledge-data.js
└── tests/
    ├── core.test.mjs
    ├── deployment.test.mjs
    └── knowledge-data.test.mjs
```


## V6–V7 combined release

### V6 — Scramble & Timer
- 3×3 random-state scramble generation through cubejs in a Web Worker; each generated state is checked by solving it back to solved.
- Timer supports 2×2 through 7×7 sessions. Scramble Center uses cubing.js event generators for 2×2 and 4×4–7×7; the generators follow the event scramble format, using random-state where required and move-based scrambles for big cubes.
- Space handling releases on keyup even if focus moved, and resets a held key when the tab is hidden or the browser window loses focus.
- New service-worker cache revision, network-first asset refresh, and update check to reduce stale JS/CSS after deployment.

### V7 — CFOP Academy
- Expanded course from 7 overview cards to 25 structured lessons across Cross, F2L, OLL, PLL and full-solve integration.
- Stage filtering, saved completion progress, random CFOP case practice, answer reveal, 3D visualization and spaced-review ratings.

### Known scope
- The Timer still covers 2×2–7×7 cubes; the Solver remains a 3×3 facelet solver.
- The 3×3 random-state worker uses cubejs from jsDelivr. Scramble Center uses cubing.js over HTTPS for other NxN WCA-format scrambles. Internet is needed the first time these CDN modules load; when unavailable, the app falls back to labelled practice sequences.
- Full browser end-to-end testing across all browsers/devices is not claimed; unit tests, JavaScript syntax checks and static deployment checks are included in this package.
