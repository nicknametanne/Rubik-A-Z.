# Cập nhật Rubik Universe V8 lên GitHub Pages

## Đây là bản nào?

V8 được ghép trực tiếp vào mã nguồn Rubik Universe V6–V7. Đây không phải website độc lập thay thế dự án cũ. V8 giữ lại các tính năng và dữ liệu trình duyệt của V6–V7, đồng thời bổ sung hình nhận diện 119 case CFOP và 5 loại scramble puzzle.

## Các tệp trong bộ Upload Kit

- `Rubik-Universe-V8.zip`: mã nguồn website V8 hoàn chỉnh, có `index.html` ở thư mục gốc ZIP.
- `deploy-pages.yml`: workflow cần cập nhật vào repository hiện tại. Workflow ưu tiên ZIP V8 trước các ZIP V6–V7/V5.5 cũ.
- `.github/workflows/deploy-pages.yml`: cùng nội dung workflow ở đúng vị trí trong cấu trúc source.

## Cập nhật repository `Rubik-A-Z` đang dùng

1. Mở repository `Rubik-A-Z` trên GitHub. Không cần tạo repository mới.
2. Mở `.github/workflows/deploy-pages.yml`, chọn **Edit** và thay toàn bộ nội dung bằng file `deploy-pages.yml` trong Upload Kit V8. Commit thay đổi này trước. Bước này quan trọng: workflow V6–V7 cũ không ưu tiên tìm ZIP V8.
3. Quay lại tab **Code** → **Add file** → **Upload files**. Tải `Rubik-Universe-V8.zip` lên thư mục gốc repository (không giải nén ZIP vào thư mục con), sau đó commit.
4. Mở **Actions** và chờ workflow `Publish Rubik Universe to GitHub Pages` chạy xong với dấu tích xanh.
5. Mở website hiện tại và nhấn `Ctrl + Shift + R` để tải lại tài nguyên mới.

Nếu GitHub Pages của repository đã đặt **Settings → Pages → Build and deployment → Source → GitHub Actions** từ lần deploy trước thì không cần cấu hình lại. Chỉ chỉnh nếu Source đang không phải GitHub Actions.

Địa chỉ Pages hiện tại của repository vẫn giữ nguyên, ví dụ: `https://nicknametanne.github.io/Rubik-A-Z/`. Việc tạo file V8 không tự deploy; bạn vẫn cần cập nhật workflow, tải ZIP và commit để GitHub Actions chạy.

## Dữ liệu cũ

V8 giữ nguyên khóa lưu LocalStorage `rubik-universe-v1` và không đổi cấu trúc lưu dữ liệu cốt lõi. Timer, solves, sessions, công thức cá nhân và tiến độ học trên cùng trình duyệt được giữ lại. Dù vậy, nên xuất backup JSON từ Settings trước khi cập nhật phiên bản lớn. Dữ liệu lưu cục bộ không tự đồng bộ sang thiết bị hoặc trình duyệt khác.

## Lưu ý về scramble

- 2×2–7×7 tiếp tục dùng các bộ sinh WCA-format hiện có của V6–V7 (với các giới hạn nguồn/Internet đã nêu trong README).
- Pyraminx, Skewb, Megaminx, Square-1 và Clock có bộ sinh scramble luyện tập riêng được chuyển từ file HTML tham khảo; không quảng cáo các bộ này là random-state generator WCA chính thức.

## Nếu deploy không cập nhật

- Kiểm tra tab **Actions** xem workflow có dấu tích xanh hay lỗi.
- Kiểm tra ZIP V8 nằm ở thư mục gốc repository.
- Kiểm tra workflow đã được thay bằng bản mới, vì nó phải tìm `Rubik-Universe-V8*.zip` trước ZIP cũ.
- Sau deploy thành công, dùng `Ctrl + Shift + R` hoặc mở cửa sổ ẩn danh để loại trừ cache trình duyệt.
