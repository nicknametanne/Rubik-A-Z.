# Hướng dẫn đưa Rubik Universe V9 lên GitHub Pages

Bản V9 được xây dựng tiếp trên mã nguồn V8/V6–V7. Dùng repository hiện tại; không tạo repository mới.

## Cập nhật repository `Rubik-A-Z`

1. Giải nén `Rubik-Universe-V9-GitHub-Upload-Kit.zip` trên máy tính.
2. Mở repository GitHub `Rubik-A-Z`.
3. Mở `.github/workflows/deploy-pages.yml` → Edit → thay toàn bộ nội dung bằng file `deploy-pages.yml` trong gói → Commit changes.
4. Ở thư mục gốc repository, chọn **Add file → Upload files**.
5. Tải lên file `Rubik-Universe-V9.zip` (không giải nén vào thư mục con) → Commit changes. Bạn cũng có thể tải nguyên file `Rubik-Universe-V9-GitHub-Upload-Kit.zip`; workflow V9 nhận diện được cả gói này.
6. Mở tab **Actions**. Chờ workflow `Publish Rubik Universe to GitHub Pages` chạy xong với dấu tích xanh.
7. Mở lại website Pages hiện tại và nhấn `Ctrl + Shift + R`.

Workflow V9 ưu tiên `Rubik-Universe-V9.zip`, sau đó nhận diện Upload Kit V9, rồi mới tìm V8, V6–V7 và V5.5. Nếu còn ZIP cũ ở thư mục gốc, V9 vẫn được ưu tiên.

Nếu **Settings → Pages → Build and deployment → Source** đã là **GitHub Actions**, không cần thay đổi. Workflow hiện đặt nhánh `main`; nếu repository dùng nhánh mặc định khác, đổi `branches: [main]` trong workflow cho đúng.

## Lưu ý dữ liệu

V9 giữ nguyên khóa LocalStorage `rubik-universe-v1` và có migration từ schema cũ. Tuy vậy, hãy vào Settings và xuất backup JSON trước khi cập nhật. Dữ liệu cục bộ không tự đồng bộ giữa các thiết bị hoặc trình duyệt.

## Nếu GitHub Actions báo lỗi

Mở lần chạy lỗi trong **Actions**, chọn bước màu đỏ và gửi nội dung log. Không cần tạo repository mới hoặc xóa dữ liệu cũ để thử lại.
