# Rubik Universe V9

Nền tảng speedcubing cá nhân chạy bằng HTML, CSS và JavaScript ES Modules thuần. Không cần framework, backend hay bước build.

## V9 — tích hợp V9 Scramble/Timer và V10 CFOP nâng cao

- Giữ nguyên các module V6–V8: Timer, 11 puzzle, Sessions, Solver 3×3, 3D Visualizer, CFOP Library 119 case, Academy/Trainer, Knowledge Base, thống kê, backup JSON/CSV, PWA và Service Worker.
- Scramble Center và Timer dùng bộ sinh cubing.js theo event code cho 11 puzzle. 2×2, 3×3, 4×4, Pyraminx, Skewb, Square-1 và Clock là nhóm random-state; 5×5–7×7 và Megaminx dùng scramble random-move theo đặc thù event. Nếu CDN lỗi, UI ghi rõ PRACTICE ONLY và không gắn nhãn random-state.
- Lịch sử lưu scramble từ Scramble Center và Timer, kèm puzzle, nguồn sinh và loại phương pháp.
- Statistics có bộ lọc puzzle độc lập với session và bộ lọc ngày; tất cả chỉ số/biểu đồ/bảng được tính trên cùng tập dữ liệu lọc.
- Inspection dùng ranh giới chính xác: đúng 15.00 giây chưa phạt; trên 15.00 đến đúng 17.00 giây là +2; trên 17.00 giây là DNF.
- CFOP Academy mở rộng 32 bài. Thêm Cross Efficiency Lab để lưu scramble, chuỗi move, số move và rotation; thêm F2L tracker để lưu case, rotation, pause và thời gian. Các log là dữ liệu người học tự nhập, không tuyên bố tự xác minh Cross/F2L đã giải đúng.
- Mỗi case CFOP có thể lưu nhiều công thức thay thế do người dùng tự kiểm chứng; ứng dụng kiểm tra ký hiệu, không bịa algorithm.
- Dữ liệu mới nằm trong schema `cfopPractice`; migration giữ nguyên khóa `rubik-universe-v1`, session, solve, algorithm, tiến độ và cài đặt từ bản cũ.

## Scramble — ghi chú chính xác

Scramble nâng cao được tải từ cubing.js. Thư viện xác định phương pháp theo event: một số event dùng random-state, big cubes và Megaminx dùng random-move. Thư viện không làm bước lọc competition scramble; đây là công cụ luyện tập và không thay cho chương trình scramble được ban tổ chức sử dụng tại giải chính thức. Khi mạng/CDN không sẵn sàng, local fallback chỉ là chuỗi practice.

## Chạy trên Windows

1. Giải nén `Rubik-Universe-V9.zip`.
2. Mở Terminal/CMD trong thư mục có `index.html`.
3. Chạy `py -m http.server 8080`.
4. Mở `http://localhost:8080` trong Chrome hoặc Edge.

Không mở bằng `file://`; ES Modules, Web Worker và Service Worker cần HTTP/HTTPS.

## Cập nhật GitHub Pages đang dùng

1. Thay toàn bộ `.github/workflows/deploy-pages.yml` bằng workflow kèm trong Upload Kit V9 và commit trước.
2. Tải `Rubik-Universe-V9.zip` lên thư mục gốc repository (không giải nén vào thư mục con), rồi commit.
3. Mở Actions và chờ workflow thành công. Nếu Pages đã chọn GitHub Actions từ trước thì không cần tạo lại repository hay cấu hình lại.
4. Mở website hiện tại và nhấn `Ctrl + Shift + R`.

Chi tiết ở `HUONG-DAN-GITHUB-V9.md` trong Upload Kit.

## Kiểm thử

Yêu cầu Node.js 18+: chạy `npm test`. Kiểm thử kiểm tra migration/backup, thống kê, inspection, notation, 119 case CFOP, 32 bài Academy, bộ sinh scramble event-code qua module giả, UI hooks và deploy assets. Kiểm thử tự động không thay thế kiểm thử trình duyệt thực tế hoặc kiểm tra scramble tại một cuộc thi.

## Dữ liệu cá nhân

Solve, session, algorithm, tiến độ học và log luyện tập được lưu cục bộ trong `localStorage` trên thiết bị/trình duyệt. Hãy xuất backup JSON trước khi đổi thiết bị; dữ liệu không tự đồng bộ giữa thiết bị.
