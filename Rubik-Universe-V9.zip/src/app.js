import {
  createDefaultData, loadData, saveData, generatePracticeScramble, generateCubePracticeScramble,
  getSessionSolves, averageOf, bestAverage, meanOf, effectiveTime, formatTime,
  parseTime, makeId, isValidAlgorithm, inspectionPenalty, isValidNotation, scheduleReview, normalizeReview, migrateData, filterSolvesByPuzzle
} from './core.js';
import { CFOP_CASES, F2L_CASES } from './cfop-data.js';
import { CFOP_LESSONS } from './academy-data.js';
import { generateWcaNxNScrambles, generateCubingJsScrambles, getScrambleMethod } from './scramble-generator.js';
import { generateSpecialScramble, getPuzzleLabel } from './multi-scramble.js';
import { renderCfopCaseDiagram } from './cfop-visuals.js';
import { createSolvedCube, applyCubeMoves, parseCubeMoves, invertCubeMoves, cubeFaceGrids, createCubeFromFaceletString, cubeToFaceletString, isCubeSolved } from './cube.js';
import { FACE_ORDER, SOLVED_FACELETS, validateFacelets } from './solver.js';
import { KNOWLEDGE_ARTICLES, KNOWLEDGE_CATEGORIES } from './knowledge-data.js';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const data = loadData();
const DEFAULT_TRAINING = { targetSeconds: 15, dailyMinutes: 30, weeklySolves: 100, completions: [] };
function normalizeTraining(training) {
  const source = training && typeof training === 'object' ? training : {};
  const normalized = { ...DEFAULT_TRAINING, ...source };
  const targetSeconds = Number(source.targetSeconds);
  const dailyMinutes = Number(source.dailyMinutes);
  const weeklySolves = Number(source.weeklySolves);
  normalized.targetSeconds = Number.isFinite(targetSeconds) && targetSeconds >= 1 && targetSeconds <= 600 ? targetSeconds : DEFAULT_TRAINING.targetSeconds;
  normalized.dailyMinutes = Number.isInteger(dailyMinutes) && dailyMinutes >= 5 && dailyMinutes <= 300 ? dailyMinutes : DEFAULT_TRAINING.dailyMinutes;
  normalized.weeklySolves = Number.isInteger(weeklySolves) && weeklySolves >= 1 && weeklySolves <= 2000 ? weeklySolves : DEFAULT_TRAINING.weeklySolves;
  normalized.completions = (Array.isArray(source.completions) ? source.completions : [])
    .filter(entry => entry && typeof entry.date === 'string')
    .map(entry => ({ date: entry.date, taskIds: Array.isArray(entry.taskIds) ? [...new Set(entry.taskIds.filter(id => typeof id === 'string'))] : [] }));
  return normalized;
}
data.training = normalizeTraining(data.training);
let solverFacelets = validateFacelets(data.solverDraft || SOLVED_FACELETS).valid ? (data.solverDraft || SOLVED_FACELETS) : SOLVED_FACELETS;
let solverWorker = null;
let solverReady = false;
let solverPending = false;
let solverRequestedFacelets = '';
let solverRequestId = 0;
let solverSolution = '';
let pendingWcaRequests = new Map();
let nextWcaRequestId = 0;
let timerScrambleRequestId = 0;
let currentScrambleType = 'practice';
let currentScrambleGenerator = 'practice';
let cfopDrillScramble = generatePracticeScramble(25);
let cfopDrillScrambleSource = 'practice';
let currentScramblePuzzle = '3x3';
let preserveNextTimerScramble = false;
let spaceHeld = false;
let academyStageFilter = 'ALL';
let academyCurrentCaseId = null;
let academyAnswerVisible = false;
let activePage = 'home';
let activeAlgorithmFilter = 'ALL';
let activeCaseFilter = 'ALL';
let searchIndex = [];
let currentKnowledgeArticleId = null;
let lastModalFocus = null;
let currentScramble = generatePracticeScramble();
let scrambleCenterPuzzle = '3x3';
let timerState = 'idle';
let timerFrame = 0;
let startAt = 0;
let inspectionAt = 0;
let currentPenalty = 'none';
let solveSessionId = data.activeSessionId;
let solvePuzzle = activeSession()?.puzzle || '3x3';
let holdTimer = 0;
let holdActive = false;
let trainerQueue = [];
let trainerIndex = 0;
let trainerRevealed = false;
let visualizer = {
  moves: [], baseCube: createSolvedCube(), cube: createSolvedCube(), step: 0,
  label: 'Cube đã giải', interval: 0, rotationX: -24, rotationY: -32
};

function persist() {
  const ok = saveData(data);
  if (!ok) toast('Không thể lưu dữ liệu. Hãy kiểm tra dung lượng trình duyệt.', 'error');
  return ok;
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}

function activeSession() {
  return data.sessions.find(session => session.id === data.activeSessionId) || data.sessions[0];
}

function sessionSolves(sessionId = data.activeSessionId) {
  return getSessionSolves(data, sessionId);
}

function displayTime(ms) {
  return formatTime(ms, Number(data.settings.timerDecimals) === 3 ? 3 : 2);
}

function getCaseProgress(id) {
  const current = data.caseProgress[id];
  const normalized = normalizeReview(current);
  if (current) return { ...normalized, favorite: Boolean(current.favorite), customMoves: typeof current.customMoves === 'string' ? current.customMoves : '', note: typeof current.note === 'string' ? current.note : '' };
  return { ...normalized, favorite: false, customMoves: '', alternativeMoves: [], note: '' };
}

function caseMoves(item) {
  const custom = data.caseProgress[item.id]?.customMoves;
  return typeof custom === 'string' && custom.trim() ? custom.trim() : item.moves;
}

function reviewLabel(status) {
  return ({ new: 'Chưa học', learning: 'Đang học', known: 'Đã thuộc' })[status] || 'Chưa học';
}

function toast(message, kind = 'success') {
  const region = $('#toast-region');
  const node = document.createElement('div');
  node.className = `toast ${kind}`;
  node.innerHTML = `<span>${kind === 'error' ? '!' : '✓'}</span><p>${esc(message)}</p>`;
  region.append(node);
  window.setTimeout(() => node.classList.add('leaving'), 2600);
  window.setTimeout(() => node.remove(), 3000);
}

function openModal(title, body, onSubmit) {
  lastModalFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  $('#modal-title').textContent = title;
  $('#modal-body').innerHTML = body;
  $('#modal-backdrop').classList.remove('hidden');
  const form = $('#modal-body form');
  if (form) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const result = onSubmit?.(new FormData(form));
      if (result !== false) closeModal();
    });
  }
  ($('#modal-body').querySelector('input,select,textarea,button,[tabindex="0"]') || $('#modal-close')).focus();
}

function closeModal() {
  $('#modal-backdrop').classList.add('hidden');
  $('#modal-body').innerHTML = '';
  if (lastModalFocus?.isConnected) lastModalFocus.focus();
  lastModalFocus = null;
}

function navigate(page) {
  if (!$('#page-' + page)) return;
  activePage = page;
  $$('.page').forEach(node => node.classList.toggle('active', node.id === `page-${page}`));
  $$('.nav-item[data-page]').forEach(node => node.classList.toggle('active', node.dataset.page === page));
  const labels = { home: 'Tổng quan', timer: 'Timer', scrambles: 'Scramble Center', academy: 'CFOP Academy', algorithms: 'Thư viện thuật toán', trainer: 'Algorithm Trainer', solver: '3×3 Solver', training: 'Training Center', visualizer: 'Rubik 3D', stats: 'Thống kê', sessions: 'Sessions', explore: 'Thư viện kiến thức', settings: 'Cài đặt' };
  $('#page-crumb').textContent = labels[page] || page;
  $('#sidebar').classList.remove('open');
  if (page === 'home') renderHome();
  if (page === 'timer') {
    renderTimerPage();
    if (preserveNextTimerScramble) preserveNextTimerScramble = false;
    else if (currentScrambleType === 'practice' || currentScramblePuzzle !== activeSession().puzzle) newScramble({ silent: true });
  }
  if (page === 'scrambles') renderScrambleCenter();
  if (page === 'academy') renderAcademy();
  if (page === 'algorithms') { renderCaseLibrary(); renderAlgorithms(); }
  if (page === 'trainer') renderTrainer();
  if (page === 'solver') renderSolver();
  if (page === 'training') renderTraining();
  if (page === 'stats') renderStats();
  if (page === 'sessions') renderSessions();
  if (page === 'explore') renderKnowledgeBase();
  if (page === 'settings') syncSettings();
  if (page === 'visualizer') { populateVisualizerPresets(); renderVisualizer(); } else stopVisualizerPlayback();
  $('#app-content').focus({ preventScroll: true });
  window.scrollTo({ top: 0, behavior: data.settings.reducedMotion ? 'auto' : 'smooth' });
}

function setTheme(theme) {
  data.settings.theme = theme === 'light' ? 'light' : 'dark';
  document.documentElement.dataset.theme = data.settings.theme;
  $('#theme-toggle').textContent = data.settings.theme === 'light' ? '☾' : '☼';
  $$('[data-theme-choice]').forEach(button => button.classList.toggle('active', button.dataset.themeChoice === data.settings.theme));
  persist();
}

function applyDisplaySettings() {
  const settings = data.settings || {};
  const widgets = settings.dashboardWidgets || {};
  document.body.classList.toggle('reduce-motion', Boolean(settings.reducedMotion));
  document.body.classList.toggle('compact-ui', Boolean(settings.compactMode));
  $('#home-recent-panel').hidden = widgets.recent === false;
  $('#home-quick-panel').hidden = widgets.quickAccess === false;
  const switches = [
    ['settings-inspection', settings.inspection !== false],
    ['settings-sound', Boolean(settings.sound)],
    ['settings-compact', Boolean(settings.compactMode)],
    ['settings-reduced-motion', Boolean(settings.reducedMotion)],
    ['settings-dashboard-recent', widgets.recent !== false],
    ['settings-dashboard-quick', widgets.quickAccess !== false]
  ];
  switches.forEach(([id, enabled]) => {
    const button = $(`#${id}`);
    if (button) { button.classList.toggle('active', enabled); button.setAttribute('aria-checked', String(enabled)); }
  });
}

function updateSessionLabels() {
  const session = activeSession();
  if (!session) return;
  $('#sidebar-session-name').textContent = session.name;
  $('#home-session-name').textContent = session.name;
  $('#timer-session-label').textContent = session.name;
  $('#home-session-sub').textContent = `${session.puzzle} · Buổi luyện tập đang hoạt động`;
}

function renderHome() {
  updateSessionLabels();
  const solves = sessionSolves();
  const finite = solves.filter(solve => Number.isFinite(effectiveTime(solve)));
  const best = finite.length ? Math.min(...finite.map(effectiveTime)) : null;
  $('#home-best').textContent = displayTime(best);
  $('#home-ao5').textContent = displayTime(bestAverage(solves, 5));
  $('#home-average').textContent = displayTime(meanOf(solves));
  $('#home-count').textContent = String(solves.length);
  applyDisplaySettings();
  const recent = solves.slice(-5).reverse();
  $('#home-recent').innerHTML = recent.length ? recent.map((solve, index) => `
    <div class="recent-row"><span class="recent-number">${solves.length - index}</span><strong>${displayTime(effectiveTime(solve))}</strong><span class="recent-date">${formatDate(solve.createdAt)}</span><span class="recent-tag ${solve.penalty === 'none' ? '' : 'penalty'}">${solve.penalty === 'none' ? 'OK' : esc(solve.penalty)}</span></div>`).join('') : `<div class="empty-state compact"><span class="empty-symbol">◷</span><strong>Chưa có lượt giải</strong><p>Những lượt solve đầu tiên sẽ xuất hiện ở đây.</p></div>`;
}

function formatDate(dateValue) {
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('vi-VN', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(date);
}

function currentSolveMetrics() {
  const solves = sessionSolves();
  const finite = solves.map(effectiveTime).filter(Number.isFinite);
  return {
    solves,
    best: finite.length ? Math.min(...finite) : null,
    ao5: averageOf(solves, 5),
    ao12: averageOf(solves, 12)
  };
}

function renderTimerPage() {
  updateSessionLabels();
  $('#inspection-state').textContent = data.settings.inspection ? 'ON' : 'OFF';
  $('#inspection-toggle').classList.toggle('is-off', !data.settings.inspection);
  if ($('#timer-decimals')) $('#timer-decimals').value = String(data.settings.timerDecimals || 2);
  $('#timer-puzzle').value = activeSession().puzzle;
  updateTimerScrambleText();
  renderTimerMetrics();
  renderTimerHistory();
  renderSolveTable();
  cancelAnimationFrame(timerFrame);
  updateTimerDisplay();
}

function renderTimerMetrics() {
  const metrics = currentSolveMetrics();
  $('#timer-best').textContent = displayTime(metrics.best);
  $('#timer-ao5').textContent = displayTime(metrics.ao5);
  $('#timer-ao12').textContent = displayTime(metrics.ao12);
  $('#timer-count').textContent = String(metrics.solves.length);
}

function renderTimerHistory() {
  const solves = sessionSolves().slice(-5).reverse();
  $('#timer-history').innerHTML = solves.length ? solves.map((solve, i) => `
    <div class="mini-solve"><span>${sessionSolves().length - i}</span><strong>${displayTime(effectiveTime(solve))}</strong><small>${solve.penalty === 'none' ? 'OK' : esc(solve.penalty)}</small></div>`).join('') : `<div class="empty-state compact"><strong>Chưa có dữ liệu</strong><p>Hãy hoàn thành lượt solve đầu tiên.</p></div>`;
}

function renderSolveTable() {
  const solves = sessionSolves().slice().reverse();
  $('#solve-table').innerHTML = solves.length ? solves.map((solve, index) => `
    <tr><td class="table-index">${solves.length - index}</td><td><strong class="table-time">${displayTime(effectiveTime(solve))}</strong>${solve.penalty === '+2' ? '<small class="inline-penalty">+2</small>' : ''}</td><td class="scramble-cell" title="${esc(solve.scramble)}">${esc(solve.scramble || '—')}</td><td>${formatDate(solve.createdAt)}</td><td class="note-cell">${esc(solve.note || '—')}</td><td><div class="table-actions"><button data-edit-solve="${esc(solve.id)}" title="Sửa">✎</button><button data-delete-solve="${esc(solve.id)}" title="Xóa">×</button></div></td></tr>`).join('') : '<tr><td colspan="6" class="table-empty">Chưa có lượt giải trong session này.</td></tr>';
}

function setTimerState(status, statusText, hint) {
  timerState = status;
  $('#timer-status').textContent = statusText;
  $('#timer-hint').textContent = hint;
  $('#timer-display').classList.remove('is-running', 'is-ready', 'is-inspection');
  if (status === 'running') $('#timer-display').classList.add('is-running');
  if (status === 'ready') $('#timer-display').classList.add('is-ready');
  if (status === 'inspection') $('#timer-display').classList.add('is-inspection');
}

function updateTimerDisplay() {
  if (timerState === 'running') {
    const elapsed = performance.now() - startAt;
    $('#timer-time').textContent = displayTime(elapsed);
    timerFrame = requestAnimationFrame(updateTimerDisplay);
  } else if (timerState === 'inspection') {
    const left = Math.max(0, 15000 - (performance.now() - inspectionAt));
    $('#timer-time').textContent = displayTime(left);
    timerFrame = requestAnimationFrame(updateTimerDisplay);
  }
}

function startInspection() {
  cancelAnimationFrame(timerFrame);
  solveSessionId = data.activeSessionId;
  solvePuzzle = activeSession().puzzle;
  inspectionAt = performance.now();
  currentPenalty = 'none';
  setTimerState('inspection', 'INSPECTION', 'KIỂM TRA RUBIK · GIỮ SPACE ĐỂ SẴN SÀNG');
  $('#timer-time').textContent = '15.00';
  updateTimerDisplay();
}

function getInspectionPenalty() {
  if (!data.settings.inspection) return 'none';
  return inspectionPenalty(performance.now() - inspectionAt);
}

function beginSolve() {
  cancelAnimationFrame(timerFrame);
  if (timerState !== 'inspection' && timerState !== 'ready') {
    solveSessionId = data.activeSessionId;
    solvePuzzle = activeSession().puzzle;
  }
  currentPenalty = timerState === 'inspection' || timerState === 'ready' ? getInspectionPenalty() : 'none';
  startAt = performance.now();
  setTimerState('running', 'SOLVING', 'NHẤN SPACE HOẶC CHẠM ĐỂ DỪNG');
  $('#timer-time').textContent = displayTime(0);
  playBeep(660, 45);
  updateTimerDisplay();
}

function stopSolve() {
  if (timerState !== 'running') return;
  cancelAnimationFrame(timerFrame);
  const rawMs = Math.max(0, performance.now() - startAt);
  const solve = {
    id: makeId('solve'), sessionId: solveSessionId, puzzle: solvePuzzle,
    scramble: currentScramble, rawMs, penalty: currentPenalty, note: '', createdAt: new Date().toISOString()
  };
  data.solves.push(solve);
  persist();
  setTimerState('stopped', 'SOLVE SAVED', 'NHẤN SPACE HOẶC CHẠM ĐỂ GIẢI TIẾP');
  $('#timer-time').textContent = displayTime(effectiveTime(solve));
  playBeep(880, 70);
  renderTimerMetrics();
  renderTimerHistory();
  renderSolveTable();
  renderHome();
  toast(`Đã lưu lượt solve: ${displayTime(effectiveTime(solve))}`);
  newScramble({ silent: true });
}

function timerTap() {
  if (timerState === 'running') return stopSolve();
  if (timerState === 'inspection') return beginSolve();
  if (timerState === 'ready') return beginSolve();
  if (data.settings.inspection) startInspection();
  else beginSolve();
}

function releaseSpaceHold({ startOnRelease = false } = {}) {
  if (!spaceHeld && !holdActive) return;
  spaceHeld = false;
  holdActive = false;
  window.clearTimeout(holdTimer);
  const wasReady = timerState === 'ready';
  if (startOnRelease && wasReady && activePage === 'timer') {
    beginSolve();
    return;
  }
  // If the browser lost focus while the key was held, never leave the timer
  // waiting in READY. Restore the state from which the hold began.
  if (wasReady) {
    if (data.settings.inspection) {
      setTimerState('inspection', 'INSPECTION', 'KIỂM TRA RUBIK · GIỮ SPACE ĐỂ SẴN SÀNG');
      updateTimerDisplay();
    } else {
      cancelAnimationFrame(timerFrame);
      setTimerState('idle', 'READY TO SOLVE', 'NHẤN SPACE HOẶC CHẠM ĐỂ BẮT ĐẦU');
      $('#timer-time').textContent = displayTime(0);
    }
  }
}

function handleSpaceDown(event) {
  if (event.code !== 'Space') return;
  const modalOpen = !$('#modal-backdrop').classList.contains('hidden');
  const isControlButton = event.target instanceof HTMLElement && event.target.closest('button') && event.target.id !== 'timer-display';
  if (isTypingTarget(event.target) || modalOpen || isControlButton) return;
  if (activePage !== 'timer' && timerState !== 'running') return;
  event.preventDefault();
  if (spaceHeld || event.repeat) return;
  spaceHeld = true;
  if (timerState === 'running') {
    stopSolve();
    return;
  }
  if (activePage !== 'timer') return;
  if (timerState === 'idle' || timerState === 'stopped') {
    if (data.settings.inspection) startInspection();
    else {
      solveSessionId = data.activeSessionId;
      solvePuzzle = activeSession().puzzle;
      setTimerState('ready', 'HOLD TO READY', 'GIỮ SPACE ĐỂ CHUẨN BỊ');
    }
  }
  holdActive = true;
  if (timerState === 'inspection') setTimerState('inspection', 'INSPECTION', 'GIỮ SPACE ĐỂ SẴN SÀNG');
  if (timerState === 'inspection' || timerState === 'ready') {
    holdTimer = window.setTimeout(() => {
      if (!spaceHeld || !holdActive || !['inspection', 'ready'].includes(timerState)) return;
      setTimerState('ready', 'READY', 'THẢ SPACE ĐỂ BẮT ĐẦU');
      $('#timer-time').textContent = displayTime(0);
      cancelAnimationFrame(timerFrame);
    }, 350);
  }
}

function handleSpaceUp(event) {
  if (event.code !== 'Space' || !spaceHeld) return;
  // Do not re-check event.target here: focus may have moved since keydown.
  event.preventDefault();
  const modalOpen = !$('#modal-backdrop').classList.contains('hidden');
  const nativeControl = event.target instanceof HTMLElement && event.target.closest('button') && event.target.id !== 'timer-display';
  const shouldStart = activePage === 'timer' && !isTypingTarget(event.target) && !nativeControl && !modalOpen;
  releaseSpaceHold({ startOnRelease: shouldStart });
}

function isTypingTarget(target) {
  return target instanceof HTMLElement && (target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName));
}


function playBeep(frequency = 660, duration = 50) {
  if (!data.settings.sound) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    const context = new AudioContextClass();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.045, context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + duration / 1000);
    oscillator.connect(gain); gain.connect(context.destination);
    oscillator.start(); oscillator.stop(context.currentTime + duration / 1000);
    oscillator.onended = () => context.close();
  } catch { /* Audio is optional; timer remains usable without it. */ }
}


function addManualSolve() {
  const body = `<form class="modal-form"><label>Thời gian gốc <input name="time" placeholder="Ví dụ: 18.42 hoặc 1:02.35" required autofocus /></label><label>Penalty<select name="penalty"><option value="none">Không có</option><option value="+2">+2 giây</option><option value="DNF">DNF</option></select></label><label>Scramble <textarea name="scramble" rows="2">${esc(currentScramble)}</textarea></label><label>Ghi chú <input name="note" placeholder="Không bắt buộc" /></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">Lưu lượt giải</button></div></form>`;
  openModal('Nhập lượt solve', body, form => {
    const rawMs = parseTime(form.get('time'));
    if (rawMs === null || rawMs <= 0) { toast('Thời gian không hợp lệ. Ví dụ: 18.42 hoặc 1:02.35.', 'error'); return false; }
    data.solves.push({ id: makeId('solve'), sessionId: data.activeSessionId, puzzle: activeSession().puzzle, rawMs, penalty: form.get('penalty'), scramble: String(form.get('scramble')).trim(), note: String(form.get('note')).trim(), createdAt: new Date().toISOString() });
    persist(); renderTimerPage(); renderHome(); toast('Đã thêm lượt solve thủ công.');
  });
}

function editSolve(id) {
  const solve = data.solves.find(item => item.id === id);
  if (!solve) return;
  const body = `<form class="modal-form"><label>Thời gian gốc (giây) <input name="time" value="${(solve.rawMs / 1000).toFixed(2)}" required /></label><label>Penalty<select name="penalty"><option value="none" ${solve.penalty === 'none' ? 'selected' : ''}>Không có</option><option value="+2" ${solve.penalty === '+2' ? 'selected' : ''}>+2 giây</option><option value="DNF" ${solve.penalty === 'DNF' ? 'selected' : ''}>DNF</option></select></label><label>Ghi chú <input name="note" value="${esc(solve.note || '')}" /></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">Lưu thay đổi</button></div></form>`;
  openModal('Chỉnh sửa lượt solve', body, form => {
    const rawMs = parseTime(form.get('time'));
    if (rawMs === null || rawMs <= 0) { toast('Thời gian không hợp lệ.', 'error'); return false; }
    solve.rawMs = rawMs; solve.penalty = form.get('penalty'); solve.note = String(form.get('note')).trim();
    persist(); renderTimerPage(); renderStats(); renderHome(); toast('Đã cập nhật lượt solve.');
  });
}

function deleteSolve(id) {
  const solve = data.solves.find(item => item.id === id);
  if (!solve || !confirm(`Xóa lượt ${displayTime(effectiveTime(solve))}? Thao tác này không thể hoàn tác.`)) return;
  data.solves = data.solves.filter(item => item.id !== id);
  persist(); renderTimerPage(); renderStats(); renderHome(); toast('Đã xóa lượt solve.');
}

function renderAlgorithms() {
  const query = $('#algorithm-search').value.trim().toLowerCase();
  const algorithms = data.algorithms.filter(alg => (activeAlgorithmFilter === 'ALL' || alg.type === activeAlgorithmFilter) && `${alg.name} ${alg.moves} ${alg.notes || ''}`.toLowerCase().includes(query));
  $('#alg-count-all').textContent = String(data.algorithms.length);
  $('#algorithm-grid').innerHTML = algorithms.length ? algorithms.map(alg => `
    <article class="algorithm-card"><div class="algorithm-card-top"><span class="alg-type ${alg.type.toLowerCase()}">${alg.type}</span><div class="alg-card-actions"><button data-favorite-alg="${esc(alg.id)}" title="Yêu thích">${alg.favorite ? '★' : '☆'}</button><button data-edit-alg="${esc(alg.id)}" title="Sửa">✎</button><button data-delete-alg="${esc(alg.id)}" title="Xóa">×</button></div></div><h3>${esc(alg.name)}</h3><div class="algorithm-formula">${esc(alg.moves)}</div><p>${esc(alg.notes || 'Chưa có ghi chú.')}</p><div class="algorithm-card-bottom"><span class="mastery ${alg.mastered ? 'done' : ''}">${alg.mastered ? '✓ Đã thuộc' : '○ Đang học'}</span><button class="text-button" data-train-alg="${esc(alg.id)}">Luyện tập →</button></div></article>`).join('') : `<div class="empty-state full-span"><span class="empty-symbol">▦</span><strong>${data.algorithms.length ? 'Không tìm thấy công thức' : 'Thư viện đang trống'}</strong><p>${data.algorithms.length ? 'Thử thay đổi từ khóa hoặc bộ lọc.' : 'Thêm công thức đầu tiên để bắt đầu xây dựng bộ sưu tập của bạn.'}</p>${data.algorithms.length ? '' : '<button class="primary-button" id="empty-add-alg">＋ Thêm công thức</button>'}</div>`;
}

function isValidMoves(moves) {
  const tokens = moves.trim().split(/\s+/).filter(Boolean);
  if (!tokens.length) return false;
  return isValidNotation(moves);
}

function addAlgorithm(existing = null) {
  const alg = existing || { name: '', type: 'OLL', moves: '', notes: '', favorite: false, mastered: false };
  const body = `<form class="modal-form"><label>Tên trường hợp <input name="name" value="${esc(alg.name)}" placeholder="Ví dụ: T-perm" required /></label><label>Nhóm<select name="type">${['OLL', 'PLL', 'F2L', 'OTHER'].map(type => `<option value="${type}" ${alg.type === type ? 'selected' : ''}>${type}</option>`).join('')}</select></label><label>Công thức <textarea name="moves" rows="3" placeholder="R U R' U'..." required>${esc(alg.moves)}</textarea><small class="field-hint">Nhập ký hiệu cơ bản, phân tách các move bằng dấu cách. Ví dụ: R U R' U'.</small></label><label>Ghi chú <textarea name="notes" rows="2" placeholder="Mẹo nhận diện, hướng cầm...">${esc(alg.notes || '')}</textarea></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">${existing ? 'Lưu thay đổi' : 'Thêm vào thư viện'}</button></div></form>`;
  openModal(existing ? 'Chỉnh sửa công thức' : 'Thêm công thức', body, form => {
    const name = String(form.get('name')).trim();
    const moves = String(form.get('moves')).trim();
    if (!name || !isValidMoves(moves)) { toast('Tên hoặc định dạng công thức chưa hợp lệ. Kiểm tra ký hiệu và dấu cách.', 'error'); return false; }
    const values = { name, type: form.get('type'), moves, notes: String(form.get('notes')).trim() };
    if (existing) Object.assign(existing, values);
    else data.algorithms.push({ id: makeId('alg'), ...values, favorite: false, mastered: false, createdAt: new Date().toISOString() });
    persist(); renderAlgorithms(); renderTrainer(); toast(existing ? 'Đã cập nhật công thức.' : 'Đã thêm công thức.');
  });
}

function editCaseAlgorithm(id) {
  const item = CFOP_CASES.find(entry => entry.id === id);
  if (!item) return;
  const progress = getCaseProgress(id);
  const body = `<form class="modal-form"><label>Case <input value="${esc(item.name)}" disabled /></label><label>Công thức chính của bạn <textarea name="moves" rows="3" placeholder="${esc(item.moves)}">${esc(progress.customMoves || item.moves)}</textarea><small class="field-hint">Để trống hoặc giữ công thức tham chiếu để dùng công thức gốc. Ký hiệu được kiểm tra trước khi lưu.</small></label><label>Công thức thay thế (mỗi dòng một công thức) <textarea name="alternatives" rows="3" placeholder="Chỉ nhập công thức bạn đã tự kiểm chứng">${esc(progress.alternativeMoves.join('\n'))}</textarea><small class="field-hint">Không tự sinh công thức thay thế. Hãy chỉ lưu biến thể bạn đã kiểm tra đúng case và hướng cầm.</small></label><label>Ghi chú nhận diện <textarea name="note" rows="2" placeholder="Hướng cầm, mẹo nhận diện...">${esc(progress.note)}</textarea></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">Lưu tùy chỉnh</button></div></form>`;
  openModal(`Tùy chỉnh ${item.name}`, body, form => {
    const moves = String(form.get('moves')).trim();
    const alternatives = String(form.get('alternatives') || '').split('\n').map(value => value.trim()).filter(Boolean);
    if ((moves && !isValidNotation(moves)) || alternatives.some(value => !isValidNotation(value))) { toast('Công thức chính hoặc công thức thay thế có ký hiệu không hợp lệ.', 'error'); return false; }
    data.caseProgress[id] = { ...progress, customMoves: moves && moves !== item.moves ? moves : '', alternativeMoves: alternatives, note: String(form.get('note')).trim() };
    persist(); renderCaseLibrary(); toast('Đã lưu tùy chỉnh case.');
  });
}

function buildTrainerQueue() {
  const type = $('#trainer-type').value;
  const now = Date.now();
  const cases = CFOP_CASES.filter(item => type === 'ALL' || item.type === type).map(item => {
    const review = getCaseProgress(item.id);
    return { key: item.id, kind: 'case', item, type: item.type, name: item.name, moves: caseMoves(item), review };
  });
  const custom = data.algorithms.filter(alg => type === 'ALL' || type === 'CUSTOM' || alg.type === type).map(alg => ({
    key: `CUSTOM-${alg.id}`, kind: 'custom', item: alg, type: alg.type, name: alg.name, moves: alg.moves,
    review: normalizeReview(alg.review, alg.mastered)
  }));
  let queue;
  if (type === 'ALL') queue = [...cases, ...custom];
  else if (['F2L', 'OLL', 'PLL'].includes(type)) queue = [...cases, ...custom.filter(entry => entry.type === type)];
  else queue = custom;
  if ($('#trainer-due-only').checked) queue = queue.filter(entry => entry.review.status === 'new' || entry.review.dueAt <= now);
  return queue.sort((a, b) => a.review.dueAt - b.review.dueAt || a.name.localeCompare(b.name));
}

function renderTrainer() {
  trainerQueue = buildTrainerQueue();
  trainerIndex = Math.min(trainerIndex, Math.max(0, trainerQueue.length - 1));
  showTrainerCard();
}

function showTrainerCard() {
  const current = trainerQueue[trainerIndex];
  trainerRevealed = false;
  const selectedType = $('#trainer-type').value;
  const allCases = CFOP_CASES.filter(item => selectedType === 'ALL' || item.type === selectedType);
  const known = allCases.filter(item => getCaseProgress(item.id).status === 'known').length;
  const total = allCases.length;
  const groupLabel = total ? `${known} / ${total} case ${selectedType === 'ALL' ? 'CFOP' : selectedType} đã thuộc` : `${data.algorithms.filter(alg => selectedType === 'CUSTOM' || selectedType === 'ALL' || alg.type === selectedType).length} công thức cá nhân`;
  $('#trainer-progress-label').textContent = groupLabel;
  $('#trainer-progress-count').textContent = trainerQueue.length ? `${trainerIndex + 1} / ${trainerQueue.length}` : '0 / 0';
  $('#trainer-progress-bar').style.width = total ? `${(known / total) * 100}%` : '0%';
  $('#trainer-category').textContent = current?.type || selectedType;
  $('#trainer-name').textContent = current?.name || 'Không có case đến hạn';
  $('#trainer-case-visual').innerHTML = current?.kind === 'case' ? renderCfopCaseDiagram(current.item, current.moves) : '';
  $('#trainer-prompt').textContent = current ? `${current.kind === 'case' ? 'Nhận diện case chuẩn.' : 'Công thức cá nhân.'} Tự nhớ công thức trước khi mở đáp án. Trạng thái: ${reviewLabel(current.review.status)}.` : 'Không có mục nào cần ôn theo bộ lọc hiện tại. Hãy tắt “Chỉ đến hạn” để xem toàn bộ thư viện.';
  $('#trainer-formula').textContent = current?.moves || '';
  $('#trainer-formula').classList.add('hidden');
  $('#reveal-formula').disabled = !current;
  $$('[data-trainer-rating]').forEach(button => { button.disabled = !current; });
  $('#flashcard').classList.remove('revealed');
  $('#reveal-formula').innerHTML = 'Hiện công thức <span>↓</span>';
}

function trainerNext(rating) {
  const current = trainerQueue[trainerIndex];
  if (!current) return;
  const updated = scheduleReview(current.review, rating);
  if (current.kind === 'case') {
    data.caseProgress[current.item.id] = { ...getCaseProgress(current.item.id), ...updated };
  } else {
    current.item.review = updated;
    current.item.mastered = updated.status === 'known';
    current.item.lastReviewedAt = new Date(updated.lastReviewedAt).toISOString();
  }
  persist();
  renderCaseLibrary();
  renderTrainer();
  if (!trainerQueue.length) toast('Đã ôn xong các mục đến hạn.');
}

function trainCase(id) {
  const item = CFOP_CASES.find(entry => entry.id === id);
  const custom = data.algorithms.find(entry => `CUSTOM-${entry.id}` === id);
  const selected = item || custom;
  if (!selected) return;
  $('#trainer-type').value = item ? item.type : (custom.type === 'F2L' || custom.type === 'OTHER' ? custom.type : 'CUSTOM');
  $('#trainer-due-only').checked = false;
  navigate('trainer');
  const key = item ? item.id : `CUSTOM-${custom.id}`;
  const index = trainerQueue.findIndex(entry => entry.key === key);
  if (index >= 0) trainerIndex = index;
  showTrainerCard();
}

function stickerDirectionLabel(direction) {
  return ({ front: 'trước', back: 'sau', left: 'trái', right: 'phải', up: 'trên', down: 'dưới' })[direction] || '—';
}

function renderCaseLibrary() {
  const query = $('#case-search').value.trim().toLowerCase();
  const now = Date.now();
  const progresses = CFOP_CASES.map(item => ({ item, progress: getCaseProgress(item.id) }));
  const knownCount = type => progresses.filter(row => row.item.type === type && row.progress.status === 'known').length;
  const dueCount = progresses.filter(row => row.progress.status === 'new' || row.progress.dueAt <= now).length;
  $('#f2l-mastered-count').textContent = `${knownCount('F2L')} / 41`;
  $('#oll-mastered-count').textContent = `${knownCount('OLL')} / 57`;
  $('#pll-mastered-count').textContent = `${knownCount('PLL')} / 21`;
  $('#case-due-count').textContent = String(dueCount);
  const filtered = progresses.filter(({ item, progress }) => {
    if (['F2L', 'OLL', 'PLL'].includes(activeCaseFilter) && item.type !== activeCaseFilter) return false;
    if (activeCaseFilter === 'DUE' && !(progress.status === 'new' || progress.dueAt <= now)) return false;
    if (activeCaseFilter === 'FAVORITE' && !progress.favorite) return false;
    return `${item.name} ${item.type} ${item.moves} ${item.family || ''} ${item.whiteSticker || ''}`.toLowerCase().includes(query);
  });
  $('#case-grid').innerHTML = filtered.map(({ item, progress }) => `
    <article class="case-card ${progress.status === 'known' ? 'is-known' : ''}">
      <div class="case-card-head"><span class="alg-type ${item.type.toLowerCase()}">${item.type}</span><button class="case-favorite ${progress.favorite ? 'active' : ''}" data-case-favorite="${item.id}" title="Yêu thích" aria-label="Yêu thích">${progress.favorite ? '★' : '☆'}</button></div>
      <div class="case-card-title"><strong>${esc(item.name)}</strong>${item.twoLook ? '<span class="case-chip">2-look</span>' : ''}</div>
      ${renderCfopCaseDiagram(item, caseMoves(item))}
      ${item.family ? `<div class="case-family">${esc(item.family)} · Sticker trắng: ${esc(stickerDirectionLabel(item.whiteSticker))}</div>` : ''}
      <div class="case-formula" title="${esc(caseMoves(item))}">${esc(caseMoves(item))}</div>
      ${progress.alternativeMoves.length ? `<details class="case-alternatives"><summary>${progress.alternativeMoves.length} công thức thay thế đã lưu</summary>${progress.alternativeMoves.map((moves, index) => `<code>${index + 1}. ${esc(moves)}</code>`).join('')}</details>` : ''}
      <div class="case-card-foot"><span class="mastery ${progress.status === 'known' ? 'done' : ''}">${reviewLabel(progress.status)}</span><div class="case-card-actions"><button data-copy-case="${item.id}" title="Sao chép">Copy</button><button data-edit-case="${item.id}" title="Tùy chỉnh công thức">Sửa</button><button data-train-case="${item.id}" title="Luyện tập">Luyện</button><button data-visualize-case="${item.id}" title="Xem mô phỏng 3D">3D</button></div></div>
    </article>`).join('') || '<div class="empty-state full-span"><strong>Không có case phù hợp</strong><p>Thử đổi bộ lọc hoặc từ khóa tìm kiếm.</p></div>';
}

function stopVisualizerPlayback() {
  if (visualizer.interval) window.clearInterval(visualizer.interval);
  visualizer.interval = 0;
  const playButton = $('#viz-play');
  if (playButton) playButton.textContent = '▶ Phát';
}

function populateVisualizerPresets() {
  const select = $('#viz-preset');
  if (select.dataset.ready === 'true') return;
  const groups = [
    ['F2L', F2L_CASES],
    ['OLL', CFOP_CASES.filter(item => item.type === 'OLL')],
    ['PLL', CFOP_CASES.filter(item => item.type === 'PLL')]
  ];
  select.innerHTML = '<option value="">Chọn F2L / OLL / PLL...</option>' + groups.map(([name, items]) =>
    `<optgroup label="${name}">${items.map(item => `<option value="${item.id}">${item.name} · ${item.moves.split(/\s+/).length} move</option>`).join('')}</optgroup>`
  ).join('');
  select.dataset.ready = 'true';
}

function renderVisualizer() {
  const grids = cubeFaceGrids(visualizer.cube);
  $$('[data-cube-face]').forEach(faceNode => {
    const face = faceNode.dataset.cubeFace;
    faceNode.innerHTML = grids[face].map(color => `<i class="viz-sticker" style="--sticker-color:${color}"></i>`).join('');
  });
  $('#viz-cube').style.transform = `rotateX(${visualizer.rotationX}deg) rotateY(${visualizer.rotationY}deg)`;
  const total = visualizer.moves.length;
  const current = visualizer.step ? visualizer.moves[visualizer.step - 1] : '—';
  $('#viz-current-move').textContent = current;
  $('#viz-step-count').textContent = `${visualizer.step} / ${total} move`;
  $('#viz-progress').max = String(total);
  $('#viz-progress').value = String(visualizer.step);
  $('#viz-progress-label').textContent = `${total ? Math.round((visualizer.step / total) * 100) : 0}%`;
  $('#viz-state-label').textContent = visualizer.label;
  $('#viz-previous').disabled = visualizer.step === 0;
  $('#viz-next').disabled = visualizer.step >= total;
  $('#viz-move-list').innerHTML = total ? visualizer.moves.map((move, index) => `<button class="viz-move ${index < visualizer.step ? 'is-done' : ''} ${index === visualizer.step - 1 ? 'is-current' : ''}" data-viz-jump="${index + 1}" title="Đến move ${index + 1}">${move}</button>`).join('') : '<span class="muted small-note">Nhập thuật toán hoặc chọn công thức để bắt đầu.</span>';
}

function setVisualizerStep(step) {
  stopVisualizerPlayback();
  visualizer.step = Math.max(0, Math.min(visualizer.moves.length, Number(step) || 0));
  visualizer.cube = applyCubeMoves(visualizer.baseCube, visualizer.moves.slice(0, visualizer.step).join(' '));
  renderVisualizer();
}

function loadVisualizerSequence(sequence, { reverseStart = false, label = 'Thuật toán tùy chỉnh', baseCube = null } = {}) {
  let tokens;
  try { tokens = parseCubeMoves(sequence); }
  catch (error) { toast(`Ký hiệu chưa hỗ trợ: ${error.message}`, 'error'); return false; }
  if (!tokens.length) { toast('Hãy nhập ít nhất một move hợp lệ.', 'error'); return false; }
  stopVisualizerPlayback();
  visualizer.moves = tokens;
  visualizer.baseCube = baseCube ? baseCube.map(sticker => ({ position: [...sticker.position], normal: [...sticker.normal], color: sticker.color })) : (reverseStart
    ? applyCubeMoves(createSolvedCube(), invertCubeMoves(tokens).join(' '))
    : createSolvedCube());
  visualizer.cube = visualizer.baseCube;
  visualizer.step = 0;
  visualizer.label = label;
  $('#viz-sequence').value = tokens.join(' ');
  $('#viz-state-help').textContent = reverseStart
    ? 'Trạng thái ban đầu được dựng từ chuỗi nghịch đảo; phát công thức để quay về cube đã giải.'
    : 'Đang phát từ cube đã giải. Kéo chuột hoặc vuốt để đổi góc nhìn.';
  renderVisualizer();
  return true;
}

function jumpVisualizerToAlgorithm(id) {
  const item = CFOP_CASES.find(entry => entry.id === id);
  if (!item) return;
  navigate('visualizer');
  $('#viz-preset').value = item.id;
  loadVisualizerSequence(caseMoves(item), { reverseStart: true, label: `${item.name} · ${item.type}` });
}

function toggleVisualizerPlayback() {
  if (visualizer.interval) return stopVisualizerPlayback();
  if (!visualizer.moves.length) return toast('Hãy tải một thuật toán trước.', 'error');
  if (visualizer.step >= visualizer.moves.length) setVisualizerStep(0);
  $('#viz-play').textContent = 'Ⅱ Tạm dừng';
  const delay = Number($('#viz-speed').value) || 520;
  visualizer.interval = window.setInterval(() => {
    if (visualizer.step >= visualizer.moves.length) return stopVisualizerPlayback();
    visualizer.step += 1;
    visualizer.cube = applyCubeMoves(visualizer.cube, visualizer.moves[visualizer.step - 1]);
    renderVisualizer();
    if (visualizer.step >= visualizer.moves.length) stopVisualizerPlayback();
  }, delay);
}

function localDateKey(value = new Date()) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function countRecentSolves(solves, days = 7) {
  const cutoff = Date.now() - days * 86400000;
  return solves.filter(solve => new Date(solve.createdAt).getTime() >= cutoff).length;
}

function activityStreak(solves) {
  const activeDates = new Set(solves.map(solve => localDateKey(solve.createdAt)).filter(Boolean));
  const cursor = new Date();
  if (!activeDates.has(localDateKey(cursor))) cursor.setDate(cursor.getDate() - 1);
  let streak = 0;
  while (activeDates.has(localDateKey(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

function getTodayCompletion() {
  const today = localDateKey();
  return data.training.completions.find(entry => entry.date === today) || { date: today, taskIds: [] };
}

const TRAINING_TASKS = [
  { id: 'cross', title: 'Cross efficiency', tag: 'CROSS', detail: 'Luyện 5 lần Cross chậm; ưu tiên nhìn trước và giảm move thừa.', minutes: 8, page: 'timer' },
  { id: 'f2l', title: 'F2L lookahead', tag: 'F2L', detail: 'Luyện 10 cặp ở tốc độ vừa; tập trung giảm khoảng dừng giữa hai cặp.', minutes: 10, page: 'algorithms' },
  { id: 'last-layer', title: 'OLL / PLL recognition', tag: 'LAST LAYER', detail: 'Ôn 10 case đến hạn, nhận diện trước khi mở công thức.', minutes: 7, page: 'trainer' },
  { id: 'full-solves', title: 'Full solves', tag: 'FULL SOLVE', detail: 'Thực hiện 5 lượt solve có kiểm soát; ghi chú giai đoạn bị chậm.', minutes: 5, page: 'timer' }
];

function renderTraining() {
  const solves = data.solves;
  const today = getTodayCompletion();
  const completed = new Set(today.taskIds);
  const weekCount = countRecentSolves(solves, 7);
  const streak = activityStreak(solves);
  $('#training-week-solves').textContent = `${weekCount} / ${data.training.weeklySolves}`;
  $('#training-daily-progress').textContent = `${completed.size} / ${TRAINING_TASKS.length}`;
  $('#training-streak').textContent = `${streak} ngày`;
  $('#training-date-label').textContent = new Intl.DateTimeFormat('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit' }).format(new Date());
  $('#training-task-list').innerHTML = TRAINING_TASKS.map(task => {
    const duration = Math.max(1, Math.round(task.minutes * data.training.dailyMinutes / 30));
    return `
    <article class="training-task ${completed.has(task.id) ? 'is-complete' : ''}">
      <button class="training-check" data-training-task="${task.id}" aria-label="${completed.has(task.id) ? 'Bỏ hoàn thành' : 'Đánh dấu hoàn thành'}" aria-pressed="${completed.has(task.id)}">${completed.has(task.id) ? '✓' : ''}</button>
      <div class="training-task-copy"><div><span class="training-task-tag">${task.tag}</span><small>${duration} phút</small></div><h4>${task.title}</h4><p>${task.detail}</p></div>
      <button class="text-button training-task-link" data-go="${task.page}">Mở bài →</button>
    </article>`;
  }).join('');
  const percentage = Math.round(completed.size / TRAINING_TASKS.length * 100);
  $('#training-progress-bar').style.width = `${percentage}%`;
  $('#training-progress-label').textContent = `${percentage}% hoàn thành`;
  $('#training-target-time').value = String(data.training.targetSeconds);
  $('#training-daily-minutes').value = String(data.training.dailyMinutes);
  $('#training-weekly-goal').value = String(data.training.weeklySolves);
  const bestSingle = solves.map(effectiveTime).filter(Number.isFinite).reduce((best, value) => Math.min(best, value), Infinity);
  $('#training-goal-summary').textContent = Number.isFinite(bestSingle)
    ? `Mục tiêu single: ${data.training.targetSeconds}s · PB hiện tại: ${displayTime(bestSingle)}.`
    : `Mục tiêu single: ${data.training.targetSeconds}s · Chưa có solve được lưu để so sánh.`;
}

function renderSolver() {
  const colors = { U: '#f5f3ea', R: '#e34f4f', F: '#32aa70', D: '#f0d23c', L: '#ff963f', B: '#3978df' };
  const faces = [...FACE_ORDER];
  $('#solver-net').innerHTML = faces.map(face => {
    const faceIndex = FACE_ORDER.indexOf(face);
    const tiles = Array.from({ length: 9 }, (_, index) => {
      const globalIndex = faceIndex * 9 + index;
      const color = solverFacelets[globalIndex];
      const fixed = index === 4;
      return `<button class="solver-sticker ${fixed ? 'is-center' : ''}" data-solver-sticker="${globalIndex}" style="--sticker:${colors[color]}" aria-label="Mặt ${face}, ô ${index + 1}: ${color}" ${fixed ? 'disabled' : ''}><span>${color}</span></button>`;
    }).join('');
    return `<div class="solver-net-face" data-net-face="${face}"><div class="solver-face-title">${face}</div><div class="solver-face-grid">${tiles}</div></div>`;
  }).join('');
  const validation = validateFacelets(solverFacelets);
  $('#solver-validation').textContent = validation.valid ? '✓ Trạng thái hợp lệ: đủ 54 ô, đúng tâm, đúng viên góc/cạnh và parity.' : `! ${validation.error}`;
  $('#solver-validation').classList.toggle('is-valid', validation.valid);
  $('#solver-validation').classList.toggle('is-invalid', !validation.valid);
  $('#solver-solve').disabled = !validation.valid || solverPending;
  if (solverSolution) $('#solver-result').classList.remove('hidden');
}

function setSolverStatus(title, detail, progress = 0, isError = false) {
  $('#solver-status-title').textContent = title;
  $('#solver-status-detail').textContent = detail;
  $('#solver-status-bar').style.width = `${Math.max(0, Math.min(100, progress))}%`;
  $('#solver-status-bar').classList.toggle('is-error', isError);
}

function dispatchPendingWcaRequests() {
  if (!solverReady || !solverWorker) return;
  for (const [requestId, request] of pendingWcaRequests) {
    if (request.sent) continue;
    request.sent = true;
    solverWorker.postMessage({ type: 'scramble', count: request.count, requestId });
  }
}

function rejectPendingWcaRequests(error) {
  for (const request of pendingWcaRequests.values()) request.reject(error);
  pendingWcaRequests.clear();
}

function requestWcaScrambles(count = 1) {
  ensureSolverWorker();
  if (!solverWorker) return Promise.reject(new Error('Không thể khởi tạo worker tạo scramble.'));
  const safeCount = Math.max(1, Math.min(20, Math.trunc(Number(count) || 1)));
  const requestId = ++nextWcaRequestId;
  return new Promise((resolve, reject) => {
    pendingWcaRequests.set(requestId, { count: safeCount, resolve, reject, sent: false });
    dispatchPendingWcaRequests();
  });
}

function puzzleSize(puzzle = activeSession()?.puzzle || '3x3') {
  const match = /^([2-7])x\1$/.exec(String(puzzle));
  return match ? Number(match[1]) : null;
}

function scrambleModeDescription(puzzle, type = currentScrambleType, generator = currentScrambleGenerator) {
  if (type === 'practice') return `${getPuzzleLabel(puzzle).toUpperCase()} · PRACTICE ONLY`;
  const method = getScrambleMethod(puzzle);
  const methodLabel = method === 'random-state' ? 'RANDOM-STATE' : method === 'random-moves' ? 'RANDOM-MOVE' : 'GENERATED';
  return `${generator === 'cubejs' ? 'CUBEJS' : 'CUBING.JS'} · ${methodLabel}`;
}

function updateTimerScrambleText() {
  $('#scramble-text').textContent = currentScramble;
  const mode = $('#current-scramble-mode');
  if (mode) mode.textContent = scrambleModeDescription(currentScramblePuzzle);
}

function recordTimerScramble(puzzle, scramble, type, generator) {
  saveCenterScramble(scramble, puzzle, 'timer', type !== 'practice', generator, getScrambleMethod(puzzle));
  persist();
}

async function newScramble({ silent = false } = {}) {
  if (['running', 'inspection', 'ready'].includes(timerState)) {
    if (!silent) toast('Hãy dừng lượt solve hoặc kết thúc inspection trước khi đổi scramble.', 'error');
    return;
  }
  const requestId = ++timerScrambleRequestId;
  const puzzle = activeSession()?.puzzle || '3x3';
  const size = puzzleSize(puzzle);
  currentScramblePuzzle = puzzle;
  currentScrambleType = 'practice';
  currentScrambleGenerator = 'practice';
  currentScramble = size ? generateCubePracticeScramble(size) : generateSpecialScramble(puzzle);
  updateTimerScrambleText();

  try {
    const [scramble] = size
      ? (size === 3 ? await requestWcaScrambles(1) : await generateWcaNxNScrambles(size, 1))
      : await generateCubingJsScrambles(puzzle, 1);
    if (requestId !== timerScrambleRequestId || ['running', 'inspection', 'ready'].includes(timerState)) return;
    currentScramble = scramble;
    currentScrambleType = 'generated';
    currentScrambleGenerator = size === 3 ? 'cubejs' : 'cubing.js';
    updateTimerScrambleText();
    recordTimerScramble(puzzle, scramble, currentScrambleType, currentScrambleGenerator);
    if (!silent) toast(`Đã tạo ${scrambleModeDescription(puzzle)} cho ${getPuzzleLabel(puzzle)}.`);
  } catch (error) {
    if (requestId !== timerScrambleRequestId || ['running', 'inspection', 'ready'].includes(timerState)) return;
    recordTimerScramble(puzzle, currentScramble, 'practice', 'practice');
    if (!silent) toast(`Không tải được bộ tạo scramble nâng cao; đang dùng chuỗi PRACTICE ONLY. ${error.message}`, 'error');
  }
}

function ensureSolverWorker() {
  if (solverWorker) return;
  try {
    solverWorker = new Worker(new URL('./solver-worker.js', import.meta.url));
    solverWorker.onmessage = event => {
      const message = event.data || {};
      if (message.type === 'ready') {
        solverReady = true;
        dispatchPendingWcaRequests();
        setSolverStatus('Solver đã sẵn sàng', 'Bảng tra cứu Kociemba đã được tạo. Dữ liệu được xử lý trong trình duyệt.', 100);
        if (solverPending && solverRequestedFacelets) solverWorker.postMessage({ type: 'solve', facelets: solverRequestedFacelets, requestId: solverRequestId });
        return;
      }
      if (message.type === 'scrambles') {
        const request = pendingWcaRequests.get(message.requestId);
        if (request) { pendingWcaRequests.delete(message.requestId); request.resolve(message.scrambles || []); }
        return;
      }
      if (message.type === 'scramble-error') {
        const request = pendingWcaRequests.get(message.requestId);
        if (request) { pendingWcaRequests.delete(message.requestId); request.reject(new Error(message.message || 'Không tạo được scramble.')); }
        return;
      }
      if (message.type === 'solution') {
        if (message.requestId !== solverRequestId) return;
        solverPending = false;
        solverSolution = message.solution || '';
        $('#solver-result').classList.remove('hidden');
        $('#solver-move-count').textContent = String(message.moves);
        $('#solver-algorithm').textContent = solverSolution || 'Cube đã được giải.';
        $('#solver-solve').disabled = false;
        setSolverStatus('Đã tìm thấy lời giải', `Đã xác minh bằng cách áp dụng ngược lại lên trạng thái nhập. ${message.moves} move.`, 100);
        toast('Đã giải và xác minh trạng thái Rubik.');
        return;
      }
      if (message.type === 'solve-error' || message.type === 'error') {
        if (message.type === 'error') rejectPendingWcaRequests(new Error(message.message || 'Không tải được bộ tạo scramble.'));
        if (message.requestId !== undefined && message.requestId !== solverRequestId) return;
        solverPending = false;
        $('#solver-solve').disabled = false;
        setSolverStatus('Không thể giải cube', message.message || 'Solver gặp lỗi.', 0, true);
        if (message.type === 'error') { solverWorker?.terminate(); solverWorker = null; solverReady = false; }
        toast(message.message || 'Solver gặp lỗi.', 'error');
      }
    };
    solverWorker.onerror = () => {
      rejectPendingWcaRequests(new Error('Worker bị lỗi khi tạo scramble.'));
      solverPending = false;
      $('#solver-solve').disabled = false;
      setSolverStatus('Không tải được solver', 'Hãy kiểm tra kết nối Internet/CDN rồi thử lại.', 0, true);
      solverWorker?.terminate(); solverWorker = null; solverReady = false;
    };
  } catch (error) {
    rejectPendingWcaRequests(error);
    solverPending = false;
    $('#solver-solve').disabled = false;
    setSolverStatus('Trình duyệt không hỗ trợ Web Worker', 'Hãy dùng trình duyệt hiện đại và mở website qua máy chủ HTTP.', 0, true);
  }
}

function requestCubeSolution() {
  const validation = validateFacelets(solverFacelets);
  if (!validation.valid) return toast(validation.error, 'error');
  if (solverPending) return;
  solverSolution = '';
  $('#solver-result').classList.add('hidden');
  solverPending = true;
  solverRequestId += 1;
  solverRequestedFacelets = solverFacelets;
  $('#solver-solve').disabled = true;
  setSolverStatus(solverReady ? 'Đang tìm lời giải...' : 'Đang khởi tạo solver...', solverReady ? 'Đang tìm chuỗi move và xác minh trạng thái đích.' : 'Lần đầu cần tải solver và tạo bảng tra cứu. Việc này diễn ra trong nền.', 35);
  ensureSolverWorker();
  if (solverReady) solverWorker.postMessage({ type: 'solve', facelets: solverRequestedFacelets, requestId: solverRequestId });
}

function updateSolverFacelets(next) {
  solverRequestId += 1;
  solverPending = false;
  solverFacelets = next;
  data.solverDraft = next;
  solverSolution = '';
  $('#solver-result').classList.add('hidden');
  persist();
  renderSolver();
  setSolverStatus('Trạng thái đã thay đổi', 'Hãy chạy Solver để tìm lời giải cho màu hiện tại.', 0);
}

function renderScrambleCenter() {
  const history = data.scrambleHistory || [];
  const filter = $('#scramble-history-filter')?.value || 'all';
  const rows = history.filter(item => filter === 'all' || item.puzzle === filter).slice().reverse();
  $('#scramble-history').innerHTML = rows.length ? rows.map(item => `<article class="scramble-history-row"><div><strong>${esc(getPuzzleLabel(item.puzzle))} · ${formatDate(item.createdAt)}</strong><p>${esc(item.scramble)}</p><small>${item.source === 'batch' ? 'Tạo theo lô' : item.source === 'timer' ? 'Tạo từ Timer' : 'Tạo mới'} · ${item.generator === 'cubing.js' ? `cubing.js · ${String(item.method || 'generated').toUpperCase()}` : item.generator === 'cubejs' ? 'CubeJS · RANDOM-STATE' : (!item.generator && (item.isGenerated ?? item.isWca)) ? 'Generated (legacy record)' : 'PRACTICE ONLY'}</small></div><div class="inline-actions"><button class="secondary-button small-button" data-copy-history="${esc(item.id)}">Copy</button><button class="text-button" data-use-history="${esc(item.id)}">Dùng</button></div></article>`).join('') : '<div class="empty-state compact"><strong>Chưa có scramble đã lưu</strong><p>Scramble bạn tạo sẽ xuất hiện ở đây.</p></div>';
  $('#scramble-history-count').textContent = String(history.length);
}

function createCenterScramble(puzzle) {
  const size = puzzleSize(puzzle);
  return size ? generateCubePracticeScramble(size) : generateSpecialScramble(puzzle);
}

function saveCenterScramble(scramble, puzzle, source = 'single', isLibraryGenerated = false, generator = 'practice', method = 'practice') {
  const entry = { id: makeId('scramble'), puzzle, scramble, source, isGenerated: Boolean(isLibraryGenerated), isWca: Boolean(isLibraryGenerated), generator, method, createdAt: new Date().toISOString() };
  data.scrambleHistory = [...(data.scrambleHistory || []), entry].slice(-200);
  return entry;
}

async function generateCenterScrambles() {
  const puzzle = $('#scramble-puzzle').value;
  const size = puzzleSize(puzzle);
  const amount = Math.max(1, Math.min(20, Number($('#scramble-amount').value) || 1));
  const button = $('#scramble-generate');
  button.disabled = true;
  button.textContent = 'Đang tạo…';
  let generated = [];
  let isLibraryGenerated = false;
  try {
    if (size) {
      try {
        generated = size === 3
          ? await requestWcaScrambles(amount)
          : await generateWcaNxNScrambles(size, amount);
        isLibraryGenerated = true;
      } catch (error) {
        generated = Array.from({ length: amount }, () => createCenterScramble(puzzle));
        toast(`Bộ tạo event chưa sẵn sàng; đã tạo chuỗi PRACTICE ONLY thay thế. ${error.message}`, 'error');
      }
    } else {
      try {
        generated = await generateCubingJsScrambles(puzzle, amount);
        isLibraryGenerated = true;
      } catch (error) {
        generated = Array.from({ length: amount }, () => generateSpecialScramble(puzzle));
        toast(`cubing.js chưa sẵn sàng; đang dùng chuỗi PRACTICE ONLY. ${error.message}`, 'error');
      }
    }
  } catch (error) {
    toast(`Không tạo được scramble: ${error.message}`, 'error');
  } finally {
    button.disabled = false;
    button.textContent = '↻ Tạo scramble';
  }
  if (!generated.length) return;
  const generator = isLibraryGenerated ? (size === 3 ? 'cubejs' : 'cubing.js') : 'practice';
  const method = getScrambleMethod(puzzle);
  generated.forEach(scramble => saveCenterScramble(scramble, puzzle, amount > 1 ? 'batch' : 'single', isLibraryGenerated, generator, method));
  persist();
  $('#scramble-current').textContent = generated[0] || 'Không tạo được scramble.';
  $('#scramble-current-mode').textContent = isLibraryGenerated ? scrambleModeDescription(puzzle, 'generated', generator) : `${getPuzzleLabel(puzzle).toUpperCase()} · PRACTICE ONLY`;
  $('#scramble-batch').innerHTML = generated.map((scramble, index) => `<div class="scramble-batch-item"><span>${index + 1}</span><code>${esc(scramble)}</code><button class="secondary-button small-button" data-copy-batch="${index}">Copy</button></div>`).join('');
  $('#scramble-batch').dataset.items = JSON.stringify(generated);
  renderScrambleCenter();
  if (isLibraryGenerated) toast(amount === 1 ? `Đã tạo scramble ${scrambleModeDescription(puzzle, 'generated', generator)}.` : `Đã tạo ${amount} scramble ${scrambleModeDescription(puzzle, 'generated', generator)}.`);
  else toast(amount === 1 ? `Đã tạo scramble ${getPuzzleLabel(puzzle)}.` : `Đã tạo ${amount} scramble ${getPuzzleLabel(puzzle)}.`);
}

function renderAcademy() {
  const completed = new Set(data.academyProgress?.completed || []);
  const legacyLessonMap = { 'cross-plan': 'cross-inspection', 'f2l-pairs': 'f2l-basic-insert', 'two-look': 'oll-2look' };
  let migratedProgress = false;
  for (const [oldId, newId] of Object.entries(legacyLessonMap)) {
    if (completed.has(oldId)) { completed.delete(oldId); completed.add(newId); migratedProgress = true; }
  }
  if (migratedProgress) { data.academyProgress = { completed: [...completed] }; persist(); }
  $('#academy-completion').textContent = `${completed.size}/${CFOP_LESSONS.length}`;
  const visibleLessons = CFOP_LESSONS.filter(lesson => academyStageFilter === 'ALL' || lesson.stage === academyStageFilter);
  $('#academy-lessons').innerHTML = visibleLessons.map(lesson => `<article class="panel academy-lesson ${completed.has(lesson.id) ? 'is-complete' : ''}"><div class="academy-lesson-top"><span class="alg-type ${lesson.stage.toLowerCase().replace('-', '')}">${lesson.stage}</span><small>${lesson.level} · ${lesson.minutes} phút</small></div><h3>${esc(lesson.title)}</h3><p>${esc(lesson.body)}</p><div class="academy-drill"><strong>Bài tập</strong><span>${esc(lesson.drill)}</span></div><button class="secondary-button small-button" data-academy-complete="${lesson.id}">${completed.has(lesson.id) ? '✓ Đã hoàn thành' : 'Đánh dấu hoàn thành'}</button></article>`).join('');
  $$('[data-academy-filter]').forEach(button => button.classList.toggle('active', button.dataset.academyFilter === academyStageFilter));
  renderAcademyPractice();
  renderCfopPracticeLab();
}

function renderAcademyPractice() {
  const item = CFOP_CASES.find(entry => entry.id === academyCurrentCaseId);
  const name = $('#academy-practice-name');
  if (!name) return;
  if (!item) {
    name.textContent = 'Chưa chọn case';
    $('#academy-case-visual').innerHTML = '';
    $('#academy-practice-detail').textContent = 'Chọn nhóm F2L, OLL hoặc PLL rồi nhấn tạo case ngẫu nhiên.';
    $('#academy-practice-formula').textContent = '';
    $('#academy-practice-formula').classList.add('hidden');
    $('#academy-reveal-case').disabled = true;
    $('#academy-train-case').disabled = true;
    $('#academy-visualize-case').disabled = true;
    $$('#academy-practice-ratings [data-academy-rating]').forEach(button => { button.disabled = true; });
    return;
  }
  name.textContent = `${item.name} · ${item.type}`;
  $('#academy-case-visual').innerHTML = renderCfopCaseDiagram(item, caseMoves(item));
  $('#academy-practice-tag').textContent = item.type;
  $('#academy-practice-tag').className = `alg-type ${item.type.toLowerCase()}`;
  $('#academy-practice-detail').textContent = item.family ? `${item.family} · Sticker trắng ${stickerDirectionLabel(item.whiteSticker)}` : `Case ${item.type} trong thư viện 119 trường hợp CFOP.`;
  $('#academy-practice-formula').textContent = caseMoves(item);
  $('#academy-practice-formula').classList.toggle('hidden', !academyAnswerVisible);
  $('#academy-reveal-case').disabled = false;
  $('#academy-reveal-case').textContent = academyAnswerVisible ? 'Ẩn công thức' : 'Hiện công thức';
  $('#academy-train-case').disabled = false;
  $('#academy-visualize-case').disabled = false;
  $$('#academy-practice-ratings [data-academy-rating]').forEach(button => { button.disabled = !academyAnswerVisible; });
}

function chooseAcademyCase() {
  const type = $('#academy-practice-type').value;
  const pool = CFOP_CASES.filter(item => item.type === type);
  if (!pool.length) return;
  const current = academyCurrentCaseId;
  const choices = pool.filter(item => item.id !== current);
  const selected = (choices.length ? choices : pool)[Math.floor(Math.random() * (choices.length || pool.length))];
  academyCurrentCaseId = selected.id;
  academyAnswerVisible = false;
  renderAcademyPractice();
}

function rateAcademyCase(rating) {
  const item = CFOP_CASES.find(entry => entry.id === academyCurrentCaseId);
  if (!item) return;
  const updated = scheduleReview(getCaseProgress(item.id), rating);
  data.caseProgress[item.id] = { ...getCaseProgress(item.id), ...updated };
  persist();
  renderAcademyPractice();
  renderCaseLibrary();
  toast(`Đã lưu mức ôn tập cho ${item.name}.`);
}

function renderCfopPracticeLab() {
  const select = $('#cfop-f2l-case');
  if (select && select.dataset.ready !== 'true') {
    select.innerHTML = F2L_CASES.map(item => `<option value="${esc(item.id)}">${esc(item.name)} · ${esc(item.family || 'F2L')}</option>`).join('');
    select.dataset.ready = 'true';
  }
  const practice = data.cfopPractice || (data.cfopPractice = { crossLogs: [], f2lLogs: [] });
  $('#cfop-cross-scramble').value = cfopDrillScramble;
  $('#cfop-cross-source').textContent = cfopDrillScrambleSource === 'cubing.js' ? 'Cubing.js scramble' : 'Practice-only sequence';
  const cross = practice.crossLogs || [];
  const averageMoves = cross.length ? cross.reduce((sum, item) => sum + item.moveCount, 0) / cross.length : null;
  const averageRotations = cross.length ? cross.reduce((sum, item) => sum + item.rotationCount, 0) / cross.length : null;
  $('#cfop-cross-summary').textContent = cross.length ? `${cross.length} lần ghi · trung bình ${averageMoves.toFixed(1)} move · ${averageRotations.toFixed(1)} rotation` : 'Chưa có lần ghi Cross nào.';
  $('#cfop-cross-recent').innerHTML = cross.length ? cross.slice(-5).reverse().map(entry => `<div class="cfop-log-row"><strong>${entry.moveCount} move</strong><span>${entry.rotationCount} rotation</span><small>${formatDate(entry.createdAt)}</small><code>${esc(entry.moves)}</code></div>`).join('') : '<p class="muted small-note">Kết quả Cross đã ghi sẽ xuất hiện ở đây.</p>';
  const f2l = practice.f2lLogs || [];
  const meanPauses = f2l.length ? f2l.reduce((sum, item) => sum + item.pauseCount, 0) / f2l.length : null;
  const meanRotations = f2l.length ? f2l.reduce((sum, item) => sum + item.rotationCount, 0) / f2l.length : null;
  $('#cfop-f2l-summary').textContent = f2l.length ? `${f2l.length} lần ghi · trung bình ${meanPauses.toFixed(1)} pause · ${meanRotations.toFixed(1)} rotation` : 'Chưa có lần ghi F2L nào.';
  $('#cfop-f2l-recent').innerHTML = f2l.length ? f2l.slice(-5).reverse().map(entry => { const item = F2L_CASES.find(candidate => candidate.id === entry.caseId); return `<div class="cfop-log-row"><strong>${esc(item?.name || entry.caseId)}</strong><span>${entry.pauseCount} pause · ${entry.rotationCount} rotation</span><small>${(entry.durationMs / 1000).toFixed(2)} giây · ${formatDate(entry.createdAt)}</small></div>`; }).join('') : '<p class="muted small-note">Kết quả F2L đã ghi sẽ xuất hiện ở đây.</p>';
}

async function createCfopCrossScramble() {
  const button = $('#cfop-cross-scramble-button');
  button.disabled = true;
  button.textContent = 'Đang tạo…';
  try {
    [cfopDrillScramble] = await generateCubingJsScrambles('3x3', 1);
    cfopDrillScrambleSource = 'cubing.js';
  } catch (error) {
    cfopDrillScramble = generatePracticeScramble(25);
    cfopDrillScrambleSource = 'practice';
    toast(`Không tải được cubing.js; đã tạo chuỗi luyện tập, không phải random-state. ${error.message}`, 'error');
  } finally {
    button.disabled = false;
    button.textContent = '↻ Scramble mới';
    renderCfopPracticeLab();
  }
}

function saveCrossPractice() {
  const moves = $('#cfop-cross-moves').value.trim();
  if (!isValidNotation(moves)) return toast('Nhập chuỗi Cross hợp lệ trước khi lưu.', 'error');
  const tokens = moves.split(/\s+/);
  const rotationCount = tokens.filter(token => /^[xyz]/.test(token)).length;
  const moveCount = tokens.length - rotationCount;
  const entry = { id: makeId('cross'), scramble: cfopDrillScramble, moves, moveCount, rotationCount, createdAt: new Date().toISOString() };
  data.cfopPractice.crossLogs = [...(data.cfopPractice.crossLogs || []), entry].slice(-200);
  persist(); renderCfopPracticeLab();
  toast(`Đã lưu Cross: ${moveCount} move, ${rotationCount} rotation.`);
}

function saveF2LPractice() {
  const caseId = $('#cfop-f2l-case').value;
  const rotationCount = Number($('#cfop-f2l-rotations').value);
  const pauseCount = Number($('#cfop-f2l-pauses').value);
  const seconds = Number($('#cfop-f2l-seconds').value);
  if (!F2L_CASES.some(item => item.id === caseId) || ![rotationCount, pauseCount, seconds].every(Number.isFinite) || rotationCount < 0 || pauseCount < 0 || seconds < 0 || rotationCount > 100 || pauseCount > 100 || seconds > 3600) return toast('Kiểm tra lại số rotation, pause và thời gian.', 'error');
  const entry = { id: makeId('f2l'), caseId, rotationCount: Math.trunc(rotationCount), pauseCount: Math.trunc(pauseCount), durationMs: Math.round(seconds * 1000), createdAt: new Date().toISOString() };
  data.cfopPractice.f2lLogs = [...(data.cfopPractice.f2lLogs || []), entry].slice(-200);
  persist(); renderCfopPracticeLab();
  toast('Đã lưu kết quả theo dõi F2L.');
}

function knowledgeCategoryLabel(categoryId) {
  return KNOWLEDGE_CATEGORIES.find(category => category.id === categoryId)?.label || 'Kiến thức';
}

function renderKnowledgeBase() {
  const categorySelect = $('#knowledge-category');
  if (!categorySelect.options.length) {
    categorySelect.innerHTML = KNOWLEDGE_CATEGORIES.map(category => `<option value="${esc(category.id)}">${esc(category.label)}</option>`).join('');
  }
  const query = $('#knowledge-search').value.trim().toLocaleLowerCase('vi');
  const category = categorySelect.value || 'all';
  const articles = KNOWLEDGE_ARTICLES.filter(article => {
    const content = [article.title, article.excerpt, article.category, ...article.sections.flatMap(section => [section.heading, ...(section.paragraphs || []), ...(section.bullets || [])])].join(' ').toLocaleLowerCase('vi');
    return (category === 'all' || article.category === category) && (!query || content.includes(query));
  });
  $('#knowledge-count').textContent = `${articles.length}/${KNOWLEDGE_ARTICLES.length} bài viết`;
  const results = $('#knowledge-results');
  const reader = $('#knowledge-reader');
  const current = KNOWLEDGE_ARTICLES.find(article => article.id === currentKnowledgeArticleId);
  if (current) {
    results.classList.add('hidden');
    reader.classList.remove('hidden');
    reader.innerHTML = renderKnowledgeArticle(current);
    return;
  }
  reader.classList.add('hidden');
  results.classList.remove('hidden');
  results.innerHTML = articles.length ? articles.map(article => `
    <button class="panel knowledge-card" data-open-article="${esc(article.id)}">
      <span class="knowledge-card-top"><span class="knowledge-tag">${esc(knowledgeCategoryLabel(article.category))}</span><small>${article.readMinutes} phút đọc</small></span>
      <strong>${esc(article.title)}</strong><span class="knowledge-card-excerpt">${esc(article.excerpt)}</span><span class="knowledge-card-link">Đọc bài viết <b>→</b></span>
    </button>`).join('') : '<div class="panel knowledge-empty"><strong>Không tìm thấy bài viết phù hợp.</strong><p>Thử từ khóa khác hoặc chọn danh mục Tất cả chủ đề.</p></div>';
}

function renderKnowledgeArticle(article) {
  const sections = article.sections.map(section => `
    <section class="knowledge-section"><h3>${esc(section.heading)}</h3>
      ${(section.paragraphs || []).map(paragraph => `<p>${esc(paragraph)}</p>`).join('')}
      ${(section.bullets || []).length ? `<ul>${section.bullets.map(item => `<li>${esc(item)}</li>`).join('')}</ul>` : ''}
      ${section.note ? `<div class="knowledge-note">${esc(section.note)}</div>` : ''}
    </section>`).join('');
  const related = (article.related || []).map(id => KNOWLEDGE_ARTICLES.find(item => item.id === id)).filter(Boolean);
  return `<div class="knowledge-reader-top"><button class="text-button" data-knowledge-back>← Tất cả bài viết</button><span class="knowledge-tag">${esc(knowledgeCategoryLabel(article.category))}</span></div>
    <div class="knowledge-article-meta">${article.readMinutes} phút đọc · Rubik Universe Knowledge Base</div>
    <h2>${esc(article.title)}</h2><p class="knowledge-lead">${esc(article.excerpt)}</p><div class="knowledge-article-body">${sections}</div>
    ${related.length ? `<div class="knowledge-related"><h3>Chủ đề liên quan</h3><div>${related.map(item => `<button class="secondary-button small-button" data-knowledge-related="${esc(item.id)}">${esc(item.title)} ↗</button>`).join('')}</div></div>` : ''}`;
}

function openKnowledgeArticle(articleId) {
  if (!KNOWLEDGE_ARTICLES.some(article => article.id === articleId)) return;
  currentKnowledgeArticleId = articleId;
  renderKnowledgeBase();
  $('#knowledge-reader').scrollIntoView({ behavior: data.settings.reducedMotion ? 'auto' : 'smooth', block: 'start' });
}

function renderStats() {
  const all = $('#stats-session-filter').value === 'all';
  const from = $('#stats-date-from')?.value ? new Date(`${$('#stats-date-from').value}T00:00:00`) : null;
  const to = $('#stats-date-to')?.value ? new Date(`${$('#stats-date-to').value}T23:59:59.999`) : null;
  const baseSolves = all ? data.solves : sessionSolves();
  const puzzleFilter = $('#stats-puzzle-filter')?.value || 'all';
  const puzzleSolves = filterSolvesByPuzzle(baseSolves, puzzleFilter, data.sessions);
  const solves = puzzleSolves.filter(solve => { const date = new Date(solve.createdAt); return (!from || date >= from) && (!to || date <= to); }).slice().sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  const finite = solves.map(effectiveTime).filter(Number.isFinite);
  const best = finite.length ? Math.min(...finite) : null;
  $('#stats-best').textContent = displayTime(best);
  $('#stats-best-ao5').textContent = displayTime(bestAverage(solves, 5));
  $('#stats-best-ao12').textContent = displayTime(bestAverage(solves, 12));
  $('#stats-ao50').textContent = displayTime(bestAverage(solves, 50));
  $('#stats-mean3').textContent = displayTime(solves.length >= 3 ? meanOf(solves.slice(-3)) : null);
  $('#stats-mean').textContent = displayTime(meanOf(solves));
  const dnf = solves.filter(solve => solve.penalty === 'DNF').length;
  const plus2 = solves.filter(solve => solve.penalty === '+2').length;
  $('#stats-count').textContent = String(solves.length);
  $('#stats-total-time').textContent = formatDuration(solves.reduce((sum, solve) => sum + (Number.isFinite(solve.rawMs) ? solve.rawMs : 0), 0));
  $('#stats-dnf').textContent = String(dnf);
  $('#stats-plus2').textContent = String(plus2);
  $('#stats-dnf-rate').textContent = solves.length ? `${Math.round(dnf / solves.length * 100)}%` : '0%';
  $('#stats-ao100').textContent = displayTime(averageOf(solves, 100));
  const recentTimes = solves.slice(-100).map(effectiveTime).filter(Number.isFinite);
  const average = recentTimes.length ? recentTimes.reduce((sum, value) => sum + value, 0) / recentTimes.length : null;
  const deviation = average === null ? null : Math.sqrt(recentTimes.reduce((sum, value) => sum + ((value - average) ** 2), 0) / recentTimes.length);
  $('#stats-stability').textContent = deviation === null ? '—' : `± ${(deviation / 1000).toFixed(2)}s`;
  $('#stats-week-solves').textContent = String(countRecentSolves(solves, 7));
  $('#stats-streak').textContent = `${activityStreak(solves)} ngày`;
  renderChart(solves);
  renderDailyChart(solves);
  renderDistributionChart(solves);
  renderSessionComparison(solves);
  $('#stats-table').innerHTML = solves.length ? solves.slice().reverse().map(solve => {
    const session = data.sessions.find(item => item.id === solve.sessionId);
    return `<tr><td>${esc(session?.name || 'Session đã xóa')}</td><td><strong class="table-time">${displayTime(effectiveTime(solve))}</strong></td><td>${formatDate(solve.createdAt)}</td><td class="scramble-cell" title="${esc(solve.scramble)}">${esc(solve.scramble || '—')}</td></tr>`;
  }).join('') : '<tr><td colspan="4" class="table-empty">Chưa có dữ liệu.</td></tr>';
}

function formatDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return hours ? `${hours}h ${minutes}m` : `${minutes}m`;
}

function renderChart(solves) {
  const chart = $('#solve-chart');
  const values = solves.slice(-24).map(effectiveTime).filter(Number.isFinite);
  if (!values.length) { chart.innerHTML = '<div class="chart-empty">Biểu đồ sẽ xuất hiện khi có ít nhất một lượt solve hợp lệ.</div>'; return; }
  const max = Math.max(...values) * 1.12 || 1;
  chart.innerHTML = `<div class="chart-bars">${values.map((value, index) => `<div class="chart-bar-wrap" title="${displayTime(value)}"><div class="chart-bar" style="height:${Math.max(5, value / max * 100)}%"></div><small>${index + 1}</small></div>`).join('')}</div><div class="chart-axis"><span>${displayTime(Math.max(...values))}</span><span>${displayTime(Math.min(...values))}</span></div>`;
}

function renderDailyChart(solves) {
  const chart = $('#stats-daily-chart');
  const groups = new Map();
  solves.forEach(solve => {
    const value = effectiveTime(solve); if (!Number.isFinite(value)) return;
    const date = new Date(solve.createdAt); if (Number.isNaN(date.getTime())) return;
    const key = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
    const group = groups.get(key) || []; group.push(value); groups.set(key, group);
  });
  const values = [...groups.entries()].slice(-14);
  if (!values.length) { chart.innerHTML = '<div class="chart-empty">Cần có solve hợp lệ để hiển thị tiến bộ theo ngày.</div>'; return; }
  const max = Math.max(...values.map(([,times]) => times.reduce((a,b)=>a+b,0)/times.length)) || 1;
  chart.innerHTML = `<div class="chart-bars">${values.map(([date,times]) => { const avg=times.reduce((a,b)=>a+b,0)/times.length; return `<div class="chart-bar-wrap" title="${date}: ${displayTime(avg)} · ${times.length} solve"><div class="chart-bar" style="height:${Math.max(5,avg/max*100)}%"></div><small>${date.slice(5)}</small></div>`; }).join('')}</div><div class="chart-axis"><span>${displayTime(max)}</span><span>Trung bình/ngày</span></div>`;
}

function renderDistributionChart(solves) {
  const chart = $('#stats-distribution-chart');
  const values = solves.map(effectiveTime).filter(Number.isFinite);
  if (!values.length) { chart.innerHTML = '<div class="chart-empty">Chưa có solve hợp lệ để phân bố thời gian.</div>'; return; }
  const min = Math.min(...values), max = Math.max(...values);
  const bucketCount = Math.min(6, Math.max(3, Math.ceil(Math.sqrt(values.length))));
  const width = Math.max(1, (max - min + 1) / bucketCount);
  const buckets = Array.from({length:bucketCount},(_,i)=>({from:min+i*width,to:min+(i+1)*width,count:0}));
  values.forEach(value => { const index = Math.min(bucketCount-1, Math.floor((value-min)/width)); buckets[index].count += 1; });
  const top = Math.max(...buckets.map(bucket=>bucket.count),1);
  chart.innerHTML = `<div class="chart-bars">${buckets.map(bucket=>`<div class="chart-bar-wrap" title="${displayTime(bucket.from)}–${displayTime(bucket.to)}: ${bucket.count} solve"><div class="chart-bar" style="height:${Math.max(4,bucket.count/top*100)}%"></div><small>${bucket.count}</small></div>`).join('')}</div><div class="chart-axis"><span>${displayTime(min)}</span><span>${displayTime(max)}</span></div>`;
}

function renderSessionComparison(filteredSolves = data.solves) {
  const rows = data.sessions.map(session => { const solves=filteredSolves.filter(solve => solve.sessionId === session.id); const finite=solves.map(effectiveTime).filter(Number.isFinite); return {session,solves,best:finite.length?Math.min(...finite):null,mean:meanOf(solves),ao5:averageOf(solves,5)}; });
  $('#stats-session-comparison').innerHTML = rows.length ? rows.map(row=>`<tr><td>${esc(row.session.name)}</td><td>${row.solves.length}</td><td>${displayTime(row.best)}</td><td>${displayTime(row.mean)}</td><td>${displayTime(row.ao5)}</td></tr>`).join('') : '<tr><td colspan="5" class="table-empty">Chưa có session.</td></tr>';
}

function renderSessions() {
  $('#session-grid').innerHTML = data.sessions.map(session => {
    const solves = sessionSolves(session.id);
    const finite = solves.map(effectiveTime).filter(Number.isFinite);
    const best = finite.length ? Math.min(...finite) : null;
    return `<article class="session-card ${session.id === data.activeSessionId ? 'selected' : ''}"><div class="session-card-head"><span class="session-puzzle">${esc(session.puzzle)}</span><button class="icon-button tiny" data-session-menu="${esc(session.id)}">···</button></div><h3>${esc(session.name)}</h3><p>${solves.length} lượt solve · Tạo ${formatDate(session.createdAt)}</p><div class="session-card-stats"><div><small>BEST SINGLE</small><strong>${displayTime(best)}</strong></div><div><small>AVERAGE</small><strong>${displayTime(meanOf(solves))}</strong></div></div><div class="session-card-bottom">${session.id === data.activeSessionId ? '<span class="active-label"><i></i> Đang hoạt động</span>' : `<button class="text-button" data-activate-session="${esc(session.id)}">Chuyển sang session →</button>`}</div></article>`;
  }).join('');
}

function createSession() {
  const body = `<form class="modal-form"><label>Tên session <input name="name" placeholder="Ví dụ: 3x3 F2L, luyện sub-20..." required /></label><label>Loại Rubik<select name="puzzle"><option value="2x2">2×2 Cube</option><option value="3x3">3×3 Cube</option><option value="4x4">4×4 Cube</option><option value="5x5">5×5 Cube</option><option value="6x6">6×6 Cube</option><option value="7x7">7×7 Cube</option><option value="Pyraminx">Pyraminx</option><option value="Skewb">Skewb</option><option value="Megaminx">Megaminx</option><option value="Square-1">Square-1</option><option value="Clock">Clock</option></select></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">Tạo session</button></div></form>`;
  openModal('Tạo session mới', body, form => {
    const name = String(form.get('name')).trim();
    if (!name) { toast('Hãy nhập tên session.', 'error'); return false; }
    const session = { id: makeId('session'), name, puzzle: form.get('puzzle'), createdAt: new Date().toISOString() };
    data.sessions.push(session); data.activeSessionId = session.id;
    persist(); updateSessionLabels(); renderSessions(); renderTimerPage(); renderHome(); toast('Đã tạo và chuyển sang session mới.');
  });
}

function sessionMenu(id) {
  const session = data.sessions.find(item => item.id === id);
  if (!session) return;
  const body = `<div class="session-menu-actions"><button class="secondary-button" id="rename-session">✎ Đổi tên session</button><button class="danger-button" id="delete-session">× Xóa session</button></div>`;
  openModal(session.name, body);
  $('#rename-session').addEventListener('click', () => {
    closeModal();
    const renameBody = `<form class="modal-form"><label>Tên mới <input name="name" value="${esc(session.name)}" required /></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">Lưu</button></div></form>`;
    openModal('Đổi tên session', renameBody, form => {
      const name = String(form.get('name')).trim(); if (!name) return false;
      session.name = name; persist(); renderSessions(); updateSessionLabels(); renderTimerPage(); renderHome(); toast('Đã đổi tên session.');
    });
  });
  $('#delete-session').addEventListener('click', () => {
    closeModal();
    if (data.sessions.length <= 1) return toast('Cần giữ lại ít nhất một session.', 'error');
    if (session.id === solveSessionId && !['idle', 'stopped'].includes(timerState)) return toast('Hãy dừng timer trước khi xóa session đang được sử dụng.', 'error');
    if (!confirm(`Xóa session “${session.name}” cùng toàn bộ lượt solve bên trong?`)) return;
    data.sessions = data.sessions.filter(item => item.id !== id);
    data.solves = data.solves.filter(solve => solve.sessionId !== id);
    if (data.activeSessionId === id) data.activeSessionId = data.sessions[0].id;
    persist(); renderSessions(); renderTimerPage(); renderHome(); renderStats(); toast('Đã xóa session và dữ liệu liên quan.');
  });
}

function exportSolvesCsv() {
  const all = $('#stats-session-filter').value === 'all';
  const solves = (all ? data.solves : sessionSolves()).slice().sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  const headers = ['Session', 'Puzzle', 'Raw time ms', 'Penalty', 'Effective time ms', 'Scramble', 'Note', 'Date ISO'];
  const rows = solves.map(solve => {
    const session = data.sessions.find(item => item.id === solve.sessionId);
    return [session?.name || 'Session deleted', solve.puzzle || '3x3', solve.rawMs, solve.penalty, Number.isFinite(effectiveTime(solve)) ? effectiveTime(solve) : 'DNF', solve.scramble || '', solve.note || '', solve.createdAt];
  });
  const escapeCsv = value => `"${String(value ?? '').replace(/"/g, '""')}"`;
  const csv = [headers, ...rows].map(row => row.map(escapeCsv).join(',')).join('\r\n');
  const blob = new Blob(['\uFEFF', csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url; link.download = `rubik-solves-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.append(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  toast(`Đã xuất ${solves.length} lượt solve ra CSV.`);
}

function exportData() {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url; link.download = `rubik-universe-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.append(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  toast('Đã xuất bản sao lưu JSON.');
}

async function importData(file) {
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    const restored = migrateData(parsed);
    if (!restored) throw new Error('invalid');
    if (!confirm(`Nhập bản sao lưu gồm ${restored.sessions.length} session, ${restored.solves.length} lượt solve và ${restored.algorithms.length} công thức cá nhân? Dữ liệu hiện tại sẽ được thay thế.`)) return;
    cancelAnimationFrame(timerFrame); window.clearTimeout(holdTimer); holdActive = false;
    setTimerState('idle', 'READY TO SOLVE', 'NHẤN SPACE HOẶC CHẠM ĐỂ BẮT ĐẦU'); $('#timer-time').textContent = displayTime(0);
    Object.keys(data).forEach(key => delete data[key]);
    Object.assign(data, restored);
    data.training = normalizeTraining(data.training);
    solverFacelets = validateFacelets(data.solverDraft || SOLVED_FACELETS).valid ? (data.solverDraft || SOLVED_FACELETS) : SOLVED_FACELETS;
    solverSolution = '';
    persist(); setTheme(data.settings.theme); syncSettings(); renderAll(); toast('Đã nhập bản sao lưu cũ.');
  } catch {
    toast('Không thể nhập file. Hãy chọn bản sao lưu Rubik Universe hợp lệ.', 'error');
  } finally { $('#import-data').value = ''; }
}

function syncSettings() {
  applyDisplaySettings();
  $('#inspection-state').textContent = data.settings.inspection ? 'ON' : 'OFF';
  $('#inspection-toggle').classList.toggle('is-off', !data.settings.inspection);
  if ($('#timer-decimals')) $('#timer-decimals').value = String(data.settings.timerDecimals || 2);
}

function searchGlobal(query) {
  const normalized = query.toLocaleLowerCase('vi');
  const results = searchIndex.filter(item => `${item.title} ${item.description}`.toLocaleLowerCase('vi').includes(normalized)).slice(0, 5);
  const articleResults = KNOWLEDGE_ARTICLES.filter(article => [article.title, article.excerpt, ...article.sections.flatMap(section => [section.heading, ...(section.paragraphs || []), ...(section.bullets || [])])].join(' ').toLocaleLowerCase('vi').includes(normalized)).slice(0, 4).map(article => ({ title: article.title, description: `${knowledgeCategoryLabel(article.category)} · Bài viết kiến thức`, page: 'explore', articleId: article.id }));
  const algResults = data.algorithms.filter(alg => `${alg.name} ${alg.type} ${alg.moves}`.toLocaleLowerCase('vi').includes(normalized)).slice(0, 3).map(alg => ({ title: alg.name, description: `${alg.type} · Công thức cá nhân`, page: 'algorithms', caseId: `CUSTOM-${alg.id}` }));
  const caseResults = CFOP_CASES.filter(item => `${item.name} ${item.type} ${item.moves}`.toLocaleLowerCase('vi').includes(normalized)).slice(0, 4).map(item => ({ title: item.name, description: `${item.type} · Case CFOP chuẩn`, page: 'algorithms', caseId: item.id }));
  return [...results, ...articleResults, ...caseResults, ...algResults].slice(0, 10);
}

function renderSearchResults(query) {
  const box = $('#search-results');
  if (!query.trim()) { box.classList.add('hidden'); return; }
  const results = searchGlobal(query.trim());
  box.innerHTML = results.length ? results.map((item, index) => `<button class="search-result" data-search-page="${item.page}" ${item.caseId ? `data-search-case="${esc(item.caseId)}"` : ''} ${item.articleId ? `data-search-article="${esc(item.articleId)}"` : ''}><span>${esc(item.title)}</span><small>${esc(item.description)}</small><kbd>${index + 1}</kbd></button>`).join('') : '<div class="search-no-results">Không tìm thấy kết quả phù hợp.</div>';
  box.classList.remove('hidden');
}

searchIndex = [
  { title: 'Tổng quan', description: 'Dashboard và thành tích', page: 'home' },
  { title: 'Rubik Timer', description: 'Bấm giờ, inspection và penalty', page: 'timer' },
  { title: 'Scramble Center', description: 'Tạo scramble 2×2 đến 7×7 và xem lịch sử', page: 'scrambles' },
  { title: 'CFOP Academy', description: 'Lộ trình Cross, F2L lookahead, OLL và PLL', page: 'academy' },
  { title: 'Thư viện thuật toán', description: 'OLL, PLL, F2L và công thức cá nhân', page: 'algorithms' },
  { title: 'Algorithm Trainer', description: 'Luyện ghi nhớ công thức F2L, OLL, PLL', page: 'trainer' },
  { title: '3×3 Solver', description: 'Nhập 54 sticker, kiểm tra và tìm lời giải', page: 'solver' },
  { title: 'Training Center', description: 'Kế hoạch luyện tập và tiến độ hằng ngày', page: 'training' },
  { title: 'Rubik 3D Visualizer', description: 'Mô phỏng cube theo từng move, phát lại công thức', page: 'visualizer' },
  { title: 'Thống kê', description: 'Single, Ao5, Ao12 và biểu đồ', page: 'stats' },
  { title: 'Sessions', description: 'Quản lý buổi luyện tập', page: 'sessions' },
  { title: 'Thư viện kiến thức', description: '29 bài viết: cấu tạo, notation, phương pháp và kỹ thuật speedcubing', page: 'explore' },
  { title: 'Cài đặt', description: 'Giao diện, inspection và sao lưu', page: 'settings' }
];

function showKeyboardHelp() {
  openModal('Phím tắt', `<div class="shortcut-list"><div><kbd>Ctrl</kbd> / <kbd>⌘</kbd> + <kbd>K</kbd><span>Mở tìm kiếm toàn cục</span></div><div><kbd>Space</kbd><span>Bắt đầu / dừng Timer khi ở trang Timer</span></div><div><kbd>N</kbd><span>Tạo scramble mới khi ở trang Timer</span></div><div><kbd>?</kbd><span>Mở bảng phím tắt</span></div><div><kbd>Esc</kbd><span>Đóng hộp thoại hoặc kết quả tìm kiếm</span></div></div>`);
}

function renderAll() {
  renderHome(); renderKnowledgeBase(); renderTimerPage(); renderScrambleCenter(); renderAcademy(); renderCaseLibrary(); renderAlgorithms(); renderTrainer(); renderSolver(); renderTraining(); renderVisualizer(); renderStats(); renderSessions(); syncSettings();
}

// Navigation and shared controls.
$$('[data-page]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.page)));
document.addEventListener('click', event => {
  const solverSticker = event.target.closest('[data-solver-sticker]');
  if (solverSticker) {
    const index = Number(solverSticker.dataset.solverSticker);
    const current = solverFacelets[index];
    const nextColor = FACE_ORDER[(FACE_ORDER.indexOf(current) + 1) % FACE_ORDER.length];
    updateSolverFacelets(solverFacelets.slice(0, index) + nextColor + solverFacelets.slice(index + 1));
  }
  const trainingTask = event.target.closest('[data-training-task]');
  if (trainingTask) {
    const today = getTodayCompletion();
    const taskId = trainingTask.dataset.trainingTask;
    const ids = new Set(today.taskIds);
    if (ids.has(taskId)) ids.delete(taskId); else ids.add(taskId);
    const next = { date: today.date, taskIds: [...ids] };
    data.training.completions = data.training.completions.filter(entry => entry.date !== today.date);
    data.training.completions.push(next);
    persist(); renderTraining();
  }
  const go = event.target.closest('[data-go]');
  if (go) navigate(go.dataset.go);
  if (event.target.closest('[data-cancel-modal]')) closeModal();
  if (event.target.closest('#empty-add-alg')) addAlgorithm();
  const academyDone = event.target.closest('[data-academy-complete]'); if (academyDone) { const id = academyDone.dataset.academyComplete; const set = new Set(data.academyProgress?.completed || []); set.has(id) ? set.delete(id) : set.add(id); data.academyProgress = { completed: [...set] }; persist(); renderAcademy(); }
  const historyCopy = event.target.closest('[data-copy-history]'); if (historyCopy) { const item = data.scrambleHistory.find(entry => entry.id === historyCopy.dataset.copyHistory); if (item) navigator.clipboard.writeText(item.scramble).then(() => toast('Đã sao chép scramble.')).catch(() => toast('Không thể sao chép.', 'error')); }
  const historyUse = event.target.closest('[data-use-history]'); if (historyUse) { const item = data.scrambleHistory.find(entry => entry.id === historyUse.dataset.useHistory); if (item) { if (activeSession()) activeSession().puzzle = item.puzzle; currentScramble = item.scramble; currentScrambleType = (item.isGenerated ?? item.isWca) ? 'generated' : 'practice'; currentScrambleGenerator = item.generator || ((item.isGenerated ?? item.isWca) ? (item.puzzle === '3x3' ? 'cubejs' : 'cubing.js') : 'practice'); currentScramblePuzzle = item.puzzle; preserveNextTimerScramble = true; persist(); navigate('timer'); updateTimerScrambleText(); toast(`Đã chuyển scramble ${getPuzzleLabel(item.puzzle)} vào Timer.`); } }
  const batchCopy = event.target.closest('[data-copy-batch]'); if (batchCopy) { const items = JSON.parse($('#scramble-batch').dataset.items || '[]'); const item = items[Number(batchCopy.dataset.copyBatch)]; if (item) navigator.clipboard.writeText(item).then(() => toast('Đã sao chép.')).catch(() => toast('Không thể sao chép.', 'error')); }
  const openArticle = event.target.closest('[data-open-article],[data-knowledge-related]');
  if (openArticle) { openKnowledgeArticle(openArticle.dataset.openArticle || openArticle.dataset.knowledgeRelated); return; }
  if (event.target.closest('[data-knowledge-back]')) { currentKnowledgeArticleId = null; renderKnowledgeBase(); return; }
  const searchPage = event.target.closest('[data-search-page]');
  if (searchPage) { $('#search-results').classList.add('hidden'); $('#global-search').value = ''; if (searchPage.dataset.searchCase) { navigate('algorithms'); trainCase(searchPage.dataset.searchCase); } else { navigate(searchPage.dataset.searchPage); if (searchPage.dataset.searchArticle) openKnowledgeArticle(searchPage.dataset.searchArticle); } }
  const edit = event.target.closest('[data-edit-solve]'); if (edit) editSolve(edit.dataset.editSolve);
  const remove = event.target.closest('[data-delete-solve]'); if (remove) deleteSolve(remove.dataset.deleteSolve);
  const editAlg = event.target.closest('[data-edit-alg]'); if (editAlg) addAlgorithm(data.algorithms.find(alg => alg.id === editAlg.dataset.editAlg));
  const deleteAlg = event.target.closest('[data-delete-alg]'); if (deleteAlg) {
    const id = deleteAlg.dataset.deleteAlg;
    if (confirm('Xóa công thức này khỏi thư viện?')) { data.algorithms = data.algorithms.filter(alg => alg.id !== id); persist(); renderAlgorithms(); renderTrainer(); toast('Đã xóa công thức.'); }
  }
  const favorite = event.target.closest('[data-favorite-alg]'); if (favorite) {
    const alg = data.algorithms.find(item => item.id === favorite.dataset.favoriteAlg); if (alg) { alg.favorite = !alg.favorite; persist(); renderAlgorithms(); }
  }
  const train = event.target.closest('[data-train-alg]'); if (train) trainCase(`CUSTOM-${train.dataset.trainAlg}`);
  const copyCase = event.target.closest('[data-copy-case]'); if (copyCase) {
    const item = CFOP_CASES.find(entry => entry.id === copyCase.dataset.copyCase);
    if (item) navigator.clipboard?.writeText(caseMoves(item)).then(() => toast(`Đã sao chép ${item.name}.`)).catch(() => toast('Không thể sao chép trong trình duyệt này.', 'error'));
  }
  const favoriteCase = event.target.closest('[data-case-favorite]'); if (favoriteCase) {
    const id = favoriteCase.dataset.caseFavorite; data.caseProgress[id] = { ...getCaseProgress(id), favorite: !getCaseProgress(id).favorite }; persist(); renderCaseLibrary();
  }
  const editCase = event.target.closest('[data-edit-case]'); if (editCase) editCaseAlgorithm(editCase.dataset.editCase);
  const trainBuiltInCase = event.target.closest('[data-train-case]'); if (trainBuiltInCase) trainCase(trainBuiltInCase.dataset.trainCase);
  const visualizeBuiltInCase = event.target.closest('[data-visualize-case]'); if (visualizeBuiltInCase) jumpVisualizerToAlgorithm(visualizeBuiltInCase.dataset.visualizeCase);
  const visualizeMove = event.target.closest('[data-viz-jump]'); if (visualizeMove) setVisualizerStep(visualizeMove.dataset.vizJump);
  const activate = event.target.closest('[data-activate-session]'); if (activate) {
    data.activeSessionId = activate.dataset.activateSession; persist(); updateSessionLabels(); renderSessions(); renderTimerPage(); renderHome(); toast('Đã chuyển session.');
  }
  const menu = event.target.closest('[data-session-menu]'); if (menu) sessionMenu(menu.dataset.sessionMenu);
});

$('#theme-toggle').addEventListener('click', () => setTheme(data.settings.theme === 'dark' ? 'light' : 'dark'));
$('#mobile-menu').addEventListener('click', () => { const open = $('#sidebar').classList.toggle('open'); $('#mobile-menu').setAttribute('aria-expanded', String(open)); });
$('#shortcuts-help').addEventListener('click', showKeyboardHelp);
$('#quick-session').addEventListener('click', () => navigate('sessions'));
$('#modal-close').addEventListener('click', closeModal);
$('#modal-backdrop').addEventListener('click', event => { if (event.target.id === 'modal-backdrop') closeModal(); });
$('#global-search').addEventListener('input', event => renderSearchResults(event.target.value));
$('#knowledge-search').addEventListener('input', () => { currentKnowledgeArticleId = null; renderKnowledgeBase(); });
$('#knowledge-category').addEventListener('change', () => { currentKnowledgeArticleId = null; renderKnowledgeBase(); });
$('#knowledge-clear').addEventListener('click', () => { $('#knowledge-search').value = ''; $('#knowledge-category').value = 'all'; currentKnowledgeArticleId = null; renderKnowledgeBase(); });
$('#scramble-generate').addEventListener('click', generateCenterScrambles);
$('#academy-random-case').addEventListener('click', chooseAcademyCase);
$('#cfop-cross-scramble-button').addEventListener('click', createCfopCrossScramble);
$('#cfop-cross-save').addEventListener('click', saveCrossPractice);
$('#cfop-f2l-save').addEventListener('click', saveF2LPractice);
$('#academy-practice-type').addEventListener('change', chooseAcademyCase);
$('#academy-reveal-case').addEventListener('click', () => { academyAnswerVisible = !academyAnswerVisible; renderAcademyPractice(); });
$('#academy-train-case').addEventListener('click', () => { if (academyCurrentCaseId) trainCase(academyCurrentCaseId); });
$('#academy-visualize-case').addEventListener('click', () => {
  const item = CFOP_CASES.find(entry => entry.id === academyCurrentCaseId);
  if (!item) return;
  navigate('visualizer');
  loadVisualizerSequence(caseMoves(item), { label: `${item.name} · CFOP Academy` });
});
$('#academy-practice-ratings').addEventListener('click', event => {
  const button = event.target.closest('[data-academy-rating]');
  if (button) rateAcademyCase(button.dataset.academyRating);
});
$('#academy-filters').addEventListener('click', event => {
  const button = event.target.closest('[data-academy-filter]');
  if (!button) return;
  academyStageFilter = button.dataset.academyFilter;
  renderAcademy();
});
$('#scramble-copy-current').addEventListener('click', async () => { try { await navigator.clipboard.writeText($('#scramble-current').textContent); toast('Đã sao chép scramble.'); } catch { toast('Không thể sao chép.', 'error'); } });
$('#scramble-history-filter').addEventListener('change', renderScrambleCenter);
$('#scramble-clear-history').addEventListener('click', () => { if (!data.scrambleHistory?.length) return; if (!confirm('Xóa toàn bộ lịch sử scramble đã lưu?')) return; data.scrambleHistory = []; persist(); renderScrambleCenter(); toast('Đã xóa lịch sử scramble.'); });
$('#stats-session-filter').addEventListener('change', renderStats);
$('#stats-puzzle-filter').addEventListener('change', renderStats);
['stats-date-from','stats-date-to'].forEach(id => $(`#${id}`).addEventListener('change', renderStats));
$('#stats-clear-dates').addEventListener('click', () => { $('#stats-date-from').value = ''; $('#stats-date-to').value = ''; renderStats(); });
$('#global-search').addEventListener('keydown', event => { if (event.key === 'Escape') $('#search-results').classList.add('hidden'); if (event.key === 'Enter') $('.search-result')?.click(); });
document.addEventListener('keydown', event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); $('#global-search').focus(); }
});

// Timer controls.
$('#timer-display').addEventListener('click', timerTap);
$('#new-scramble').addEventListener('click', newScramble);
$('#copy-scramble').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(currentScramble); toast('Đã sao chép scramble.'); }
  catch { toast('Trình duyệt không cho phép sao chép tự động.', 'error'); }
});
$('#inspection-toggle').addEventListener('click', () => {
  data.settings.inspection = !data.settings.inspection; persist(); syncSettings();
  toast(`Inspection ${data.settings.inspection ? 'đã bật' : 'đã tắt'}.`);
});
$('#manual-solve').addEventListener('click', addManualSolve);
$('#add-manual-bottom').addEventListener('click', addManualSolve);
$('#reset-timer').addEventListener('click', () => {
  if (timerState === 'running') return toast('Không thể đặt lại khi timer đang chạy.', 'error');
  cancelAnimationFrame(timerFrame); setTimerState('idle', 'READY TO SOLVE', 'NHẤN SPACE HOẶC CHẠM ĐỂ BẮT ĐẦU'); $('#timer-time').textContent = displayTime(0);
});
$('#timer-puzzle').addEventListener('change', () => {
  if (['running', 'inspection', 'ready'].includes(timerState)) {
    $('#timer-puzzle').value = activeSession().puzzle;
    toast('Không thể đổi loại Rubik khi Timer đang hoạt động.', 'error');
    return;
  }
  const selected = $('#timer-puzzle').value;
  activeSession().puzzle = selected;
  solvePuzzle = selected;
  persist(); updateSessionLabels(); renderTimerPage(); renderHome();
  newScramble({ silent: true });
});
document.addEventListener('keydown', handleSpaceDown, { capture: true });
document.addEventListener('keyup', handleSpaceUp, { capture: true });
window.addEventListener('blur', () => releaseSpaceHold({ startOnRelease: false }));
document.addEventListener('visibilitychange', () => {
  if (document.hidden) releaseSpaceHold({ startOnRelease: false });
  else if (timerState === 'running') { cancelAnimationFrame(timerFrame); updateTimerDisplay(); }
});
document.addEventListener('keydown', event => {
  const modalOpen = !$('#modal-backdrop').classList.contains('hidden');
  if (modalOpen && event.key === 'Tab') {
    const focusable = $$('#modal-backdrop button:not([disabled]), #modal-backdrop input:not([disabled]), #modal-backdrop select:not([disabled]), #modal-backdrop textarea:not([disabled]), #modal-backdrop a[href], #modal-backdrop [tabindex]:not([tabindex="-1"])')
      .filter(element => element.getClientRects().length > 0);
    if (!focusable.length) {
      event.preventDefault();
      $('#modal-close').focus();
    } else {
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && (document.activeElement === first || !$('#modal-backdrop').contains(document.activeElement))) {
        event.preventDefault(); last.focus();
      } else if (!event.shiftKey && (document.activeElement === last || !$('#modal-backdrop').contains(document.activeElement))) {
        event.preventDefault(); first.focus();
      }
    }
    return;
  }
  const typing = isTypingTarget(event.target);
  if (event.key.toLowerCase() === 'n' && activePage === 'timer' && !typing && !modalOpen) { event.preventDefault(); newScramble(); }
  if (event.key === 'Escape') {
    if (modalOpen) closeModal();
    $('#search-results').classList.add('hidden');
  }
  if (event.key === '?' && !typing && !modalOpen) { event.preventDefault(); showKeyboardHelp(); }
});

// Algorithms and spaced practice.
$('#add-algorithm').addEventListener('click', () => addAlgorithm());
$('#empty-add-alg').addEventListener('click', () => addAlgorithm());
$('#algorithm-search').addEventListener('input', renderAlgorithms);
$('#case-search').addEventListener('input', renderCaseLibrary);
$$('[data-library-mode]').forEach(button => button.addEventListener('click', () => {
  const showCases = button.dataset.libraryMode === 'cases';
  $$('[data-library-mode]').forEach(item => item.classList.toggle('active', item === button));
  $('#case-library').classList.toggle('hidden', !showCases);
  $('#custom-library').classList.toggle('hidden', showCases);
}));
$('#case-filters').addEventListener('click', event => {
  const button = event.target.closest('[data-case-filter]'); if (!button) return;
  activeCaseFilter = button.dataset.caseFilter;
  $$('.filter-tab', $('#case-filters')).forEach(item => item.classList.toggle('active', item === button));
  renderCaseLibrary();
});
$('#algorithm-filters').addEventListener('click', event => {
  const button = event.target.closest('[data-filter]'); if (!button) return;
  activeAlgorithmFilter = button.dataset.filter;
  $$('.filter-tab', $('#algorithm-filters')).forEach(item => item.classList.toggle('active', item === button));
  renderAlgorithms();
});
$('#trainer-type').addEventListener('change', () => { trainerIndex = 0; renderTrainer(); });
$('#trainer-due-only').addEventListener('change', () => { trainerIndex = 0; renderTrainer(); });
$('#reveal-formula').addEventListener('click', () => {
  const alg = trainerQueue[trainerIndex]; if (!alg) return;
  trainerRevealed = !trainerRevealed;
  $('#trainer-formula').classList.toggle('hidden', !trainerRevealed);
  $('#flashcard').classList.toggle('revealed', trainerRevealed);
  $('#reveal-formula').innerHTML = trainerRevealed ? 'Ẩn công thức <span>↑</span>' : 'Hiện công thức <span>↓</span>';
});
$$('[data-trainer-rating]').forEach(button => button.addEventListener('click', () => trainerNext(button.dataset.trainerRating)));
$('#trainer-shuffle').addEventListener('click', () => { trainerQueue.sort(() => Math.random() - 0.5); trainerIndex = 0; showTrainerCard(); });

// Interactive 3D cube visualizer.
$('#viz-preset').addEventListener('change', () => {
  const item = CFOP_CASES.find(entry => entry.id === $('#viz-preset').value);
  if (item) $('#viz-sequence').value = caseMoves(item);
});
$('#viz-load-sequence').addEventListener('click', () => {
  const sequence = $('#viz-sequence').value.trim();
  const item = CFOP_CASES.find(entry => entry.id === $('#viz-preset').value);
  const isSelectedPreset = item && sequence === caseMoves(item);
  loadVisualizerSequence(sequence, {
    reverseStart: Boolean(isSelectedPreset),
    label: isSelectedPreset ? `${item.name} · ${item.type}` : 'Thuật toán tùy chỉnh'
  });
});
$('#viz-random-scramble').addEventListener('click', () => {
  const scramble = generatePracticeScramble(20);
  $('#viz-preset').value = '';
  loadVisualizerSequence(scramble, { label: 'Scramble luyện tập 3×3' });
});
$('#viz-previous').addEventListener('click', () => setVisualizerStep(visualizer.step - 1));
$('#viz-next').addEventListener('click', () => setVisualizerStep(visualizer.step + 1));
$('#viz-play').addEventListener('click', toggleVisualizerPlayback);
$('#viz-reset').addEventListener('click', () => setVisualizerStep(0));
$('#viz-progress').addEventListener('input', event => setVisualizerStep(event.target.value));
$('#viz-speed').addEventListener('change', () => {
  if (visualizer.interval) { stopVisualizerPlayback(); toggleVisualizerPlayback(); }
});
const cubeStage = $('#cube-stage');
let dragState = null;
cubeStage.addEventListener('pointerdown', event => {
  if (event.button !== 0 || event.target.closest('button')) return;
  dragState = { x: event.clientX, y: event.clientY, rotationX: visualizer.rotationX, rotationY: visualizer.rotationY };
  cubeStage.setPointerCapture?.(event.pointerId);
});
cubeStage.addEventListener('pointermove', event => {
  if (!dragState) return;
  visualizer.rotationY = dragState.rotationY + (event.clientX - dragState.x) * 0.7;
  visualizer.rotationX = Math.max(-80, Math.min(80, dragState.rotationX - (event.clientY - dragState.y) * 0.65));
  $('#viz-cube').style.transform = `rotateX(${visualizer.rotationX}deg) rotateY(${visualizer.rotationY}deg)`;
});
['pointerup', 'pointercancel', 'lostpointercapture'].forEach(type => cubeStage.addEventListener(type, () => { dragState = null; }));

// V4 Solver and Training Center.
$('#solver-reset').addEventListener('click', () => updateSolverFacelets(SOLVED_FACELETS));
$('#solver-scramble').addEventListener('click', () => {
  const scramble = generatePracticeScramble(25);
  const state = applyCubeMoves(createSolvedCube(), scramble);
  updateSolverFacelets(cubeToFaceletString(state));
  setSolverStatus('Đã tạo trạng thái thử', `Áp dụng scramble luyện tập: ${scramble}`, 0);
});
$('#solver-solve').addEventListener('click', requestCubeSolution);
$('#solver-copy').addEventListener('click', async () => {
  if (!solverSolution) return;
  try { await navigator.clipboard.writeText(solverSolution); toast('Đã sao chép lời giải.'); }
  catch { toast('Trình duyệt không cho phép sao chép.', 'error'); }
});
$('#solver-visualize').addEventListener('click', () => {
  if (!solverSolution) return;
  try {
    const baseCube = createCubeFromFaceletString(solverFacelets);
    const resultCube = applyCubeMoves(baseCube, solverSolution);
    if (!isCubeSolved(resultCube)) throw new Error('Mô hình 3D không xác minh được chuỗi move này.');
    navigate('visualizer');
    loadVisualizerSequence(solverSolution, { label: 'Lời giải Solver · Kociemba', baseCube });
    $('#viz-state-help').textContent = 'Trạng thái bắt đầu lấy từ 54 sticker bạn nhập; đang phát lời giải đã xác minh.';
  } catch (error) { toast(error.message, 'error'); }
});
$('#training-save-goals').addEventListener('click', () => {
  const targetSeconds = Number($('#training-target-time').value);
  const dailyMinutes = Number($('#training-daily-minutes').value);
  const weeklySolves = Number($('#training-weekly-goal').value);
  if (!Number.isFinite(targetSeconds) || targetSeconds < 1 || targetSeconds > 600 || !Number.isInteger(dailyMinutes) || dailyMinutes < 5 || dailyMinutes > 300 || !Number.isInteger(weeklySolves) || weeklySolves < 1 || weeklySolves > 2000) {
    return toast('Kiểm tra mục tiêu: thời gian 1–600 giây, phút/ngày 5–300, solve/tuần 1–2000.', 'error');
  }
  data.training.targetSeconds = targetSeconds;
  data.training.dailyMinutes = dailyMinutes;
  data.training.weeklySolves = weeklySolves;
  persist(); renderTraining(); toast('Đã lưu mục tiêu luyện tập.');
});

// Stats, sessions, settings and backup.
$('#export-solves-csv').addEventListener('click', exportSolvesCsv);
$('#create-session').addEventListener('click', createSession);
$('#settings-inspection').addEventListener('click', () => { data.settings.inspection = !data.settings.inspection; persist(); syncSettings(); });
$('#settings-sound').addEventListener('click', () => { data.settings.sound = !data.settings.sound; persist(); syncSettings(); });
$('#settings-compact').addEventListener('click', () => { data.settings.compactMode = !data.settings.compactMode; persist(); syncSettings(); });
$('#settings-reduced-motion').addEventListener('click', () => { data.settings.reducedMotion = !data.settings.reducedMotion; persist(); syncSettings(); });
$('#settings-dashboard-recent').addEventListener('click', () => { data.settings.dashboardWidgets.recent = !data.settings.dashboardWidgets.recent; persist(); syncSettings(); });
$('#settings-dashboard-quick').addEventListener('click', () => { data.settings.dashboardWidgets.quickAccess = !data.settings.dashboardWidgets.quickAccess; persist(); syncSettings(); });
$('#timer-decimals').value = String(data.settings.timerDecimals || 2);
$('#timer-decimals').addEventListener('change', () => { data.settings.timerDecimals = Number($('#timer-decimals').value) === 3 ? 3 : 2; persist(); renderTimerPage(); });
$('#theme-options').addEventListener('click', event => { const button = event.target.closest('[data-theme-choice]'); if (button) setTheme(button.dataset.themeChoice); });
$('#export-data').addEventListener('click', exportData);
$('#import-data').addEventListener('change', event => importData(event.target.files?.[0]));
$('#clear-data').addEventListener('click', () => {
  if (!confirm('Xóa toàn bộ session, lượt solve, công thức và cài đặt? Hãy xuất bản sao lưu trước nếu cần.')) return;
  const defaults = createDefaultData();
  Object.keys(data).forEach(key => delete data[key]); Object.assign(data, defaults);
  data.training = { ...DEFAULT_TRAINING }; solverFacelets = SOLVED_FACELETS; solverSolution = '';
  persist(); setTheme('dark'); renderAll(); navigate('home'); toast('Đã xóa toàn bộ dữ liệu.');
});

// Initial state.
document.documentElement.dataset.theme = data.settings.theme;
setTheme(data.settings.theme);
syncSettings();
renderAll();
setTimerState('idle', 'READY TO SOLVE', 'NHẤN SPACE HOẶC CHẠM ĐỂ BẮT ĐẦU');
$('#timer-time').textContent = displayTime(0);
$('#timer-decimals').value = String(data.settings.timerDecimals || 2);
updateTimerScrambleText();
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  navigator.serviceWorker.register(new URL('../sw.js', import.meta.url), { updateViaCache: 'none' }).then(registration => registration.update()).catch(error => console.warn('PWA service worker registration failed:', error));
}
